# Placeholder-Game-Name — implementation specification

Status: Approved for implementation by the user on 2026-10-17. This document governs this placeholder build. It does not define the production game.

## Current user-directed revisions — 2026-10-17

These override the initial plan below: double jump is available immediately, including existing saves. Movement VFX use tapered animated wind ribbons, with a small single jump, stronger double jump, horizontal dash/sprint trails, and light landing air sweeps. No movement dust particles. Damage shake is stronger and may restart on stronger impacts. Menus show titles, buttons and settings only; remove tutorial/reassurance copy and in-world tips/objective prose. World labels use high-resolution text; canvas renders at device pixel density up to 2×, and camera positions are rounded. Menu backgrounds do not apply blur. The original unlock gate is superseded; the circuit switch still gates the final route.

## Jump sound / feet alignment revision

Use a brief filtered-air jump sound with soft low tonal weight, slightly stronger on double jump. Reuse the noise buffer and clean up audio nodes. Anchor visible player art at the physics body bottom; preserve the anchor during deformation and suppress grounded rotation. Push this build to the user-confirmed `v-ahmed/Placeholder-Game-Name` repository while preserving its initial commit.

## Outcome and boundaries
Deliver a complete desktop-browser metroidvania prototype in `/Users/ahmedmustafa/Projects/Placeholder-Game-Name`. Target 5–10 minutes on a first playthrough. Use Phaser, TypeScript and Vite with pinned dependencies. Use generated geometric art and synthesized sound; no external character assets, lore, signature abilities, boss, enemy ability sets, equipment or skill trees. One delivery includes internal testing and repair before handoff.

## Exploration loop
Explore → see a blocked high route → traverse the lower route → unlock double jump → return via an upper route → open a persistent shortcut → reach the exit.

Five rooms:
1. Starting chamber: controls, checkpoint, visible unreachable upper exit.
2. Lower passage: sprint/dash practice, basic enemies and hazards.
3. Traversal chamber: double-jump pickup, checkpoint, vertical return path.
4. Upper return: double-jump route, connection back to the starting chamber, shortcut switch.
5. Final chamber: combined traversal/combat and a completion beacon.

Every required jump must be reachable with margin. Hazards must never respawn the player in damage. Room exits must have safe spawn points and clear markers. No accidental alternate route may bypass the double-jump gate.

## Controls and controller
A/D or arrows move; Space jumps; hold Shift sprints; K or X dashes; J or Z attacks; E interacts; Escape pauses; M mutes; F3 toggles diagnostics.

- Quick acceleration and stopping, controlled air steering, faster fall than ascent.
- Approximately 100 ms coyote time, 120 ms jump buffer, jump-release height control.
- Double jump unlock requires a fresh press and permits only one extra jump before landing.
- Horizontal dash lasts approximately 150 ms. One charge returns on landing with a short cooldown. No damage immunity from dash. Collision cannot be skipped at dash speed.
- Explicit priority: dead/transition/paused > hurt > dash > ordinary movement. Attack may coexist with ordinary movement, but not dash/hurt.
- Visual deformation never changes collision dimensions.
- No slopes, wall movement, moving platforms or ledge grabbing in this scope.

## Combat, health and progression
One short directional melee strike, one hit per enemy per swing, brief recovery, hit sparks and knockback. One generic patrol enemy turns at edges and walls and deals contact damage. No bespoke attack abilities. Player has five health units, bounded hurt knockback and about 800 ms damage immunity. Light contact and higher-damage hazards produce different shake strengths. Pits return to a safe checkpoint with damage; fatal damage triggers respawn.

Checkpoints restore health and save the active location. Unlock, shortcut and discovered-room map persist across death and reload. Enemies reset on respawn. Versioned, validated local storage fails gracefully. Restart erases progress after an in-game confirmation. Completion shows time/deaths and permits continue/replay.

## Presentation
Dark technical ruin, bright cyan player silhouette, warm coral threats, warm white platforms, amber interactions. Generated textures, consistent silhouettes and readable labels. Parallax background, room-specific title, restrained atmosphere. Dust for movement, sprint streaks, takeoff burst, double-jump ring, dash afterimages, velocity-scaled landing dust, attack arc, damage flash, bounded screen shake, checkpoint pulse. Cap effects and avoid unbounded allocations. Synthesized sounds start only after a user gesture; mute and reduced-motion controls persist. Reduced effects disable shake, hit pause and excessive particles.

Camera uses dead zone, smoothing, modest look-ahead, room bounds and short fade transitions. HUD shows health, dash charge, objective, traversal unlock and a discovered-room connection map. Native HTML overlays provide start/pause/death/completion menus with keyboard-operable buttons. The game fills the viewport with no website framing (user clarification). Camera zoom adapts to the viewport while preserving world scale relationships. Thin ledges permit upward passage and catch the player on descent, keeping traversal forgiving. Focus loss pauses and clears inputs.

## Architecture
- `src/main.ts`: composition, scenes, integration and lifecycle.
- `src/config.ts`: movement/combat tuning.
- `src/controller.ts`: testable controller rules and state.
- `src/rooms.ts`: data-driven rooms, solids, exits, enemies, hazards and markers.
- `src/progress.ts`: validated save data, checkpoints, unlocks and persistence.
- `src/style.css`: shell, HUD and overlays.
Keep render objects separate from physics bodies; document art and animation replacement in README. Use Arcade Physics and fixed physics stepping. Support high refresh rendering without frame-dependent movement/timers.

## Implementation order
1. Scaffold and save this plan; install dependencies.
2. Controller, generated art and safe test room.
3. Room graph, progression, checkpoints and completion.
4. Generic enemies, melee and damage.
5. Camera, effects, audio, map, UI and saves.
6. Targeted logic tests, typecheck, production build and browser playthrough; repair observed defects.

## Acceptance and verification
- Complete route from fresh save; double-jump gate cannot be crossed early.
- Coyote/buffer behavior, variable jump and exactly one extra jump.
- Dash ends safely at walls; no repeated air dash; hurt/death never leave actions stuck.
- Per-swing hit tracking and damage immunity.
- Checkpoint safety; shortcut/unlock persist after death and reload.
- Pause/focus clearing, restart, mute, effects settings and unavailable storage.
- Stable transitions and respawn during actions.
- Build contains all assets and runs without a backend.
- Aim for smooth 60 fps on desktop; report measured environment and any verification limitations honestly.

## Delivery
Source, lockfile, this plan, README with Node prerequisites, `npm install`, `npm run dev`, `npm run build`, `npm run preview`, controls, room walkthrough, asset replacement guide and known limitations. No repository push or hosted deployment until repository details are provided. Report actual verification results in `VERIFICATION.md`.
