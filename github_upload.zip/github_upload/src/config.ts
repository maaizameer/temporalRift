export const MOVE = {
  speed: 290, sprint: 435, acceleration: 2500, airAcceleration: 1900, braking: 3000,
  jump: 660, gravity: 1500, maxFall: 920, coyote: 100, buffer: 120,
  dashSpeed: 850, dashDuration: 150, dashCooldown: 380,
  hurtDuration: 180, invulnerability: 850, attackDuration: 150, attackCooldown: 300,
} as const;
export const VIEW = { width: 1280, height: 720 };
export const COLORS = { player: 0x8bf4e7, enemy: 0xfa837c, gold: 0xe5c48b, solid: 0x69777f, bg: 0x0d1721 };
export function approach(current: number, target: number, amount: number) {
  return current < target ? Math.min(target, current + amount) : Math.max(target, current - amount);
}
