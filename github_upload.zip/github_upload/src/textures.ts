/**
 * Procedural Texture Generator for Hollow Knight Dark Fantasy Aesthetics
 * Generates rich, characterful, atmospheric textures and sprites on offscreen canvases
 * and registers them directly into Phaser's Texture Manager for high-performance WebGL batching.
 */
import Phaser from 'phaser';

export function registerHollowKnightTextures(scene: Phaser.Scene) {
  const tm = scene.textures;

  // 1. Ancient Gothic Cavern Stone Slab (hk_stone_slab) - 128x64
  if (!tm.exists('hk_stone_slab')) {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;

    // Base deep obsidian slate with subtle gradient
    const grad = ctx.createLinearGradient(0, 0, 0, 64);
    grad.addColorStop(0, '#1c2830');
    grad.addColorStop(0.3, '#162026');
    grad.addColorStop(1, '#0e151a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 64);

    // Weathered horizontal masonry joints
    ctx.fillStyle = '#090e12';
    ctx.fillRect(0, 28, 128, 2);
    ctx.fillRect(0, 56, 128, 2);

    // Vertical stone block seams (staggered)
    ctx.fillRect(42, 0, 2, 28);
    ctx.fillRect(96, 0, 2, 28);
    ctx.fillRect(20, 28, 2, 28);
    ctx.fillRect(78, 28, 2, 28);

    // Fine hand-drawn stone fractures
    ctx.strokeStyle = '#22323c';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(12, 10); ctx.lineTo(24, 18); ctx.lineTo(34, 16);
    ctx.moveTo(85, 36); ctx.lineTo(92, 44); ctx.lineTo(108, 42);
    ctx.moveTo(55, 4); ctx.lineTo(62, 12);
    ctx.stroke();

    // Subtle stone specular highlights along seams
    ctx.strokeStyle = '#2d424e';
    ctx.beginPath();
    ctx.moveTo(0, 30); ctx.lineTo(128, 30);
    ctx.moveTo(44, 2); ctx.lineTo(44, 26);
    ctx.stroke();

    // Bioluminescent mossy top crust (Hollow Knight Greenpath/Crossroads moss)
    ctx.fillStyle = '#1e3830';
    ctx.fillRect(0, 0, 128, 6);
    ctx.fillStyle = '#3a6858';
    ctx.fillRect(0, 0, 128, 3);
    ctx.fillStyle = '#68c5a4';
    ctx.fillRect(0, 0, 128, 1.2);

    // Small hanging moss droplets / tendrils
    ctx.fillStyle = '#2d5446';
    for (let x = 6; x < 128; x += 14) {
      const h = 3 + ((x * 7) % 6);
      ctx.beginPath();
      ctx.moveTo(x - 2, 5);
      ctx.lineTo(x + 2, 5);
      ctx.lineTo(x, 5 + h);
      ctx.closePath();
      ctx.fill();
    }

    tm.addCanvas('hk_stone_slab', canvas);
  }

  // 2. Volcanic Charred Basalt with Magma Veins (hk_volcanic_slab) - 128x64
  if (!tm.exists('hk_volcanic_slab')) {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;

    // Scorched dark basalt base
    const grad = ctx.createLinearGradient(0, 0, 0, 64);
    grad.addColorStop(0, '#241410');
    grad.addColorStop(0.4, '#190e0b');
    grad.addColorStop(1, '#0e0806');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 64);

    // Fractured charcoal block seams
    ctx.fillStyle = '#080403';
    ctx.fillRect(0, 32, 128, 2.5);
    ctx.fillRect(52, 0, 2.5, 32);
    ctx.fillRect(104, 32, 2.5, 32);

    // Glowing magma fissures running through the basalt
    ctx.strokeStyle = '#ff3300';
    ctx.lineWidth = 1.8;
    ctx.shadowColor = '#ff5500';
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.moveTo(16, 4); ctx.lineTo(26, 18); ctx.lineTo(44, 22); ctx.lineTo(58, 14);
    ctx.moveTo(70, 34); ctx.lineTo(82, 48); ctx.lineTo(98, 42); ctx.lineTo(115, 54);
    ctx.stroke();

    // Hot molten core highlight inside fissures
    ctx.strokeStyle = '#ffe600';
    ctx.lineWidth = 0.9;
    ctx.shadowBlur = 3;
    ctx.beginPath();
    ctx.moveTo(18, 5); ctx.lineTo(26, 18); ctx.lineTo(42, 21);
    ctx.moveTo(72, 35); ctx.lineTo(82, 48); ctx.lineTo(96, 43);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Scorched volcanic crust top edge
    ctx.fillStyle = '#421d14';
    ctx.fillRect(0, 0, 128, 5);
    ctx.fillStyle = '#ff4400';
    ctx.fillRect(0, 0, 128, 2);
    ctx.fillStyle = '#ffaa00';
    ctx.fillRect(0, 0, 128, 1);

    tm.addCanvas('hk_volcanic_slab', canvas);
  }

  // 3. Vaulted Gothic Cathedral Slab (hk_cathedral_slab) - 128x64
  if (!tm.exists('hk_cathedral_slab')) {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;

    // Deep royal violet-slate stone
    const grad = ctx.createLinearGradient(0, 0, 0, 64);
    grad.addColorStop(0, '#221630');
    grad.addColorStop(0.35, '#181024');
    grad.addColorStop(1, '#0e0916');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 64);

    // Gothic ashlar block joints
    ctx.fillStyle = '#090510';
    ctx.fillRect(0, 30, 128, 2);
    ctx.fillRect(64, 0, 2, 30);
    ctx.fillRect(32, 30, 2, 34);
    ctx.fillRect(96, 30, 2, 34);

    // Carved ancient temporal relief engravings
    ctx.strokeStyle = '#4e3370';
    ctx.lineWidth = 1;
    ctx.beginPath();
    // Chevron arch pattern
    for (let cx = 16; cx < 128; cx += 32) {
      ctx.moveTo(cx - 8, 22); ctx.lineTo(cx, 14); ctx.lineTo(cx + 8, 22);
    }
    ctx.stroke();

    // Polished flagstone rim with brass filigree
    ctx.fillStyle = '#3c2456';
    ctx.fillRect(0, 0, 128, 5);
    ctx.fillStyle = '#8b5cf6';
    ctx.fillRect(0, 0, 128, 2);
    ctx.fillStyle = '#d8b4fe';
    ctx.fillRect(0, 0, 128, 1);

    tm.addCanvas('hk_cathedral_slab', canvas);
  }

  // 4. Menacing Gothic Crystalline Spikes (hk_spikes) - 32x32
  if (!tm.exists('hk_spikes')) {
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d')!;

    // Draw 3 distinct hand-crafted, jagged needle-sharp spikes
    const drawThorn = (baseX: number, width: number, height: number, tilt: number) => {
      const tipX = baseX + width / 2 + tilt;
      const tipY = 32 - height;

      // Dark obsidian shadow facet
      ctx.fillStyle = '#0b1116';
      ctx.beginPath();
      ctx.moveTo(baseX, 32);
      ctx.lineTo(tipX, tipY);
      ctx.lineTo(baseX + width / 2, 32);
      ctx.closePath();
      ctx.fill();

      // Gleaming faceted front
      const thornGrad = ctx.createLinearGradient(baseX, 32, tipX, tipY);
      thornGrad.addColorStop(0, '#1c2830');
      thornGrad.addColorStop(0.6, '#314450');
      thornGrad.addColorStop(1, '#658292');
      ctx.fillStyle = thornGrad;
      ctx.beginPath();
      ctx.moveTo(baseX + width / 2, 32);
      ctx.lineTo(tipX, tipY);
      ctx.lineTo(baseX + width, 32);
      ctx.closePath();
      ctx.fill();

      // Razor specular highlight ridge along the spine
      ctx.strokeStyle = '#a8f0e0';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(baseX + width / 2, 32);
      ctx.lineTo(tipX, tipY);
      ctx.stroke();

      // Sharp glowing tip point
      ctx.fillStyle = '#e8fffa';
      ctx.fillRect(tipX - 0.5, tipY, 1, 2);
    };

    drawThorn(0, 12, 28, -1.5);
    drawThorn(10, 13, 31, 0.5);
    drawThorn(21, 11, 26, 1.2);

    tm.addCanvas('hk_spikes', canvas);
  }

  // 5. Volcanic Magma Hive Spawner Enemy (hk_magma_spawner) - 56x64
  if (!tm.exists('hk_magma_spawner')) {
    const canvas = document.createElement('canvas');
    canvas.width = 56;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;

    // Jagged volcanic rock spire silhouette
    ctx.fillStyle = '#1c0e0a';
    ctx.beginPath();
    ctx.moveTo(6, 62);
    ctx.lineTo(12, 28);
    ctx.lineTo(20, 8);
    ctx.lineTo(28, 4);
    ctx.lineTo(36, 8);
    ctx.lineTo(44, 28);
    ctx.lineTo(50, 62);
    ctx.closePath();
    ctx.fill();

    // Carapace plate shading
    ctx.fillStyle = '#2e1711';
    ctx.beginPath();
    ctx.moveTo(14, 26); ctx.lineTo(28, 12); ctx.lineTo(42, 26);
    ctx.lineTo(38, 48); ctx.lineTo(28, 54); ctx.lineTo(18, 48);
    ctx.closePath();
    ctx.fill();

    // Top molten vent / caldera
    ctx.fillStyle = '#ff2b00';
    ctx.shadowColor = '#ff6600';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.ellipse(28, 7, 9, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Incandescent bubbling core
    ctx.fillStyle = '#ffee33';
    ctx.shadowBlur = 5;
    ctx.beginPath();
    ctx.ellipse(28, 7, 5, 2.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Glowing magma eyes / fissures on the hive body
    ctx.fillStyle = '#ff4400';
    ctx.beginPath();
    ctx.ellipse(22, 32, 4, 7, -0.2, 0, Math.PI * 2);
    ctx.ellipse(34, 32, 4, 7, 0.2, 0, Math.PI * 2);
    ctx.ellipse(28, 44, 5, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffcc00';
    ctx.beginPath();
    ctx.ellipse(22, 32, 2, 4, -0.2, 0, Math.PI * 2);
    ctx.ellipse(34, 32, 2, 4, 0.2, 0, Math.PI * 2);
    ctx.ellipse(28, 44, 2.5, 2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Outer cracked basalt ridges
    ctx.strokeStyle = '#482419';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(10, 30); ctx.lineTo(20, 34); ctx.lineTo(14, 50);
    ctx.moveTo(46, 30); ctx.lineTo(36, 34); ctx.lineTo(42, 50);
    ctx.stroke();

    tm.addCanvas('hk_magma_spawner', canvas);
  }

  // 6. Volcanic Molten Rock (hk_lava_rock) - 24x24
  if (!tm.exists('hk_lava_rock')) {
    const canvas = document.createElement('canvas');
    canvas.width = 24;
    canvas.height = 24;
    const ctx = canvas.getContext('2d')!;

    // Outer fiery glow
    ctx.shadowColor = '#ff5500';
    ctx.shadowBlur = 8;
    ctx.fillStyle = '#ff3700';
    ctx.beginPath();
    ctx.arc(12, 12, 9, 0, Math.PI * 2);
    ctx.fill();

    // Charred crust chunks
    ctx.fillStyle = '#26110a';
    ctx.beginPath();
    ctx.arc(9, 10, 4, 0, Math.PI * 2);
    ctx.arc(15, 14, 4.5, 0, Math.PI * 2);
    ctx.fill();

    // White-hot molten fissures
    ctx.fillStyle = '#ffea44';
    ctx.shadowBlur = 4;
    ctx.beginPath();
    ctx.arc(12, 11, 2.5, 0, Math.PI * 2);
    ctx.arc(14, 9, 1.8, 0, Math.PI * 2);
    ctx.fill();

    tm.addCanvas('hk_lava_rock', canvas);
  }

  // 7. Hollow Knight Ornate Iron Bench Checkpoint (hk_bench) - 64x44
  if (!tm.exists('hk_bench')) {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 44;
    const ctx = canvas.getContext('2d')!;

    // Iron bench backrest arches with wrought curls
    ctx.strokeStyle = '#2b3642';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';

    // Backrest arches
    ctx.beginPath();
    ctx.arc(20, 20, 10, Math.PI, 0);
    ctx.arc(36, 20, 10, Math.PI, 0);
    ctx.stroke();

    // Decorative curled armrests
    ctx.beginPath();
    ctx.moveTo(8, 28); ctx.quadraticCurveTo(4, 18, 10, 16);
    ctx.moveTo(48, 28); ctx.quadraticCurveTo(52, 18, 46, 16);
    ctx.stroke();

    // Bench seating plank
    ctx.fillStyle = '#1c242c';
    ctx.fillRect(8, 26, 40, 5);
    ctx.fillStyle = '#3a4a58';
    ctx.fillRect(8, 26, 40, 1.5);

    // Bench legs
    ctx.strokeStyle = '#232c36';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(12, 31); ctx.lineTo(9, 43);
    ctx.moveTo(44, 31); ctx.lineTo(47, 43);
    ctx.moveTo(28, 31); ctx.lineTo(28, 43);
    ctx.stroke();

    // Brass accent rivets
    ctx.fillStyle = '#d4b476';
    ctx.fillRect(10, 28, 2, 2);
    ctx.fillRect(27, 28, 2, 2);
    ctx.fillRect(44, 28, 2, 2);

    // Iron Lantern post on right
    ctx.strokeStyle = '#384654';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(56, 43); ctx.lineTo(56, 10);
    ctx.quadraticCurveTo(56, 4, 60, 4);
    ctx.stroke();

    // Hanging Soul Lantern
    ctx.fillStyle = '#1c242c';
    ctx.fillRect(58, 6, 4, 2); // lantern cap

    // Soul lantern glass & radiant glow
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 9;
    ctx.fillStyle = '#7ee0c5';
    ctx.beginPath();
    ctx.ellipse(60, 12, 3.5, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(60, 12, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    tm.addCanvas('hk_bench', canvas);
  }

  // 8. Temporal Relic Medallion (hk_relic) - 32x32
  if (!tm.exists('hk_relic')) {
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d')!;

    // Ancient Hallownest Relic Medallion
    ctx.shadowColor = '#ffd700';
    ctx.shadowBlur = 8;

    // Carved beetle crest outer silhouette
    ctx.fillStyle = '#b8903c';
    ctx.beginPath();
    ctx.moveTo(16, 2);
    ctx.lineTo(28, 12);
    ctx.lineTo(24, 28);
    ctx.lineTo(16, 31);
    ctx.lineTo(8, 28);
    ctx.lineTo(4, 12);
    ctx.closePath();
    ctx.fill();

    // Inner gold filigree
    ctx.fillStyle = '#f6d878';
    ctx.beginPath();
    ctx.moveTo(16, 5);
    ctx.lineTo(25, 13);
    ctx.lineTo(22, 26);
    ctx.lineTo(16, 28);
    ctx.lineTo(10, 26);
    ctx.lineTo(7, 13);
    ctx.closePath();
    ctx.fill();

    // Glowing cyan temporal core (hourglass jewel)
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 6;
    ctx.fillStyle = '#102028';
    ctx.beginPath();
    ctx.arc(16, 17, 7, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.moveTo(12, 12); ctx.lineTo(20, 12); ctx.lineTo(13, 22); ctx.lineTo(19, 22);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(15, 16, 2, 2);

    tm.addCanvas('hk_relic', canvas);
  }

  // 9. Chronos Shockwave Energy Crest (hk_shockwave) - 28x40
  if (!tm.exists('hk_shockwave')) {
    const canvas = document.createElement('canvas');
    canvas.width = 28;
    canvas.height = 40;
    const ctx = canvas.getContext('2d')!;

    ctx.shadowColor = '#d977f8';
    ctx.shadowBlur = 10;

    // Upward jagged crystalline rift wave
    ctx.fillStyle = '#6b21a8';
    ctx.beginPath();
    ctx.moveTo(4, 40);
    ctx.lineTo(10, 20);
    ctx.lineTo(14, 2);
    ctx.lineTo(18, 18);
    ctx.lineTo(24, 40);
    ctx.closePath();
    ctx.fill();

    // Violet/pink energy core
    ctx.fillStyle = '#d977f8';
    ctx.beginPath();
    ctx.moveTo(7, 40);
    ctx.lineTo(12, 22);
    ctx.lineTo(14, 5);
    ctx.lineTo(16, 20);
    ctx.lineTo(21, 40);
    ctx.closePath();
    ctx.fill();

    // Radiant white inner rift line
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(14, 7);
    ctx.lineTo(14, 38);
    ctx.stroke();

    tm.addCanvas('hk_shockwave', canvas);
  }

  // 10. Kamikaze Fire Wisp Enemy (hk_wisp) - 36x36
  if (!tm.exists('hk_wisp')) {
    const canvas = document.createElement('canvas');
    canvas.width = 36;
    canvas.height = 36;
    const ctx = canvas.getContext('2d')!;

    // Fiery aura
    ctx.shadowColor = '#ff4400';
    ctx.shadowBlur = 10;

    // Flowing flame horns & tendrils
    ctx.fillStyle = '#ff3300';
    ctx.beginPath();
    ctx.moveTo(18, 4);
    ctx.quadraticCurveTo(8, 10, 6, 26);
    ctx.quadraticCurveTo(12, 34, 18, 30);
    ctx.quadraticCurveTo(24, 34, 30, 26);
    ctx.quadraticCurveTo(28, 10, 18, 4);
    ctx.fill();

    // Inner bright flame core
    ctx.fillStyle = '#ff9900';
    ctx.beginPath();
    ctx.ellipse(18, 18, 8, 11, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dark horned mask skull silhouette
    ctx.fillStyle = '#140804';
    ctx.beginPath();
    ctx.moveTo(18, 8);
    ctx.lineTo(24, 14);
    ctx.lineTo(22, 24);
    ctx.lineTo(18, 27);
    ctx.lineTo(14, 24);
    ctx.lineTo(12, 14);
    ctx.closePath();
    ctx.fill();

    // Glowing white soul eyes (iconic Hollow Knight void eye shape)
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 4;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.ellipse(15, 18, 2, 3.5, -0.2, 0, Math.PI * 2);
    ctx.ellipse(21, 18, 2, 3.5, 0.2, 0, Math.PI * 2);
    ctx.fill();

    tm.addCanvas('hk_wisp', canvas);
  }
}
