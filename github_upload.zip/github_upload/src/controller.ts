import { MOVE } from './config';
/** Clock-independent rules shared by the actual controller and tests. */
export class Traversal {
  lastGround = -Infinity;
  jumpQueued = -Infinity;
  airJumpUsed = false;
  dashReady = true;
  lastDash = -Infinity;
  grounded = false;
  landed(ground: boolean, now: number) {
    this.grounded = ground;
    if (ground) { this.lastGround = now; this.airJumpUsed = false; this.dashReady = true; }
  }
  queueJump(now: number) { this.jumpQueued = now; }
  consumeJump(now: number, unlocked: boolean): 'ground' | 'air' | null {
    if (now - this.jumpQueued > MOVE.buffer) return null;
    if (this.grounded || now - this.lastGround <= MOVE.coyote) {
      this.jumpQueued = -Infinity; this.lastGround = -Infinity; this.grounded = false;
      return 'ground';
    }
    if (unlocked && !this.airJumpUsed) {
      this.airJumpUsed = true; this.jumpQueued = -Infinity; return 'air';
    }
    return null;
  }
  consumeDash(now: number) {
    if (!this.dashReady || now - this.lastDash < MOVE.dashCooldown) return false;
    this.dashReady = false; this.lastDash = now; return true;
  }
  reset() {
    this.lastGround = -Infinity; this.jumpQueued = -Infinity; this.airJumpUsed = false;
    this.dashReady = true; this.lastDash = -Infinity; this.grounded = false;
  }
}
