import type { RoomId } from './progress';
export type Platform = [number, number, number, number];
export type EnemyKind = 'patrol' | 'bomber' | 'hurler' | 'spawner';
export type EnemySpawn = [number, number, EnemyKind?];
export interface Exit { x: number; y: number; to: RoomId; spawn: [number, number]; label: string; gate?: 'jump' | 'shortcut'; }
export interface Room {
  name: string; subtitle: string; tint: number; platforms: Platform[]; exits: Exit[];
  enemies: EnemySpawn[]; hazards: Platform[]; checkpoint?: [number, number]; pickup?: [number, number]; switch?: [number, number]; goal?: [number, number];
  relic?: [number, number];
}
const floor: Platform = [0, 840, 1920, 120];
export const ROOMS: Record<RoomId, Room> = {
  start: { name: '01 / THE THRESHOLD', subtitle: 'An opening above. A passage below.', tint: 0x14313b,
    platforms: [floor, [150,580,430,24], [760,580,440,24], [1380,580,500,24]],
    checkpoint: [340,810], enemies: [], hazards: [],
    exits: [
      {x:1840,y:790,to:'lower',spawn:[150,790],label:'LOWER PASSAGE →'},
      {x:1810,y:530,to:'upper',spawn:[1740,790],label:'UPPER LOOP',gate:'shortcut'},
      {x:240,y:530,to:'final',spawn:[880,790],label:'← BOSS ARENA (CHRONOS)'},
    ] },
  lower: { name:'02 / THE INFERNAL PASSAGE', subtitle:'Molten air. Watch the skies and the magma.',tint:0x421208,
    platforms:[[0,840,760,120],[910,840,1010,120],[390,730,180,24],[1060,710,190,24],[1400,620,180,24]],
    enemies:[[480,680,'bomber'],[630,810,'hurler'],[1150,660,'spawner'],[1480,570,'bomber'],[1690,810,'hurler']], hazards:[[770,864,130,36],[1110,818,100,22]],
    relic:[1420,570],
    exits:[{x:80,y:790,to:'start',spawn:[1740,790],label:'← THRESHOLD'}, {x:1840,y:790,to:'well',spawn:[150,790],label:'THE WELL →'}] },
  well: {name:'03 / THE WELL',subtitle:'A second breath changes the way back.',tint:0x17382f,
    platforms:[floor,[990,720,200,24],[1250,600,190,24],[1510,480,360,24]],
    enemies:[[560,810]],hazards:[],checkpoint:[780,810],pickup:[1000,790],
    relic:[1620,430],
    exits:[{x:80,y:790,to:'lower',spawn:[1740,790],label:'← UNDERPASS'}, {x:1790,y:430,to:'upper',spawn:[150,790],label:'UPPER RETURN →',gate:'jump'}] },
  upper: {name:'04 / THE RETURN',subtitle:'Open the circuit. Remember this way.',tint:0x26333e,
    platforms:[[0,840,480,120],[680,840,420,120],[1300,840,620,120],[400,720,180,24],[710,610,180,24],[1010,660,180,24]],
    enemies:[[920,810],[1450,810]], hazards:[[490,864,180,36],[1110,864,180,36]],switch:[1650,800],
    relic:[730,560],
    exits:[{x:80,y:790,to:'well',spawn:[1680,430],label:'← THE WELL'}, {x:1840,y:790,to:'start',spawn:[1680,530],label:'THRESHOLD →',gate:'shortcut'}] },
  final: {name:'05 / THE TEMPORAL CORE',subtitle:'Chronos awaits. Break the loop.',tint:0x392019,
    platforms:[[0,840,650,120],[820,840,1100,120],[450,720,180,24],[920,660,200,24],[1220,560,220,24],[1520,660,200,24]],
    enemies:[],hazards:[[660,864,150,36]],goal:[1750,790],
    exits:[{x:80,y:790,to:'start',spawn:[350,530],label:'← THRESHOLD'}] },
};
export const CHECKPOINTS: Partial<Record<RoomId,[number,number]>> = {start:[340,790],well:[780,790]};
