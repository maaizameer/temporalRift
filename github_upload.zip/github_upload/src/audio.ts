/** Procedural Web Audio API sound synthesis without external sound files. */
const noiseBuffers = new WeakMap<AudioContext, AudioBuffer>();

function getNoiseBuffer(context: AudioContext): AudioBuffer {
  let buffer = noiseBuffers.get(context);
  if (!buffer) {
    buffer = context.createBuffer(1, Math.ceil(context.sampleRate * 0.6), context.sampleRate);
    const samples = buffer.getChannelData(0);
    for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
    noiseBuffers.set(context, buffer);
  }
  return buffer;
}

export function playJumpSound(context: AudioContext, doubleJump: boolean) {
  const buffer = getNoiseBuffer(context);
  const now = context.currentTime;
  const duration = doubleJump ? .24 : .17;
  const air = context.createBufferSource();
  air.buffer = buffer;
  const filter = context.createBiquadFilter();
  filter.type = 'bandpass';
  filter.Q.value = .65;
  filter.frequency.setValueAtTime(doubleJump ? 1100 : 850, now);
  filter.frequency.exponentialRampToValueAtTime(doubleJump ? 1900 : 1450, now + .035);
  filter.frequency.exponentialRampToValueAtTime(430, now + duration);
  const airGain = context.createGain();
  airGain.gain.setValueAtTime(.0001, now);
  airGain.gain.exponentialRampToValueAtTime(doubleJump ? .23 : .17, now + .018);
  airGain.gain.exponentialRampToValueAtTime(.0001, now + duration);
  air.connect(filter); filter.connect(airGain); airGain.connect(context.destination);
  air.start(now); air.stop(now + duration);
  air.onended = () => { air.disconnect(); filter.disconnect(); airGain.disconnect(); };

  const body = context.createOscillator();
  const bodyGain = context.createGain();
  body.type = 'sine';
  body.frequency.setValueAtTime(doubleJump ? 205 : 175, now);
  body.frequency.exponentialRampToValueAtTime(doubleJump ? 120 : 95, now + .09);
  bodyGain.gain.setValueAtTime(.0001, now);
  bodyGain.gain.exponentialRampToValueAtTime(doubleJump ? .055 : .045, now + .008);
  bodyGain.gain.exponentialRampToValueAtTime(.0001, now + .115);
  body.connect(bodyGain); bodyGain.connect(context.destination);
  body.start(now); body.stop(now + .12);
  body.onended = () => { body.disconnect(); bodyGain.disconnect(); };
}

export function playShootSound(context: AudioContext) {
  const now = context.currentTime;
  const osc = context.createOscillator();
  const gain = context.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(880, now);
  osc.frequency.exponentialRampToValueAtTime(180, now + 0.14);
  gain.gain.setValueAtTime(0.12, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
  osc.connect(gain);
  gain.connect(context.destination);
  osc.start(now);
  osc.stop(now + 0.14);
  osc.onended = () => { osc.disconnect(); gain.disconnect(); };

  // Subtle high sparkle
  const sub = context.createOscillator();
  const subGain = context.createGain();
  sub.type = 'sine';
  sub.frequency.setValueAtTime(1400, now);
  sub.frequency.exponentialRampToValueAtTime(450, now + 0.08);
  subGain.gain.setValueAtTime(0.04, now);
  subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
  sub.connect(subGain);
  subGain.connect(context.destination);
  sub.start(now);
  sub.stop(now + 0.08);
  sub.onended = () => { sub.disconnect(); subGain.disconnect(); };
}

export function playExplosionSound(context: AudioContext, isBig = false) {
  const buffer = getNoiseBuffer(context);
  const now = context.currentTime;
  const duration = isBig ? 0.45 : 0.28;

  const noise = context.createBufferSource();
  noise.buffer = buffer;
  const filter = context.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(isBig ? 650 : 500, now);
  filter.frequency.exponentialRampToValueAtTime(60, now + duration);

  const gain = context.createGain();
  gain.gain.setValueAtTime(isBig ? 0.28 : 0.18, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  noise.connect(filter);
  filter.connect(gain);
  gain.connect(context.destination);
  noise.start(now);
  noise.stop(now + duration);
  noise.onended = () => { noise.disconnect(); filter.disconnect(); gain.disconnect(); };

  // Bass thump
  const sub = context.createOscillator();
  const subGain = context.createGain();
  sub.type = 'triangle';
  sub.frequency.setValueAtTime(isBig ? 130 : 110, now);
  sub.frequency.exponentialRampToValueAtTime(28, now + duration * 0.7);
  subGain.gain.setValueAtTime(isBig ? 0.22 : 0.12, now);
  subGain.gain.exponentialRampToValueAtTime(0.001, now + duration * 0.7);
  sub.connect(subGain);
  subGain.connect(context.destination);
  sub.start(now);
  sub.stop(now + duration * 0.7);
  sub.onended = () => { sub.disconnect(); subGain.disconnect(); };
}

export function playLavaThrowSound(context: AudioContext) {
  const now = context.currentTime;
  const osc = context.createOscillator();
  const gain = context.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(140, now);
  osc.frequency.exponentialRampToValueAtTime(290, now + 0.1);
  osc.frequency.exponentialRampToValueAtTime(90, now + 0.25);

  const filter = context.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(420, now);

  gain.gain.setValueAtTime(0.001, now);
  gain.gain.linearRampToValueAtTime(0.09, now + 0.05);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(context.destination);
  osc.start(now);
  osc.stop(now + 0.25);
  osc.onended = () => { osc.disconnect(); filter.disconnect(); gain.disconnect(); };
}

export function playBossDashSound(context: AudioContext) {
  const now = context.currentTime;
  const osc = context.createOscillator();
  const gain = context.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(420, now);
  osc.frequency.exponentialRampToValueAtTime(95, now + 0.28);

  const buffer = getNoiseBuffer(context);
  const noise = context.createBufferSource();
  noise.buffer = buffer;
  const filter = context.createBiquadFilter();
  filter.type = 'bandpass';
  filter.frequency.setValueAtTime(550, now);
  filter.frequency.exponentialRampToValueAtTime(180, now + 0.28);

  gain.gain.setValueAtTime(0.18, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

  osc.connect(gain);
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(context.destination);

  osc.start(now);
  osc.stop(now + 0.28);
  noise.start(now);
  noise.stop(now + 0.28);
  osc.onended = () => { osc.disconnect(); noise.disconnect(); filter.disconnect(); gain.disconnect(); };
}

export function playTimeTrapSound(context: AudioContext) {
  const now = context.currentTime;
  const osc1 = context.createOscillator();
  const osc2 = context.createOscillator();
  const gain = context.createGain();

  osc1.type = 'sine';
  osc2.type = 'sine';
  osc1.frequency.setValueAtTime(440, now);
  osc2.frequency.setValueAtTime(444, now); // 4Hz detuned beat frequency

  gain.gain.setValueAtTime(0.001, now);
  gain.gain.linearRampToValueAtTime(0.07, now + 0.08);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

  osc1.connect(gain);
  osc2.connect(gain);
  gain.connect(context.destination);

  osc1.start(now);
  osc1.stop(now + 0.35);
  osc2.start(now);
  osc2.stop(now + 0.35);
  osc1.onended = () => { osc1.disconnect(); osc2.disconnect(); gain.disconnect(); };
}

// --- Procedural Dark Fantasy Ambient Music Engine ---
let musicMasterGain: GainNode | null = null;
let musicInterval: number | null = null;
let currentMusicContext: AudioContext | null = null;
let musicStep = 0;
let isBossMode = false;

// Haunting A-minor crystalline scale for exploration (Hollow Knight style)
const EXPLORE_NOTES = [220, 261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 659.25];
// Tense, dramatic D-Phrygian / Harmonic scale for Chronos Boss fight
const BOSS_NOTES = [146.83, 155.56, 196.00, 220.00, 246.94, 293.66, 311.13, 392.00];

export function setMusicBoss(bossActive: boolean) {
  isBossMode = bossActive;
}

export function updateMusic(context: AudioContext, muted: boolean, bossActive: boolean) {
  isBossMode = bossActive;
  if (muted || context.state !== 'running') {
    stopMusic();
    return;
  }
  if (!musicMasterGain || currentMusicContext !== context) {
    initMusic(context);
  }
}

function initMusic(context: AudioContext) {
  stopMusic();
  currentMusicContext = context;
  musicMasterGain = context.createGain();
  musicMasterGain.gain.setValueAtTime(0.001, context.currentTime);
  musicMasterGain.gain.linearRampToValueAtTime(0.14, context.currentTime + 2.5);
  musicMasterGain.connect(context.destination);

  // Deep Cello / Sub Drone
  const drone = context.createOscillator();
  const droneFilter = context.createBiquadFilter();
  const droneGain = context.createGain();

  drone.type = 'sawtooth';
  drone.frequency.setValueAtTime(55, context.currentTime); // A1 note
  droneFilter.type = 'lowpass';
  droneFilter.frequency.setValueAtTime(140, context.currentTime);

  droneGain.gain.setValueAtTime(0.08, context.currentTime);

  drone.connect(droneFilter);
  droneFilter.connect(droneGain);
  droneGain.connect(musicMasterGain);
  drone.start();

  musicStep = 0;
  // Step sequencer: runs every 240ms for rhythmic cohesion
  musicInterval = window.setInterval(() => {
    if (!currentMusicContext || currentMusicContext.state !== 'running' || !musicMasterGain) return;
    const now = currentMusicContext.currentTime;
    musicStep++;

    if (!isBossMode) {
      // Exploration: Delicate, sparse piano/bell notes in A minor
      if (musicStep % 2 === 0 && Math.random() < 0.65) {
        const note = EXPLORE_NOTES[Math.floor(Math.random() * EXPLORE_NOTES.length)];
        const bell = currentMusicContext.createOscillator();
        const bellGain = currentMusicContext.createGain();
        bell.type = 'sine';
        bell.frequency.setValueAtTime(note, now);

        bellGain.gain.setValueAtTime(0.001, now);
        bellGain.gain.linearRampToValueAtTime(0.05, now + 0.04);
        bellGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.6);

        bell.connect(bellGain);
        bellGain.connect(musicMasterGain);
        bell.start(now);
        bell.stop(now + 1.7);
        bell.onended = () => { bell.disconnect(); bellGain.disconnect(); };
      }
    } else {
      // Boss Phase: Urgent driving ostinato + dark low thuds
      const note = BOSS_NOTES[musicStep % BOSS_NOTES.length];
      const lead = currentMusicContext.createOscillator();
      const leadFilter = currentMusicContext.createBiquadFilter();
      const leadGain = currentMusicContext.createGain();

      lead.type = 'sawtooth';
      lead.frequency.setValueAtTime(note, now);
      leadFilter.type = 'lowpass';
      leadFilter.frequency.setValueAtTime(450, now);
      leadFilter.frequency.exponentialRampToValueAtTime(120, now + 0.22);

      leadGain.gain.setValueAtTime(0.08, now);
      leadGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      lead.connect(leadFilter);
      leadFilter.connect(leadGain);
      leadGain.connect(musicMasterGain);
      lead.start(now);
      lead.stop(now + 0.23);
      lead.onended = () => { lead.disconnect(); leadFilter.disconnect(); leadGain.disconnect(); };

      // Low heartbeat thud every 4 steps
      if (musicStep % 4 === 0) {
        const kick = currentMusicContext.createOscillator();
        const kickGain = currentMusicContext.createGain();
        kick.type = 'triangle';
        kick.frequency.setValueAtTime(95, now);
        kick.frequency.exponentialRampToValueAtTime(32, now + 0.18);
        kickGain.gain.setValueAtTime(0.18, now);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        kick.connect(kickGain);
        kickGain.connect(musicMasterGain);
        kick.start(now);
        kick.stop(now + 0.19);
        kick.onended = () => { kick.disconnect(); kickGain.disconnect(); };
      }
    }
  }, 230);
}

export function stopMusic() {
  if (musicInterval !== null) {
    window.clearInterval(musicInterval);
    musicInterval = null;
  }
  if (musicMasterGain && currentMusicContext) {
    try {
      musicMasterGain.gain.setValueAtTime(musicMasterGain.gain.value, currentMusicContext.currentTime);
      musicMasterGain.gain.linearRampToValueAtTime(0.001, currentMusicContext.currentTime + 0.5);
    } catch {}
    musicMasterGain = null;
  }
}

export function playShockwaveSound(context: AudioContext) {
  const now = context.currentTime;
  const osc = context.createOscillator();
  const gain = context.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(220, now);
  osc.frequency.exponentialRampToValueAtTime(45, now + 0.4);

  const filter = context.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(380, now);
  filter.frequency.exponentialRampToValueAtTime(70, now + 0.4);

  gain.gain.setValueAtTime(0.16, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(context.destination);
  osc.start(now);
  osc.stop(now + 0.4);
  osc.onended = () => { osc.disconnect(); filter.disconnect(); gain.disconnect(); };
}

export function playRelicSound(context: AudioContext) {
  const now = context.currentTime;
  const chord = [392.00, 493.88, 587.33, 783.99]; // G-major radiant triad
  chord.forEach((freq, idx) => {
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + idx * 0.06);

    gain.gain.setValueAtTime(0.001, now + idx * 0.06);
    gain.gain.linearRampToValueAtTime(0.09, now + idx * 0.06 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.06 + 1.2);

    osc.connect(gain);
    gain.connect(context.destination);
    osc.start(now + idx * 0.06);
    osc.stop(now + idx * 0.06 + 1.25);
    osc.onended = () => { osc.disconnect(); gain.disconnect(); };
  });
}

export function playMapOpenSound(context: AudioContext) {
  const now = context.currentTime;
  const buffer = getNoiseBuffer(context);
  const noise = context.createBufferSource();
  noise.buffer = buffer;
  const filter = context.createBiquadFilter();
  filter.type = 'bandpass';
  filter.frequency.setValueAtTime(350, now);
  filter.frequency.exponentialRampToValueAtTime(1400, now + 0.18);
  const noiseGain = context.createGain();
  noiseGain.gain.setValueAtTime(0.001, now);
  noiseGain.gain.linearRampToValueAtTime(0.07, now + 0.04);
  noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);
  noise.connect(filter);
  filter.connect(noiseGain);
  noiseGain.connect(context.destination);
  noise.start(now);
  noise.stop(now + 0.23);
  noise.onended = () => { noise.disconnect(); filter.disconnect(); noiseGain.disconnect(); };

  [523.25, 783.99].forEach((freq, idx) => {
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + idx * 0.07);
    gain.gain.setValueAtTime(0.001, now + idx * 0.07);
    gain.gain.linearRampToValueAtTime(0.05, now + idx * 0.07 + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.07 + 0.9);
    osc.connect(gain);
    gain.connect(context.destination);
    osc.start(now + idx * 0.07);
    osc.stop(now + idx * 0.07 + 0.95);
    osc.onended = () => { osc.disconnect(); gain.disconnect(); };
  });
}

export function playMapCloseSound(context: AudioContext) {
  const now = context.currentTime;
  const buffer = getNoiseBuffer(context);
  const noise = context.createBufferSource();
  noise.buffer = buffer;
  const filter = context.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(1200, now);
  filter.frequency.exponentialRampToValueAtTime(180, now + 0.16);
  const gain = context.createGain();
  gain.gain.setValueAtTime(0.05, now);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(context.destination);
  noise.start(now);
  noise.stop(now + 0.17);
  noise.onended = () => { noise.disconnect(); filter.disconnect(); gain.disconnect(); };
}

export function playBossDefeatChime(context: AudioContext) {
  const now = context.currentTime;
  const chord = [146.83, 220.00, 293.66, 349.23, 440.00];
  chord.forEach((freq, idx) => {
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = idx === 0 ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(freq, now + idx * 0.08);
    gain.gain.setValueAtTime(0.001, now + idx * 0.08);
    gain.gain.linearRampToValueAtTime(idx === 0 ? 0.18 : 0.09, now + idx * 0.08 + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 3.2);
    osc.connect(gain);
    gain.connect(context.destination);
    osc.start(now + idx * 0.08);
    osc.stop(now + idx * 0.08 + 3.3);
    osc.onended = () => { osc.disconnect(); gain.disconnect(); };
  });
}
