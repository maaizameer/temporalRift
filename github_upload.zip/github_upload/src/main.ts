import Phaser from 'phaser';
import './style.css';
import {
  playJumpSound, playShootSound, playExplosionSound, playLavaThrowSound,
  playBossDashSound, playTimeTrapSound, playShockwaveSound, playRelicSound,
  updateMusic, stopMusic, setMusicBoss,
  playMapOpenSound, playMapCloseSound, playBossDefeatChime
} from './audio';
import { MOVE, COLORS, approach } from './config';
import { Traversal } from './controller';
import { registerHollowKnightTextures } from './textures';
import { ROOMS, CHECKPOINTS, type EnemyKind } from './rooms';
import { freshSave, readSave, storeSave, clearSave, readSettings, storeSettings, type RoomId } from './progress';

let save = readSave();
const settings = readSettings();
let started = false;
let audio: AudioContext | undefined;
const hud = document.querySelector<HTMLDivElement>('#hud')!;
const overlay = document.querySelector<HTMLDivElement>('#overlay')!;
const toastElement = document.querySelector<HTMLDivElement>('#toast')!;
let toastTimer = 0;
function toast(message: string) {
  toastElement.textContent = message; toastElement.classList.add('show');
  window.clearTimeout(toastTimer); toastTimer = window.setTimeout(() => toastElement.classList.remove('show'), 3300);
}
function unlockAudio() { try { audio ??= new AudioContext(); void audio.resume(); } catch {} }
function sound(kind: 'jump'|'air'|'dash'|'hit'|'hurt'|'checkpoint'|'unlock'|'step'|'shoot'|'explode'|'explodeBig'|'lava'|'bossDash'|'timetrap'|'shockwave'|'relic'|'mapOpen'|'mapClose'|'bossDefeat') {
  if (settings.muted || !audio || audio.state !== 'running') return;
  if (kind === 'jump' || kind === 'air') { playJumpSound(audio, kind === 'air'); return; }
  if (kind === 'shoot') { playShootSound(audio); return; }
  if (kind === 'explode') { playExplosionSound(audio, false); return; }
  if (kind === 'explodeBig') { playExplosionSound(audio, true); return; }
  if (kind === 'lava') { playLavaThrowSound(audio); return; }
  if (kind === 'bossDash') { playBossDashSound(audio); return; }
  if (kind === 'timetrap') { playTimeTrapSound(audio); return; }
  if (kind === 'shockwave') { playShockwaveSound(audio); return; }
  if (kind === 'relic') { playRelicSound(audio); return; }
  if (kind === 'mapOpen') { playMapOpenSound(audio); return; }
  if (kind === 'mapClose') { playMapCloseSound(audio); return; }
  if (kind === 'bossDefeat') { playBossDefeatChime(audio); return; }
  const notes = ({dash:[340,65,.12],hit:[150,70,.07],hurt:[100,35,.18],checkpoint:[420,680,.26],unlock:[540,1080,.45],step:[65,30,.035]} as Record<string, [number, number, number]>)[kind];
  if (!notes) return;
  const oscillator=audio.createOscillator(), gain=audio.createGain();
  oscillator.type=kind==='hurt'?'triangle':'sine';
  oscillator.frequency.setValueAtTime(notes[0],audio.currentTime); oscillator.frequency.exponentialRampToValueAtTime(notes[1],audio.currentTime+notes[2]);
  gain.gain.setValueAtTime(kind==='step'?.025:.075,audio.currentTime); gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+notes[2]);
  oscillator.connect(gain);gain.connect(audio.destination);oscillator.start();oscillator.stop(audio.currentTime+notes[2]);
  oscillator.onended=()=>{oscillator.disconnect();gain.disconnect();};
}
function formatTime(ms: number) { const s=Math.floor(ms/1000);return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`; }
const idleMap = import.meta.glob('./assets/player/idle/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const walkMap = import.meta.glob('./assets/player/walk/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const runMap = import.meta.glob('./assets/player/run/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const jumpMap = import.meta.glob('./assets/player/jump/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const fallMap = import.meta.glob('./assets/player/fall/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const deathMap = import.meta.glob('./assets/player/death/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const slashMap = import.meta.glob('./assets/player/slash/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const burstMap = import.meta.glob('./assets/player/burst/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const orbMap = import.meta.glob('./assets/player/orb/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const enemyAttackMap = import.meta.glob('./assets/player/attack/*.png', { eager: true, import: 'default' }) as Record<string, string>;

const bossIdleMap = import.meta.glob('./assets/boss/idle/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const bossAttackMap = import.meta.glob('./assets/boss/attack/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const bossAppearMap = import.meta.glob('./assets/boss/appear/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const bossBigMap = import.meta.glob('./assets/boss/big/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const bossOrbAttackMap = import.meta.glob('./assets/boss/orbattack/*.png', { eager: true, import: 'default' }) as Record<string, string>;
const bossTimeballMap = import.meta.glob('./assets/boss/timeball/orb_*.png', { eager: true, import: 'default' }) as Record<string, string>;

type Enemy = {
  kind: EnemyKind;
  body: Phaser.Physics.Arcade.Image;
  visual: Phaser.GameObjects.Container;
  sprite: Phaser.GameObjects.Sprite;
  bar: Phaser.GameObjects.Rectangle;
  maxHp: number;
  hp: number;
  direction: number;
  hurtUntil: number;
  baseY: number;
  state: 'idle' | 'patrol' | 'charging';
  timer: number;
};
type LavaRock = {
  body: Phaser.Physics.Arcade.Image;
  visual: Phaser.GameObjects.Sprite;
  glow: Phaser.GameObjects.Arc;
  createdAt: number;
};
type Projectile = {
  body: Phaser.Physics.Arcade.Image;
  visual: Phaser.GameObjects.Sprite;
  glow: Phaser.GameObjects.Arc;
  vx: number;
  vy: number;
  createdAt: number;
  piercing?: boolean;
  hitTargets?: Set<any>;
};
type Shockwave = {
  body: Phaser.Physics.Arcade.Image;
  visual: Phaser.GameObjects.Sprite;
  glow: Phaser.GameObjects.Arc;
  dir: number;
  expiresAt: number;
};

type Marker = {kind:'checkpoint'|'pickup'|'switch'|'goal'|'exit'|'relic';x:number;y:number;visual:Phaser.GameObjects.Container;exitIndex?:number};

type BossState = 'appear' | 'idle' | 'telegraph_dash' | 'dash' | 'orb_attack' | 'big_cast' | 'telegraph_slam' | 'ground_slam' | 'dead';
type Boss = {
  body: Phaser.Physics.Arcade.Image;
  sprite: Phaser.GameObjects.Sprite;
  visual: Phaser.GameObjects.Container;
  state: BossState;
  stateTimer: number;
  hp: number;
  maxHp: number;
  facing: number;
  hurtUntil: number;
  dashDir: number;
  attackCount: number;
};
type TimeBall = {
  sprite: Phaser.GameObjects.Sprite;
  ring: Phaser.GameObjects.Arc;
  x: number;
  y: number;
  radius: number;
  expiresAt: number;
  lastTick: number;
  targetX?: number;
  targetY?: number;
};

class GameScene extends Phaser.Scene {
  roomId:RoomId='start';
  player!:Phaser.Physics.Arcade.Image;
  visual!:Phaser.GameObjects.Container;
  core!:Phaser.GameObjects.Sprite;
  ground!:Phaser.Physics.Arcade.StaticGroup;
  enemies:Enemy[]=[]; markers:Marker[]=[];
  keys!:Record<string,Phaser.Input.Keyboard.Key>;
  traversal=new Traversal();
  facing=1; health=5; clock=0; dashUntil=0; hurtUntil=0; immuneUntil=0; attackUntil=0; lastAttack=-Infinity;
  lastShoot=-Infinity;
  hitEnemies=new Set<Enemy>();
  active=false; transitioning=false; dead=false; swing?:Phaser.GameObjects.Sprite;
  lastDust=0; lastTrail=0; previousGround=false; lastFall=0; lastHud=0; lastSave=0;
  effectCount=0; diagnostic=false; overlayMode='';
  // Orb companion — orbits the player and is the source of attacks
  orbSprite!:Phaser.GameObjects.Sprite;
  aimDir:{x:number;y:number}={x:1,y:0};  // normalized 8-dir aim
  orbAngle=0; // current angle (radians) of the orb around the player
  projectiles: Projectile[] = [];
  relicsCollected: Set<string> = new Set();
  shockwaves: Shockwave[] = [];
  bossPhase2Triggered = false;
  lastHudKey = '';
  lastNearbyText = '';
  motes: { sprite: Phaser.GameObjects.Arc; vx: number; vy: number; minX: number; maxX: number; minY: number; maxY: number }[] = [];
  playerLantern!: Phaser.GameObjects.Arc;
  orbHalo!: Phaser.GameObjects.Arc;
  bannerTimeout?: number;

  // Boss encounter
  boss?: Boss;
  bossActive=false;
  bossDefeated=false;
  bossHitThisSwing=false;
  timeBalls: TimeBall[] = [];
  lavaRocks: LavaRock[] = [];
  arenaBarrier?: Phaser.GameObjects.Rectangle;
  inTimeTrap=false;

  constructor(){super('Game');}
  preload() {
    const register = (prefix: string, globMap: Record<string, string>) => {
      Object.keys(globMap).sort().forEach((key, index) => {
        this.load.image(`${prefix}_${index}`, globMap[key]);
      });
    };
    register('p_idle', idleMap);
    register('p_walk', walkMap);
    register('p_run', runMap);
    register('p_jump', jumpMap);
    register('p_fall', fallMap);
    register('p_death', deathMap);
    register('fx_slash', slashMap);
    register('fx_burst', burstMap);
    register('e_orb', orbMap);
    register('e_attack', enemyAttackMap);

    register('b_idle', bossIdleMap);
    register('b_attack', bossAttackMap);
    register('b_appear', bossAppearMap);
    register('b_big', bossBigMap);
    register('b_orbattack', bossOrbAttackMap);
    register('b_timeball', bossTimeballMap);
  }
  init(data:{room?:RoomId;spawn?:[number,number];health?:number}) {
    this.roomId=data.room??save.checkpoint; this.health=data.health??5;
    this.enemies=[];this.markers=[];this.traversal=new Traversal();this.facing=1;this.clock=0;
    this.dashUntil=0;this.hurtUntil=0;this.immuneUntil=0;this.attackUntil=0;this.lastAttack=-Infinity;
    this.lastShoot=-Infinity;this.projectiles=[];
    this.shockwaves=[];this.bossPhase2Triggered=false;
    this.hitEnemies=new Set();this.active=false;this.transitioning=false;this.dead=false;this.swing=undefined;
    this.lastDust=0;this.lastTrail=0;this.previousGround=false;this.lastFall=0;this.lastHud=0;this.lastSave=0;this.effectCount=0;
    this.aimDir={x:1,y:0};this.orbAngle=0;
    this.boss=undefined;this.bossActive=false;this.bossDefeated=false;this.bossHitThisSwing=false;
    this.timeBalls=[];this.lavaRocks=[];this.inTimeTrap=false;this.arenaBarrier=undefined;
  }
  createAnimations() {
    // duration: 1000 makes Phaser auto-calculate frameRate = count / 1 = count fps,
    // so every animation plays all its frames in exactly 1 second.
    const makeAnim = (key: string, prefix: string, count: number, repeat = -1, duration = 1000) => {
      if (this.anims.exists(key)) return;
      this.anims.create({
        key,
        frames: Array.from({ length: count }, (_, i) => ({ key: `${prefix}_${i}` })),
        duration,
        repeat,
      });
    };
    makeAnim('player-idle', 'p_idle', 6, -1);
    makeAnim('player-walk', 'p_walk', 4, -1);
    makeAnim('player-run', 'p_run', 4, -1);
    makeAnim('player-jump', 'p_jump', 6, 0);
    makeAnim('player-fall', 'p_fall', 6, -1);
    makeAnim('player-death', 'p_death', 10, 0);
    makeAnim('fx-slash', 'fx_slash', 9, 0);
    makeAnim('fx-burst', 'fx_burst', 6, 0);
    makeAnim('player-orb', 'e_orb', 6, -1);      // orb = player companion
    makeAnim('enemy-attack', 'e_attack', 6, -1);  // enemies use attack anim (looping)

    makeAnim('boss-idle', 'b_idle', Object.keys(bossIdleMap).length, -1, 1000);
    makeAnim('boss-attack', 'b_attack', Object.keys(bossAttackMap).length, 0, 500);
    makeAnim('boss-appear', 'b_appear', Object.keys(bossAppearMap).length, 0, 800);
    makeAnim('boss-big', 'b_big', Object.keys(bossBigMap).length, 0, 1100);
    makeAnim('boss-orbattack', 'b_orbattack', Object.keys(bossOrbAttackMap).length, 0, 600);
    makeAnim('boss-timeball', 'b_timeball', Object.keys(bossTimeballMap).length, -1, 1000);
  }
  create(data:{spawn?:[number,number]}) {
    this.makeTextures(); this.createAnimations(); this.drawRoom();
    const spawn=data.spawn??CHECKPOINTS[this.roomId]??[150,790];
    this.player=this.physics.add.image(spawn[0],spawn[1],'player').setAlpha(0).setDepth(10);
    this.player.setSize(26,42).setOffset(5,5).setMaxVelocity(950,MOVE.maxFall).setCollideWorldBounds(true);
    this.physics.add.collider(this.player,this.ground,undefined,(_player,platform)=>{
      const body=this.player.body as Phaser.Physics.Arcade.Body;
      const ledge=(platform as Phaser.GameObjects.Rectangle).body as Phaser.Physics.Arcade.StaticBody;
      return ledge.height>24 || (body.velocity.y>=0 && body.prev.y+body.height<=ledge.top+8);
    });
    // Anchor sprite foot at collision body bottom (261/300 vertically, 139/300 horizontally)
    this.core=this.add.sprite(0,21,'p_idle_0').setOrigin(139/300, 261/300).setScale(0.32);
    this.core.play('player-idle');
    const shadow=this.add.ellipse(0,20,27,7,0x051015,.6);
    // Orb companion: starts to the right of the player, hovers independently
    this.orbSprite=this.add.sprite(32,-10,'e_orb_0').setScale(0.32).setDepth(13);
    this.orbSprite.play('player-orb');
    this.visual=this.add.container(spawn[0],spawn[1],[shadow,this.core]).setDepth(12);

    // Atmospheric Lumafly lantern lighting halo around player & companion orb
    const isFire = this.roomId === 'lower';
    const lanternColor = isFire ? 0xff7722 : 0x8bf4e7;
    this.playerLantern = this.add.circle(spawn[0], spawn[1], 210, lanternColor, isFire ? 0.09 : 0.07).setDepth(11);
    this.orbHalo = this.add.circle(spawn[0], spawn[1], 85, 0x00f0ff, 0.14).setDepth(12);
    this.showAreaBanner();
    const kb=this.input.keyboard!;
    this.keys=kb.addKeys({
      left:'A',right:'D',left2:'LEFT',right2:'RIGHT',
      up:'W',down:'S',up2:'UP',down2:'DOWN',
      jump:'SPACE',sprint:'SHIFT',
      dash:'L',dash2:'C',dash3:'SHIFT',
      attack:'J',attack2:'Z',
      shoot:'K',shoot2:'X',
      interact:'E',interact2:'ENTER',interact3:'F',
      map:'TAB',map2:'M',
      pause:'ESC',mute:'N',debug:'F3',bossTest:'B',
    }) as typeof this.keys;
    kb.addCapture(['SPACE','UP','DOWN','LEFT','RIGHT','TAB']);
    const onBlur=()=>{if(this.active&&!this.dead)this.showMenu('pause');this.clearInputs();};
    window.addEventListener('blur',onBlur);
    const onVisibility=()=>{if(document.hidden)onBlur();};document.addEventListener('visibilitychange',onVisibility);

    const onPointerMove = (pointer: Phaser.Input.Pointer) => {
      if(!this.active||this.transitioning||this.dead)return;
      const worldPoint=cam.getWorldPoint(pointer.x,pointer.y);
      const dx=worldPoint.x-this.player.x;
      const dy=worldPoint.y-this.player.y;
      const len=Math.hypot(dx,dy);
      if(len>8){
        this.aimDir={x:dx/len, y:dy/len};
      }
    };
    this.input.on('pointermove', onPointerMove);

    const onPointerDown = (pointer: Phaser.Input.Pointer) => {
      if(!this.active||this.transitioning||this.dead)return;
      unlockAudio();
      const worldPoint=cam.getWorldPoint(pointer.x,pointer.y);
      const dx=worldPoint.x-this.player.x;
      const dy=worldPoint.y-this.player.y;
      const len=Math.hypot(dx,dy);
      if(len>8){
        this.aimDir={x:dx/len, y:dy/len};
      }
      if(pointer.button===0){
        // Left click: melee attack
        if(this.clock-this.lastAttack>=MOVE.attackCooldown&&this.clock>=this.dashUntil)this.attack();
      }else if(pointer.button===2){
        // Right click: ranged companion orb shot
        this.shootOrb();
      }
    };
    this.input.on('pointerdown', onPointerDown);

    const onContextMenu=(e:MouseEvent)=>e.preventDefault();
    window.addEventListener('contextmenu',onContextMenu);

    this.events.once('shutdown',()=>{
      window.removeEventListener('blur',onBlur);
      document.removeEventListener('visibilitychange',onVisibility);
      window.removeEventListener('contextmenu',onContextMenu);
      this.input.off('pointermove',onPointerMove);
      this.input.off('pointerdown',onPointerDown);
      if (this.bannerTimeout) window.clearTimeout(this.bannerTimeout);
      this.tweens.killAll();
    });
    const cam=this.cameras.main;
    cam.setZoom(1.35);
    cam.roundPixels=true;cam.setBounds(0,0,1920,960);cam.startFollow(this.player,true,.09,.09);cam.setDeadzone(180,140);cam.setFollowOffset(0,40);cam.fadeIn(220,9,18,26);
    this.physics.world.setBounds(0,0,1920,1100);
    if(!save.discovered.includes(this.roomId)){save.discovered.push(this.roomId);storeSave(save);}
    this.renderHud();
    if(!started)this.showMenu('start');else this.resume();
    if(import.meta.env.DEV) {
      (window as unknown as {__game:any}).__game={
        scene: this,
        snapshot:()=>({room:this.roomId,x:this.player.x,y:this.player.y,vx:this.player.body?.velocity.x,vy:this.player.body?.velocity.y,grounded:this.player.body?.blocked.down,health:this.health,active:this.active,save:structuredClone(save),dash:this.traversal.dashReady,airUsed:this.traversal.airJumpUsed,effects:this.effectCount}),
        warp: (room: RoomId, spawn: [number, number]) => this.changeRoom(room, spawn),
        setPos: (x: number, y: number) => { this.player.setPosition(x, y); this.visual.setPosition(x, y); },
        setVelocity: (vx: number, vy: number) => this.player.setVelocity(vx, vy),
        jump: () => { (this.player.body as Phaser.Physics.Arcade.Body).setVelocityY(-MOVE.jump); this.deform(.83, 1.17); sound('jump'); },
        doubleJump: () => { (this.player.body as Phaser.Physics.Arcade.Body).setVelocityY(-MOVE.jump); this.deform(.83, 1.17); sound('air'); this.wind(this.player.x, this.player.y, 'double'); },
        dash: (dir: number) => { this.facing = dir; this.dashUntil = this.clock + MOVE.dashDuration; (this.player.body as Phaser.Physics.Arcade.Body).setVelocity(dir * MOVE.dashSpeed, 0); sound('dash'); this.wind(this.player.x, this.player.y, 'dash'); },
        slash: (aimX: number, aimY: number) => { this.aimDir = {x: aimX, y: aimY}; this.attack(); },
        shoot: (aimX: number, aimY: number) => { this.aimDir = {x: aimX, y: aimY}; this.shootOrb(); },
        openMap: (tab?: 'map' | 'relics') => this.showMapJournal(tab),
        closeMap: () => this.resume(),
        collectRelic: (key: string) => { this.relicsCollected.add(key); this.renderHud(); sound('relic'); },
        triggerBoss: () => this.triggerBossFight(),
        damageBoss: () => this.damageBoss(),
        defeatBoss: () => this.defeatBoss(),
        showBanner: (title: string, sub: string) => this.showAreaBanner(title, sub),
        setOverdrive: (active: boolean) => {
          if (active) {
            this.relicsCollected.add('lower_1420_570');
            this.relicsCollected.add('well_1620_430');
            this.relicsCollected.add('upper_730_560');
          } else {
            this.relicsCollected.clear();
          }
          this.renderHud();
        }
      };
    }
  }
  showAreaBanner(customTitle?: string, customSub?: string) {
    const banner = document.getElementById('area-banner');
    if (!banner) return;
    const titles: Record<RoomId, { title: string; sub: string }> = {
      start: { title: 'THE ANCIENT THRESHOLD', sub: 'Forgotten Caverns of the Weaver' },
      lower: { title: 'MOLTEN PASSAGE', sub: 'Scorched Veins of the Under-Deep' },
      well: { title: 'ABYSSAL CISTERN', sub: 'Submerged Depths of Still Water' },
      upper: { title: 'HOLLOW RAMPARTS', sub: 'Overlook of the Lost Spire' },
      final: { title: 'SANCTUM OF CHRONOS', sub: 'Domain of the Slumbering Hourglass' },
    };
    const info = customTitle
      ? { title: customTitle, sub: customSub ?? '' }
      : (titles[this.roomId] ?? { title: ROOMS[this.roomId].name, sub: 'The Hollow Realm' });
    banner.innerHTML = `<div class="area-title">${info.title}</div><div class="area-sub">${info.sub}</div>`;
    banner.classList.add('show');
    if (this.bannerTimeout) window.clearTimeout(this.bannerTimeout);
    this.bannerTimeout = window.setTimeout(() => {
      banner.classList.remove('show');
    }, 3200);
  }
  makeTextures() {
    registerHollowKnightTextures(this);
    if(this.textures.exists('player'))return;
    const g=this.add.graphics();
    g.fillStyle(COLORS.player);g.fillRoundedRect(0,0,36,52,9);g.fillStyle(0xd3fff3,.65);g.fillRoundedRect(4,3,28,6,3);g.generateTexture('player',36,52);g.clear();
    g.fillStyle(COLORS.enemy);g.fillRoundedRect(0,0,40,34,7);g.generateTexture('enemy',40,34);g.clear();
    g.fillStyle(0xffffff);g.fillCircle(4,4,4);g.generateTexture('dot',8,8);g.destroy();
  }
  drawRoom() {
    const room=ROOMS[this.roomId];
    this.cameras.main.setBackgroundColor(0x06090e);

    // Deep parallax background gradient
    const bg=this.add.graphics().setScrollFactor(.2);
    const topColor = this.roomId==='lower'?0x160502:this.roomId==='final'?0x080410:0x071118;
    const botColor = this.roomId==='lower'?0x380c05:this.roomId==='final'?0x1e0b2e:room.tint;
    bg.fillGradientStyle(topColor,topColor,botColor,botColor,1);
    bg.fillRect(-500,-400,3500,1800);

    // Background gothic architecture / silhouettes
    const architecture=this.add.graphics().setScrollFactor(.4);
    if(this.roomId==='final'){
      // Vaulted cathedral pillars and arches
      architecture.fillStyle(0x2d1448, 0.25);
      for(let x=100;x<2000;x+=320){
        architecture.fillRect(x,120,60,900);
        architecture.fillCircle(x+30,120,70);
      }
    } else if(this.roomId==='lower'){
      // Jagged volcanic stalagmites
      architecture.fillStyle(0x280e07, 0.45);
      for(let i=0;i<18;i++){
        const x=i*130;
        architecture.fillTriangle(x,900, x+45,550+(i*43)%180, x+90,900);
      }
    } else {
      // Ancient stone columns
      architecture.lineStyle(1,0x53777d,.07);
      for(let x=-80;x<2700;x+=180){
        architecture.strokeRect(x,100,100,1000);
        architecture.lineBetween(x,420,x+100,420);
      }
    }

    const distant=this.add.graphics().setScrollFactor(.6);
    distant.fillStyle(this.roomId==='lower'?0x2a0d06:room.tint,.5);
    for(let i=0;i<16;i++){const x=i*170;const h=180+(i*83)%310;distant.fillRect(x,850-h,70+(i*13)%70,h);}

    const art=this.add.graphics().setDepth(2);
    this.ground=this.physics.add.staticGroup();

    const isVolcano = this.roomId === 'lower';
    const isCathedral = this.roomId === 'final';

    // Dark monolithic platform base tones
    const baseColor = isVolcano ? 0x130a08 : isCathedral ? 0x0e0a18 : 0x090e13;
    const bodyColor = isVolcano ? 0x1f110c : isCathedral ? 0x161224 : 0x121a22;
    const rimGlowColor = isVolcano ? 0xff4d00 : isCathedral ? 0x9333ea : 0x14b8a6;
    const rimHighlight = isVolcano ? 0xffaa00 : isCathedral ? 0xd8b4fe : 0x5eead4;
    const rootColor = isVolcano ? 0x0c0605 : 0x05070a;

    for(const [x,y,w,h] of room.platforms){
      // 1. Solid monolithic bedrock
      art.fillStyle(baseColor, 1);
      art.fillRoundedRect(x, y, w, h, { tl: 5, tr: 5, bl: 3, br: 3 });

      // 2. Subtle internal depth layer
      if (h > 14) {
        art.fillStyle(bodyColor, 0.45);
        art.fillRect(x + 2, y + 4, w - 4, Math.min(18, h - 8));
      }

      // 3. Painterly organic top rim (moss/lichen in caverns, glowing magma in volcanic, rune-gold in sanctum)
      art.fillStyle(rimGlowColor, isVolcano ? 0.75 : 0.6);
      art.fillRect(x, y, w, 3);
      art.fillStyle(rimHighlight, 0.9);
      art.fillRect(x + 4, y, Math.max(10, w - 8), 1.5);

      // Subtle light emission above the platform rim
      if (w >= 60 && !settings.reduced) {
        art.fillStyle(rimHighlight, isVolcano ? 0.12 : 0.06);
        art.fillRect(x + 6, y - 4, w - 12, 4);
      }

      // 4. Natural hanging cave roots / stalactites beneath floating platforms
      if (w >= 70 && y < 820 && h >= 20) {
        const rootCount = Math.floor(w / 45);
        art.fillStyle(rootColor, 0.95);
        for (let r = 0; r < rootCount; r++) {
          const rx = x + 18 + r * 42 + ((r * 17) % 15);
          if (rx < x + w - 12) {
            const rootLen = 8 + ((r * 31 + x) % 18);
            art.fillTriangle(rx - 2, y + h, rx + 2, y + h, rx, y + h + rootLen);
            // Occasional root spore drop
            if ((r + x) % 3 === 0 && !isVolcano) {
              art.fillStyle(0x2dd4bf, 0.4);
              art.fillCircle(rx, y + h + rootLen + 1, 1);
              art.fillStyle(rootColor, 0.95);
            }
          }
        }
      }

      const body=this.add.rectangle(x+w/2,y+h/2,w,h,0x000000,0);
      this.physics.add.existing(body,true);
      this.ground.add(body);
    }

    // Hazards: Room 02 = incandescent magma pools; Other rooms = authentic Hollow Knight crystalline spikes
    for(const [x,y,w,h] of room.hazards){
      if(this.roomId==='lower'){
        this.add.circle(x+w/2, y+h/2, w*0.75, 0xff3b00, 0.16).setDepth(2);
        art.fillGradientStyle(0x7a0c00, 0x7a0c00, 0xff5500, 0xff5500, 1);
        art.fillRect(x, y-2, w, h+14);
        art.lineStyle(2, 0xffea00, 0.9);
        art.lineBetween(x, y-2, x+w, y-2);
      } else {
        this.add.tileSprite(x+w/2, y+h-16, w, 32, 'hk_spikes').setDepth(3);
      }
    }

    for(const [x,y,kind] of room.enemies) this.spawnEnemy(x,y,kind);
    if(room.checkpoint) this.makeMarker('checkpoint', ...room.checkpoint);
    if(room.pickup && !save.doubleJump) this.makeMarker('pickup', ...room.pickup);
    if(room.switch) this.makeMarker('switch', ...room.switch);
    if(room.goal) this.makeMarker('goal', ...room.goal);
    if(room.relic && !this.relicsCollected.has(`${this.roomId}_${room.relic[0]}_${room.relic[1]}`)) {
      this.makeMarker('relic', ...room.relic);
    }
    room.exits.forEach((exit,i) => this.makeMarker('exit', exit.x, exit.y, i));

    // High-performance atmospheric motes/embers (zero tween manager overhead)
    this.motes = [];
    const isFire = this.roomId === 'lower';
    const isFinal = this.roomId === 'final';
    const count = settings.reduced ? 0 : (isFire ? 26 : 18);
    const moteColor = isFire ? 0xff5500 : isFinal ? 0xd8b4fe : 0x8bf4e7;
    for(let i = 0; i < count; i++){
      const mx = (i * 97 + 40) % 1920;
      const my = 150 + (i * 73) % 720;
      const r = 1 + (i % 3) * 0.6;
      const dot = this.add.circle(mx, my, r, moteColor, isFire ? 0.65 : 0.35).setDepth(2);
      this.motes.push({
        sprite: dot,
        vx: (i % 2 === 0 ? 1 : -1) * (14 + (i % 4) * 6),
        vy: -(22 + (i % 5) * 8),
        minX: 0, maxX: 1920,
        minY: 120, maxY: 920
      });
    }
  }
  worldText(x:number,y:number,text:string,color:number,size=11){return this.add.text(x,y,text,{resolution:3,fontFamily:'Cinzel, serif',fontSize:`${size}px`,color:`#${color.toString(16).padStart(6,'0')}`,align:'center',lineSpacing:8}).setOrigin(.5).setDepth(3);}
  makeMarker(kind:Marker['kind'],x:number,y:number,exitIndex?:number){
    const color=kind==='pickup'?COLORS.player:kind==='relic'?0xffd700:COLORS.gold;
    const ring=this.add.circle(0,0,kind==='exit'?28:kind==='relic'?22:20,color,.03).setStrokeStyle(1,color,.6);
    const inner=this.add.container(0, 0);

    if(kind==='checkpoint'){
      const bench = this.add.sprite(0, -6, 'hk_bench').setScale(1);
      const warmLight = this.add.circle(20, -14, 18, 0xffd580, 0.16);
      inner.add([bench, warmLight]);
    }
    else if(kind==='relic'){
      const relic = this.add.sprite(0, -4, 'hk_relic').setScale(1.15);
      const aura = this.add.circle(0, -4, 16, 0x00f0ff, 0.25);
      inner.add([aura, relic]);
      if(!settings.reduced) this.tweens.add({targets:relic, y:relic.y-6, duration:1200, yoyo:true, repeat:-1, ease:'Sine.easeInOut'});
    }
    else if(kind==='pickup'){
      const icon = this.add.graphics();
      icon.lineStyle(2, COLORS.player, 0.85);
      icon.lineBetween(-8,6,0,-5);icon.lineBetween(0,-5,8,6);icon.lineBetween(-8,-3,0,-14);icon.lineBetween(0,-14,8,-3);
      inner.add(icon);
    }
    else if(kind==='switch'){
      const icon = this.add.graphics();
      icon.lineStyle(2, COLORS.gold, 0.85);
      icon.strokeRect(-8,-10,16,20);icon.lineBetween(-4,0,7,-8);
      inner.add(icon);
    }
    else if(kind==='goal'){
      const icon = this.add.graphics();
      icon.lineStyle(2, COLORS.gold, 0.85);
      icon.strokeCircle(0,0,11);icon.lineBetween(0,-19,0,19);icon.lineBetween(-19,0,19,0);
      inner.add(icon);
    }
    else {
      const icon = this.add.graphics();
      icon.lineStyle(2, COLORS.gold, 0.85);
      icon.strokeRect(-9,-20,18,40);icon.lineBetween(-3,0,5,0);
      inner.add(icon);
    }

    const label=kind==='exit'?ROOMS[this.roomId].exits[exitIndex!].label:kind==='checkpoint'?'CHECKPOINT':kind==='pickup'?'SECOND BREATH':kind==='relic'?'TEMPORAL RELIC':kind==='switch'?'CIRCUIT SWITCH':'TIMELINE BEACON';
    const text=this.add.text(0,kind==='exit'?-45:kind==='checkpoint'?28:40,label,{resolution:3,fontFamily:'Cinzel, serif',fontSize:'11px',fontStyle:'bold',color:'#e8dec8',align:'center'}).setOrigin(.5);
    const visual=this.add.container(x,y,[ring,inner,text]).setDepth(4);
    this.markers.push({kind,x,y,visual,exitIndex});
    if(!settings.reduced)this.tweens.add({targets:ring,alpha:.4,scale:1.15,duration:1500,yoyo:true,repeat:-1});
  }
  spawnEnemy(x:number,y:number,kind:EnemyKind='patrol'){
    if(kind==='bomber'){
      const body=this.physics.add.image(x,y,'enemy').setAlpha(0).setSize(28,28);
      (body.body as Phaser.Physics.Arcade.Body).setAllowGravity(false);
      const sprite=this.add.sprite(0,0,'hk_wisp').setScale(1);
      const glow=this.add.circle(0,0,22,0xff3b00,0.22);
      this.tweens.add({targets:glow,scale:1.35,alpha:0.08,duration:400,yoyo:true,repeat:-1});
      this.tweens.add({targets:sprite,y:-4,duration:650,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
      const bar=this.add.rectangle(-10,-22,20,2,0xff5500,0.85).setOrigin(0,0.5);
      const track=this.add.rectangle(0,-22,20,2,0x3d4149);
      const visual=this.add.container(x,y,[glow,sprite,track,bar]).setDepth(8);
      this.enemies.push({kind:'bomber',body,visual,sprite,bar,maxHp:2,hp:2,direction:1,hurtUntil:0,baseY:y,state:'idle',timer:this.clock});
    }else if(kind==='hurler'){
      const body=this.physics.add.image(x,y,'enemy').setAlpha(0).setSize(44,40).setMaxVelocity(300,920);
      this.physics.add.collider(body,this.ground);
      const sprite=this.add.sprite(0,-8,'e_attack_0').setScale(0.9).setTint(0xe64a19);
      sprite.play('enemy-attack');
      const bar=this.add.rectangle(-16,-32,32,3,0xff3b00,0.85).setOrigin(0,0.5);
      const track=this.add.rectangle(0,-32,32,3,0x3d4149);
      const visual=this.add.container(x,y,[sprite,track,bar]).setDepth(8);
      this.enemies.push({kind:'hurler',body,visual,sprite,bar,maxHp:4,hp:4,direction:-1,hurtUntil:0,baseY:y,state:'patrol',timer:this.clock+2200});
    }else if(kind==='spawner'){
      const body=this.physics.add.image(x,y,'enemy').setAlpha(0).setSize(52,60);
      this.physics.add.collider(body,this.ground);
      (body.body as Phaser.Physics.Arcade.Body).setImmovable(true);
      const sprite=this.add.sprite(0,0,'hk_magma_spawner').setScale(1);
      const glow=this.add.circle(0,4,16,0xff4400,0.22);
      this.tweens.add({targets:glow,scale:1.3,alpha:0.1,duration:500,yoyo:true,repeat:-1});
      const bar=this.add.rectangle(-20,-38,40,3,0xff4400,0.9).setOrigin(0,0.5);
      const track=this.add.rectangle(0,-38,40,3,0x1a2128);
      const visual=this.add.container(x,y,[glow,sprite,track,bar]).setDepth(7);
      this.enemies.push({kind:'spawner',body,visual,sprite,bar,maxHp:6,hp:6,direction:0,hurtUntil:0,baseY:y,state:'idle',timer:this.clock+3500});
    }else{
      const body=this.physics.add.image(x,y,'enemy').setAlpha(0).setSize(36,30).setMaxVelocity(300,920);
      this.physics.add.collider(body,this.ground);
      const sprite=this.add.sprite(0,-4,'e_orb_0').setScale(0.65);
      sprite.play('player-orb');
      const bar=this.add.rectangle(-12,-26,24,2,COLORS.enemy,.8).setOrigin(0,.5);
      const track=this.add.rectangle(0,-26,24,2,0x3d4149);
      const visual=this.add.container(x,y,[sprite,track,bar]).setDepth(8);
      this.enemies.push({kind:'patrol',body,visual,sprite,bar,maxHp:3,hp:3,direction:-1,hurtUntil:0,baseY:y,state:'patrol',timer:0});
    }
  }
  pressed(...names:string[]){return names.some(name=>Phaser.Input.Keyboard.JustDown(this.keys[name]));}
  clearInputs(){this.input.keyboard?.resetKeys();this.traversal.jumpQueued=-Infinity;}
  resume(){
    if(this.overlayMode==='map') sound('mapClose');
    started=true;this.active=true;this.overlayMode='';overlay.classList.remove('open');overlay.innerHTML='';
    this.physics.resume();this.tweens.resumeAll();this.clearInputs();document.querySelector<HTMLCanvasElement>('canvas')?.focus();
  }
  showMapJournal(activeTab: 'map' | 'relics' = 'map') {
    this.active = false;
    this.physics.pause();
    this.tweens.pauseAll();
    this.clearInputs();
    this.overlayMode = 'map';
    overlay.classList.add('open');
    sound('mapOpen');

    const discovered = save.discovered;
    const curRoom = this.roomId;

    const roomDetails: Record<RoomId, {
      roman: string;
      title: string;
      sub: string;
      bench?: string;
      relic?: string;
      ability?: string;
      gate?: string;
      boss?: string;
    }> = {
      final: {
        roman: 'CHAMBER V',
        title: 'SANCTUM OF CHRONOS',
        sub: 'Domain of the Slumbering Hourglass',
        boss: this.bossDefeated ? '💀 CHRONOS (VANQUISHED ★)' : '💀 CHRONOS (LORD OF TIME)',
        ability: '⌛ TIMELINE BEACON',
      },
      start: {
        roman: 'CHAMBER I',
        title: 'THE ANCIENT THRESHOLD',
        sub: 'Forgotten Caverns of the Weaver',
        bench: '🪑 WEAVER BENCH (RESTED)',
        gate: '🚪 SANCTUM ARCH &bull; HIGH LOOP',
      },
      upper: {
        roman: 'CHAMBER IV',
        title: 'HOLLOW RAMPARTS',
        sub: 'Overlook of the Lost Spire',
        gate: save.shortcut ? '⚙️ SHORTCUT CIRCUIT (OPEN ★)' : '⚙️ SHORTCUT CIRCUIT (LOCKED)',
        relic: this.relicsCollected.has('upper_730_560') ? '✦ WEAVER CHRONOMETER (RESTORED ★)' : '✦ WEAVER CHRONOMETER (UNFOUND)',
      },
      lower: {
        roman: 'CHAMBER II',
        title: 'MOLTEN PASSAGE',
        sub: 'Scorched Veins of the Under-Deep',
        relic: this.relicsCollected.has('lower_1420_570') ? '✦ CREST OF THE PYRE (RESTORED ★)' : '✦ CREST OF THE PYRE (UNFOUND)',
        gate: '🔥 MAGMA PITS &bull; WISP CALDERA',
      },
      well: {
        roman: 'CHAMBER III',
        title: 'ABYSSAL CISTERN',
        sub: 'Submerged Depths of Still Water',
        bench: '🪑 CISTERN BENCH (RESTED)',
        ability: save.doubleJump ? '🪶 SECOND BREATH WINGS (ACQUIRED ★)' : '🪶 SECOND BREATH WINGS (UNCLAIMED)',
        relic: this.relicsCollected.has('well_1620_430') ? '✦ EYE OF THE DEEP (RESTORED ★)' : '✦ EYE OF THE DEEP (UNFOUND)',
      },
    };

    const renderChamber = (id: RoomId) => {
      const isKnown = discovered.includes(id);
      const isActive = curRoom === id;
      const info = roomDetails[id];

      if (!isKnown) {
        return `
          <div class="chamber-card unknown">
            <div style="font-family:'Cinzel',serif;font-size:16px;color:#6b5d4f;letter-spacing:4px">? ? ?</div>
            <div style="font-family:'EB Garamond',serif;font-style:italic;font-size:11.5px;color:#5a6870;margin-top:4px">Uncharted Cavern</div>
          </div>
        `;
      }

      return `
        <div class="chamber-card discovered ${isActive ? 'active' : ''}">
          ${isActive ? '<span class="vessel-badge">◆ YOU ARE HERE ◆</span>' : ''}
          <div class="chamber-title">${info.roman} &bull; ${info.title}</div>
          <div class="chamber-sub">${info.sub}</div>
          <div class="landmark-list">
            ${info.boss ? `<div class="landmark-pill ${this.bossDefeated ? 'completed' : 'unlocked'}">${info.boss}</div>` : ''}
            ${info.bench ? `<div class="landmark-pill completed">${info.bench}</div>` : ''}
            ${info.ability ? `<div class="landmark-pill ${save.doubleJump ? 'completed' : 'unlocked'}">${info.ability}</div>` : ''}
            ${info.relic ? `<div class="landmark-pill ${info.relic.includes('RESTORED') ? 'unlocked' : ''}">${info.relic}</div>` : ''}
            ${info.gate ? `<div class="landmark-pill">${info.gate}</div>` : ''}
          </div>
        </div>
      `;
    };

    const mapHtml = `
      <div class="parchment-map-grid">
        ${renderChamber('final')}
        ${renderChamber('start')}
        ${renderChamber('upper')}
        <div style="display:flex;align-items:center;justify-content:center;color:#856d56;font-family:'Cinzel',serif;font-size:9.5px;letter-spacing:2px">
          <span>&uarr; CHRONOS VAULT</span>
        </div>
        ${renderChamber('lower')}
        ${renderChamber('well')}
      </div>
      <div class="map-legend">
        <span>🪑 Checkpoint Bench</span>
        <span>✦ Temporal Relic</span>
        <span>🪶 Second Breath</span>
        <span>⚙️ Shortcut Circuit</span>
        <span>💀 Chronos Boss</span>
        <span>◆ Vessel Presence</span>
      </div>
    `;

    const r1 = this.relicsCollected.has('lower_1420_570');
    const r2 = this.relicsCollected.has('well_1620_430');
    const r3 = this.relicsCollected.has('upper_730_560');

    const relicsHtml = `
      <div class="relics-grid">
        <div class="relic-card ${r1 ? 'collected' : ''}">
          <div class="relic-header">
            <span class="relic-title">CREST OF THE PYRE</span>
            <span class="relic-badge ${r1 ? 'restored' : 'dormant'}">${r1 ? 'RESTORED ★' : 'DORMANT'}</span>
          </div>
          <div class="relic-loc">ORIGIN &bull; MOLTEN PASSAGE</div>
          <div class="relic-desc">A petrified volcanic carapace enclosing primeval heat. Snatched from the charred ceiling above bubbling magma chasms.</div>
        </div>

        <div class="relic-card ${r2 ? 'collected' : ''}">
          <div class="relic-header">
            <span class="relic-title">EYE OF THE DEEP</span>
            <span class="relic-badge ${r2 ? 'restored' : 'dormant'}">${r2 ? 'RESTORED ★' : 'DORMANT'}</span>
          </div>
          <div class="relic-loc">ORIGIN &bull; ABYSSAL CISTERN</div>
          <div class="relic-desc">A deep-water gem that pulses in rhythm with the vessel's heart. Retains the chill of stagnant waters beneath the ruined cistern.</div>
        </div>

        <div class="relic-card ${r3 ? 'collected' : ''}">
          <div class="relic-header">
            <span class="relic-title">WEAVER'S CHRONOMETER</span>
            <span class="relic-badge ${r3 ? 'restored' : 'dormant'}">${r3 ? 'RESTORED ★' : 'DORMANT'}</span>
          </div>
          <div class="relic-loc">ORIGIN &bull; HOLLOW RAMPARTS</div>
          <div class="relic-desc">A clockwork pendulum carved from celestial brass. Its balance wheel oscillates counter to worldly decay and distortion.</div>
        </div>
      </div>

      <div class="overdrive-banner">
        ${this.relicsCollected.size >= 3
          ? '★ TEMPORAL OVERDRIVE UNLEASHED &bull; Companion orb projects a radiant 3-way piercing pulse with every cast!'
          : `✦ OVERDRIVE AWAKENING (${this.relicsCollected.size}/3) &bull; Reclaim all three relics across the caverns to unlock the orb's piercing triad blast.`}
      </div>

      <div class="stats" style="margin-top:20px">
        <div><strong>${formatTime(save.elapsed)}</strong><span>EXPEDITION TIME</span></div>
        <div><strong>${save.deaths}</strong><span>SHELL FRACTURES</span></div>
        <div><strong>${save.discovered.length}/5</strong><span>CAVERNS MAPPED</span></div>
        <div><strong>${this.relicsCollected.size}/3</strong><span>RELICS RECLAIMED</span></div>
      </div>
    `;

    overlay.innerHTML = `
      <div class="panel parchment-panel">
        <div class="parchment-header">
          <div class="panel-glyph">✦ ❖ ✦</div>
          <h2>CHART OF THE SUBTERRANEAN VOID</h2>
          <div class="lore-sub">Etched upon ancient moth-silk by the Cartographer &bull; Press TAB or ESC to stow</div>
        </div>
        <div class="journal-nav">
          <button class="${activeTab === 'map' ? 'primary' : ''}" id="btn-tab-map">🗺️ CARTOGRAPHY</button>
          <button class="${activeTab === 'relics' ? 'primary' : ''}" id="btn-tab-relics">📜 CHRONICLES &amp; RELICS (${this.relicsCollected.size}/3)</button>
          <button id="btn-close-map" style="margin-left:auto;">✕ STOW MAP [ESC]</button>
        </div>
        <div class="journal-content">
          ${activeTab === 'map' ? mapHtml : relicsHtml}
        </div>
      </div>
    `;

    const btnMap = overlay.querySelector<HTMLButtonElement>('#btn-tab-map');
    const btnRelics = overlay.querySelector<HTMLButtonElement>('#btn-tab-relics');
    const btnClose = overlay.querySelector<HTMLButtonElement>('#btn-close-map');

    if (btnMap) btnMap.onclick = () => this.showMapJournal('map');
    if (btnRelics) btnRelics.onclick = () => this.showMapJournal('relics');
    if (btnClose) btnClose.onclick = () => this.resume();
  }
  showMenu(mode:'start'|'pause'|'dead'|'complete'|'restart'){
    this.active=false;this.physics.pause();this.tweens.pauseAll();this.clearInputs();this.overlayMode=mode;overlay.classList.add('open');
    const titles: Record<string, string> = {
      start: 'TEMPORAL RIFT',
      pause: 'PAUSED',
      dead: 'VESSEL SHATTERED',
      complete: 'TIMELINE RESTORED',
      restart: 'SEVER THE THREAD?'
    };
    const subtitles: Record<string, string> = {
      start: 'Descend into the forgotten depths of the temporal spire. Cleanse the molten rifts and overthrow Chronos.',
      pause: 'Time stands still within the rift.',
      dead: 'Thy shell hath fallen to the shadows. Awaken once more at the temporal threshold.',
      complete: 'The ancient chronometer falls quiet. Light returns to the caverns below.',
      restart: 'Resetting shall wipe all recorded memories and return thee to the origin.'
    };
    const title = titles[mode];
    const subtitle = subtitles[mode];

    const controlsHtml = `
      <div class="controls-card">
        <div class="controls-card-title">VESSEL DISCIPLINE &bull; KEYBOARD CONTROLS</div>
        <div class="controls-grid">
          <div>
            <div class="control-group-title">STYLE I &bull; WASD + J K L</div>
            <div class="control-row"><span>Move &amp; Aim</span><div><span class="keycap">W</span> <span class="keycap">A</span> <span class="keycap">S</span> <span class="keycap">D</span></div></div>
            <div class="control-row"><span>Jump / Air Leap</span><span class="keycap">SPACE</span></div>
            <div class="control-row"><span>Orb Nail Slash</span><span class="keycap">J</span></div>
            <div class="control-row"><span>Orb Energy Cast</span><span class="keycap">K</span></div>
            <div class="control-row"><span>Mothwing Dash</span><div><span class="keycap">L</span> / <span class="keycap">SHIFT</span></div></div>
            <div class="control-row"><span>Commune / Enter</span><span class="keycap">E</span></div>
          </div>
          <div>
            <div class="control-group-title">STYLE II &bull; ARROWS + Z X C</div>
            <div class="control-row"><span>Move &amp; Aim</span><div><span class="keycap">←</span> <span class="keycap">↑</span> <span class="keycap">↓</span> <span class="keycap">→</span></div></div>
            <div class="control-row"><span>Jump / Air Leap</span><span class="keycap">SPACE</span></div>
            <div class="control-row"><span>Orb Nail Slash</span><span class="keycap">Z</span></div>
            <div class="control-row"><span>Orb Energy Cast</span><span class="keycap">X</span></div>
            <div class="control-row"><span>Mothwing Dash</span><div><span class="keycap">C</span> / <span class="keycap">SHIFT</span></div></div>
            <div class="control-row"><span>Commune / Enter</span><span class="keycap">ENTER</span></div>
          </div>
        </div>
        <div class="controls-note">
          <span>✦ Mouse supported: Left Click = Slash &bull; Right Click = Cast</span>
          <span><span class="keycap">TAB</span> or <span class="keycap">M</span> Cartography &amp; Relics</span>
          <span><span class="keycap">B</span> Instant Boss Warp</span>
        </div>
      </div>
    `;

    overlay.innerHTML = `
      <div class="panel">
        <div class="panel-glyph">✦ ❖ ✦</div>
        <h2>${title}</h2>
        <div class="lore-sub">${subtitle}</div>
        ${mode === 'start' || mode === 'pause' ? controlsHtml : ''}
        ${mode === 'restart' ? '<p style="color:#d8e5e7;margin:16px 0">Clear all saved progress and return to the start room?</p>' : ''}
        ${mode === 'complete' ? `
          <div class="stats">
            <div><strong>${formatTime(save.elapsed)}</strong><span>TIME ELAPSED</span></div>
            <div><strong>${save.deaths}</strong><span>SHELL DEATHS</span></div>
            <div><strong>${save.discovered.length}/5</strong><span>ROOMS EXPLORED</span></div>
            <div><strong>${this.relicsCollected.size}/3</strong><span>RELICS RESTORED</span></div>
          </div>
          <p style="color:#9bf1df;font-style:italic;margin-top:12px">All temporal rifts sealed. Chronos has been vanquished!</p>
        ` : ''}
        ${mode === 'start' || mode === 'pause' ? `
          <div class="settings">
            <label><input type="checkbox" id="setting-muted"> Mute sound (N)</label>
            <label><input type="checkbox" id="setting-reduced"> Reduced effects</label>
            <label><input type="checkbox" id="setting-shake"> Screen shake</label>
          </div>
        ` : ''}
        <div class="buttons"></div>
      </div>
    `;
    const buttons = overlay.querySelector('.buttons')!;
    const button = (label: string, action: () => void, primary = false) => {
      const b = document.createElement('button');
      b.textContent = label;
      b.className = primary ? 'primary' : '';
      b.onclick = () => { unlockAudio(); action(); };
      buttons.append(b);
    };
    if (mode === 'start') {
      button(save.elapsed > 0 ? 'CONTINUE EXPLORING' : 'ENTER THE RIFT', () => this.resume(), true);
      button('CARTOGRAPHY & RELICS [TAB]', () => this.showMapJournal('map'));
      button('WARP TO CHRONOS', () => { this.resume(); this.changeRoom('final', [880, 790]); });
      if (save.elapsed > 0) button('NEW ODYSSEY', () => this.showMenu('restart'));
    }
    if (mode === 'pause') {
      button('RESUME', () => this.resume(), true);
      button('CARTOGRAPHY & RELICS [TAB]', () => this.showMapJournal('map'));
      button('WARP TO CHRONOS', () => { this.resume(); this.changeRoom('final', [880, 790]); });
      button('RESTART RUN', () => this.showMenu('restart'));
    }
    if (mode === 'dead') button('ARISE AT BENCH', () => this.respawn(), true);
    if (mode === 'complete') {
      button('CONTINUE EXPLORING', () => this.resume(), true);
      button('CARTOGRAPHY & RELICS [TAB]', () => this.showMapJournal('map'));
      button('COMMENCE ANEW', () => this.showMenu('restart'));
    }
    if (mode === 'restart') {
      button('CONFIRM RESET', () => { clearSave(); save = freshSave(); started = true; this.scene.restart({ room: 'start' }); }, true);
      button('RETURN', () => this.showMenu(started ? 'pause' : 'start'));
    }
    for (const key of ['muted', 'reduced', 'shake'] as const) {
      const input = overlay.querySelector<HTMLInputElement>(`#setting-${key}`);
      if (input) {
        input.checked = settings[key];
        input.onchange = () => { settings[key] = input.checked; storeSettings(settings); };
      }
    }
    overlay.querySelector<HTMLButtonElement>('button')?.focus();
    storeSave(save);
  }
  update(_time:number,delta:number){
    if(this.pressed('mute')){settings.muted=!settings.muted;storeSettings(settings);toast(settings.muted?'Sound off':'Sound on');if(!settings.muted)unlockAudio();}
    if(this.pressed('map','map2')){
      if(this.overlayMode==='map') this.resume();
      else if(this.active&&!this.dead&&!this.transitioning) this.showMapJournal('map');
    }
    if(this.pressed('debug')){this.diagnostic=!this.diagnostic;this.renderHud();}
    if(this.pressed('bossTest')){this.changeRoom('final',[880,790]);toast('WARPING TO CHRONOS BOSS ARENA');}
    if(this.pressed('pause')&&!this.transitioning&&!this.dead){
      if(this.overlayMode==='map') this.resume();
      else if(this.active) this.showMenu('pause');
      else if(this.overlayMode==='pause') this.resume();
    }
    if(!this.active||this.transitioning||this.dead||this.physics.world.isPaused)return;
    const dt=Math.min(delta,35);this.clock+=dt;if(!save.completed)save.elapsed+=dt;
    const now=this.clock, body=this.player.body as Phaser.Physics.Arcade.Body;
    const grounded=body.blocked.down;
    this.traversal.landed(grounded,now);
    if(grounded&&!this.previousGround){if(this.lastFall>160){this.wind(this.player.x,body.bottom,'land',Math.min(1,this.lastFall/900));this.deform(1.14,.84);if(this.lastFall>500)sound('step');}}
    this.previousGround=grounded;this.lastFall=body.velocity.y;
    // Horizontal movement: A/D or Arrow Left/Right
    const axis=Number(this.keys.right.isDown||this.keys.right2.isDown)-Number(this.keys.left.isDown||this.keys.left2.isDown);
    if(axis&&now>=this.hurtUntil&&now>=this.dashUntil)this.facing=axis;
    // 8-directional aim from WASD or Arrow Keys
    const aimX=Number(this.keys.right.isDown||this.keys.right2.isDown)-Number(this.keys.left.isDown||this.keys.left2.isDown);
    const aimY=Number(this.keys.down.isDown||this.keys.down2.isDown)-Number(this.keys.up.isDown||this.keys.up2.isDown);
    if(aimX!==0||aimY!==0){
      const len=Math.sqrt(aimX*aimX+aimY*aimY);
      this.aimDir={x:aimX/len,y:aimY/len};
    }
    // Smoothly rotate the orb angle towards the aim direction
    const targetAngle=Math.atan2(this.aimDir.y,this.aimDir.x);
    let angleDiff=targetAngle-this.orbAngle;
    // Wrap angle difference to [-PI, PI]
    while(angleDiff>Math.PI)angleDiff-=Math.PI*2;
    while(angleDiff<-Math.PI)angleDiff+=Math.PI*2;
    this.orbAngle+=angleDiff*Math.min(1,dt*0.018);
    // Position the orb sprite in world space (orbit radius 42px around player)
    const ORB_RADIUS=42;
    const orbWorldX=this.player.x+Math.cos(this.orbAngle)*ORB_RADIUS;
    const orbWorldY=this.player.y+Math.sin(this.orbAngle)*ORB_RADIUS;
    this.orbSprite.setPosition(orbWorldX,orbWorldY);
    if(this.playerLantern) this.playerLantern.setPosition(this.player.x, this.player.y);
    if(this.orbHalo) this.orbHalo.setPosition(orbWorldX, orbWorldY);
    if(this.pressed('jump'))this.traversal.queueJump(now);
    if(now<this.hurtUntil){body.setAllowGravity(true);}
    else if(now<this.dashUntil){body.setAllowGravity(false);body.setVelocity(this.facing*MOVE.dashSpeed,0);if(body.blocked.left||body.blocked.right)this.dashUntil=now;}
    else {
      body.setAllowGravity(true);
      const speedMult = this.inTimeTrap ? 0.35 : 1;
      const target=axis*(grounded&&this.keys.sprint.isDown?MOVE.sprint:MOVE.speed)*speedMult;
      const acceleration=axis?(grounded?MOVE.acceleration:MOVE.airAcceleration):(grounded?MOVE.braking:MOVE.airAcceleration*.55);
      body.setVelocityX(approach(body.velocity.x,target,acceleration*dt/1000));
      const jump=this.traversal.consumeJump(now,save.doubleJump);
      if(jump){
        const jumpPwr = this.inTimeTrap ? MOVE.jump * 0.72 : MOVE.jump;
        body.setVelocityY(-jumpPwr);this.previousGround=false;sound(jump==='air'?'air':'jump');this.deform(.83,1.17);this.wind(this.player.x,body.bottom,jump==='air'?'double':'jump',1,0x000000);
      }
      if(Phaser.Input.Keyboard.JustUp(this.keys.jump)&&body.velocity.y<-260)body.setVelocityY(-260);
      if(body.velocity.y>0)body.setGravityY(320);else body.setGravityY(0);
      if(this.pressed('dash','dash2','dash3')&&this.traversal.consumeDash(now)){
        this.dashUntil=now+MOVE.dashDuration;body.setAllowGravity(false);body.setVelocity(this.facing*MOVE.dashSpeed,0);this.attackUntil=0;sound('dash');this.wind(this.player.x,this.player.y,'dash',1,0x000000);this.deform(1.25,.77);
        const burst=this.add.sprite(this.player.x-this.facing*16,this.player.y+10,'fx_burst_0').setOrigin(0.5,0.5).setScale(0.32).setDepth(11).setFlipX(this.facing<0);
        burst.play('fx-burst');burst.once('animationcomplete',()=>burst.destroy());
      }
      if(this.pressed('attack','attack2')&&now-this.lastAttack>=MOVE.attackCooldown&&now>=this.dashUntil)this.attack();
      if(this.pressed('shoot','shoot2')&&now>=this.dashUntil)this.shootOrb();
    }
    if(this.attackUntil>now)this.checkAttack();
    this.updateProjectiles(dt);
    this.updateEnemies(dt);
    this.updateLavaRocks();
    this.updateTimeBalls(dt);
    this.updateBoss(dt);
    this.updateShockwaves(dt);
    if(audio) updateMusic(audio, settings.muted, this.bossActive);
    if(this.roomId==='final'&&!this.bossActive&&!this.bossDefeated){
      this.triggerBossFight();
    }
    // Update lightweight atmospheric motes
    for(let i=0; i<this.motes.length; i++){
      const m = this.motes[i];
      m.sprite.x += m.vx * (dt / 1000);
      m.sprite.y += m.vy * (dt / 1000);
      if(m.sprite.y < m.minY) m.sprite.y = m.maxY;
      if(m.sprite.x < m.minX) m.sprite.x = m.maxX;
      else if(m.sprite.x > m.maxX) m.sprite.x = m.minX;
    }
    this.checkHazards();
    this.checkMarkers(this.pressed('interact','interact2','interact3'));
    if(this.player.y>1010)this.damage(1,0,true);
    this.visual.setPosition(this.player.x,this.player.y);
    if(this.dead){
      this.core.play('player-death',true);
    }else if(now<this.dashUntil){
      this.core.play('player-run',true);
    }else if(!grounded){
      if(body.velocity.y<-30)this.core.play('player-jump',true);
      else this.core.play('player-fall',true);
    }else{
      const speed=Math.abs(body.velocity.x);
      if(speed>25){
        if(this.keys.sprint.isDown&&speed>MOVE.speed*.9)this.core.play('player-run',true);
        else this.core.play('player-walk',true);
      }else{
        this.core.play('player-idle',true);
      }
    }
    this.core.setFlipX(this.facing<0);
    this.core.setTint(now<this.immuneUntil&&Math.floor(now/70)%2===0?0xffaaaa:this.inTimeTrap?0xd8b4fe:0xffffff);
    this.visual.alpha=now<this.immuneUntil&&Math.floor(now/80)%2===0?.4:1;
    // Grounded art stays upright so rotation cannot push a corner below the floor.
    this.core.rotation=grounded?0:Phaser.Math.Clamp(body.velocity.x*.0001,-.07,.07);
    if(grounded&&Math.abs(body.velocity.x)>100&&now-this.lastDust>(this.keys.sprint.isDown?60:110)){
      this.lastDust=now;if(this.keys.sprint.isDown)this.wind(this.player.x,this.player.y+8,'sprint');
    }
    if(now<this.dashUntil&&now-this.lastTrail>24){this.lastTrail=now;this.afterimage();}
    const cam=this.cameras.main;cam.followOffset.x=approach(cam.followOffset.x,-this.facing*65,dt*.3);
    if(now-this.lastHud>90){this.lastHud=now;this.renderHud();}
    if(now-this.lastSave>2500){this.lastSave=now;storeSave(save);}
  }
  deform(x:number,y:number){if(settings.reduced)return;this.tweens.killTweensOf(this.core);this.core.setScale(x*.32,y*.32);this.tweens.add({targets:this.core,scaleX:.32,scaleY:.32,duration:170,ease:'Sine.easeOut'});}
  attack(){
    this.lastAttack=this.clock;this.attackUntil=this.clock+MOVE.attackDuration;this.hitEnemies.clear();this.bossHitThisSwing=false;
    // Slash spawns at the orb's current world position, rotated to match aim direction
    const ox=this.orbSprite.x, oy=this.orbSprite.y;
    const slashAngle=Math.atan2(this.aimDir.y,this.aimDir.x);
    const slash=this.add.sprite(ox,oy,'fx_slash_0')
      .setOrigin(0.1,0.5).setScale(0.22).setDepth(14)
      .setRotation(slashAngle);
    this.swing=slash;
    slash.play('fx-slash');slash.once('animationcomplete',()=>slash.destroy());sound('hit');
  }
  checkAttack(){
    // Keep the slash anchored to the orb while it plays
    if(this.swing?.active)this.swing.setPosition(this.orbSprite.x,this.orbSprite.y);
    // Hitbox covers only the slash blade (extending from the orb in the aim direction),
    // not the orb itself — the orb only initiates the attack.
    const ox=this.orbSprite.x, oy=this.orbSprite.y;
    const dir=this.aimDir;
    const ang=Math.atan2(dir.y,dir.x);
    const cs=Math.cos(ang), sn=Math.sin(ang);
    // Blade segment: starts a short distance from the orb, extends forward in aim direction.
    const s0=10, s1=100, w=22;
    const corners=[{x:s0,y:-w/2},{x:s1,y:-w/2},{x:s1,y:w/2},{x:s0,y:w/2}];
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    for(const c of corners){
      const wx=ox+c.x*cs-c.y*sn;
      const wy=oy+c.x*sn+c.y*cs;
      if(wx<minX)minX=wx;if(wy<minY)minY=wy;
      if(wx>maxX)maxX=wx;if(wy>maxY)maxY=wy;
    }
    const hit=new Phaser.Geom.Rectangle(minX,minY,maxX-minX,maxY-minY);
    if(this.boss&&this.boss.hp>0&&this.boss.state!=='appear'&&this.boss.state!=='dead'&&!this.bossHitThisSwing){
      if(Phaser.Geom.Intersects.RectangleToRectangle(hit,this.boss.body.getBounds())){
        this.bossHitThisSwing=true;
        this.damageBoss();
      }
    }
    for(const enemy of this.enemies){
      if(enemy.hp<=0||this.hitEnemies.has(enemy))continue;
      if(Phaser.Geom.Intersects.RectangleToRectangle(hit,enemy.body.getBounds())){
        this.hitEnemies.add(enemy);
        enemy.hp--;
        const fullBar=enemy.kind==='spawner'?40:enemy.kind==='hurler'?32:20;
        enemy.bar.width=Math.max(0,(enemy.hp/enemy.maxHp)*fullBar);
        enemy.hurtUntil=this.clock+230;
        if(enemy.kind!=='spawner'){
          enemy.body.setVelocity(this.aimDir.x*230,this.aimDir.y*230-80);
        }
        this.burst(enemy.body.x,enemy.body.y,8,COLORS.enemy,'dash');sound('hit');
        this.impact(.0012,65,25);
        if(enemy.hp<=0){
          if(enemy.kind==='bomber'){
            this.burst(enemy.body.x,enemy.body.y,16,0xff5500,'jump');
            sound('explode');
          }else if(enemy.kind==='spawner'){
            this.burst(enemy.body.x,enemy.body.y,30,0xff3b00,'jump');
            this.ring(enemy.body.x,enemy.body.y,0xff5500);
            sound('explodeBig');
            toast('MAGMA SPAWNER CRUSHED!');
          }
          enemy.visual.destroy();
          enemy.body.disableBody(true,true);
        }
      }
    }
  }

  shootOrb(){
    const now=this.clock;
    if(now-this.lastShoot<300||now<this.dashUntil)return;
    this.lastShoot=now;
    unlockAudio();
    sound('shoot');

    const ox=this.orbSprite.x, oy=this.orbSprite.y;
    const dir=this.aimDir;
    const speed=660;
    const baseAngle=Math.atan2(dir.y,dir.x);

    const isOverdrive = this.relicsCollected.size >= 3;
    const angles = isOverdrive ? [baseAngle - 0.22, baseAngle, baseAngle + 0.22] : [baseAngle];

    for(const a of angles){
      const vx = Math.cos(a) * speed;
      const vy = Math.sin(a) * speed;

      const body = this.physics.add.image(ox, oy, 'dot').setSize(16, 16).setAlpha(0);
      (body.body as Phaser.Physics.Arcade.Body).setAllowGravity(false);
      body.setVelocity(vx, vy);

      const tint = isOverdrive ? 0xffea00 : 0x9bf1df;
      const glowColor = isOverdrive ? 0xffaa00 : 0x00f0ff;
      const glow = this.add.circle(ox, oy, isOverdrive ? 15 : 12, glowColor, 0.55).setDepth(13);
      const visual = this.add.sprite(ox, oy, 'e_orb_0').setScale(isOverdrive ? 0.28 : 0.24).setTint(tint).setDepth(14);
      visual.play('player-orb');

      const proj: Projectile = { body, visual, glow, vx, vy, createdAt: now, piercing: isOverdrive, hitTargets: new Set() };
      this.physics.add.collider(body, this.ground, () => {
        this.destroyProjectile(proj, true);
      });
      this.projectiles.push(proj);
    }

    this.tweens.add({
      targets:this.orbSprite,
      scaleX:isOverdrive?0.52:0.45,scaleY:isOverdrive?0.52:0.45,
      duration:80,yoyo:true,ease:'Quad.easeOut'
    });
  }

  destroyProjectile(proj:Projectile,hitTerrain=false){
    if(!proj.body.active&&!proj.visual.active)return;
    if(hitTerrain){
      this.burst(proj.body.x,proj.body.y,6,proj.piercing?0xffea00:0x9bf1df,'land');
      sound('step');
    }
    proj.visual.destroy();
    proj.glow.destroy();
    proj.body.disableBody(true,true);
  }

  updateProjectiles(_dt:number){
    const now=this.clock;
    const remaining:Projectile[]=[];

    for(const p of this.projectiles){
      if(!p.body.active||now-p.createdAt>1600){
        this.destroyProjectile(p);
        continue;
      }

      p.visual.setPosition(p.body.x,p.body.y);
      p.glow.setPosition(p.body.x,p.body.y);

      if(Math.random()<(p.piercing?0.45:0.25)){
        this.burst(p.body.x,p.body.y,1,p.piercing?0xffea00:0x8bf4e7,'land');
      }

      let hit=false;

      // Check boss collision
      if(this.boss&&this.boss.hp>0&&this.boss.state!=='appear'&&this.boss.state!=='dead'){
        if(Phaser.Geom.Intersects.RectangleToRectangle(p.body.getBounds(),this.boss.body.getBounds())){
          if(!p.hitTargets?.has(this.boss)){
            p.hitTargets?.add(this.boss);
            this.damageBoss();
            this.burst(p.body.x,p.body.y,12,p.piercing?0xffea00:0x8bf4e7,'jump');
            if(!p.piercing||(p.hitTargets && p.hitTargets.size>=2)){
              this.destroyProjectile(p);
              hit=true;
            }
          }
        }
      }

      if(hit)continue;

      // Check enemies
      for(const enemy of this.enemies){
        if(enemy.hp<=0)continue;
        if(Phaser.Geom.Intersects.RectangleToRectangle(p.body.getBounds(),enemy.body.getBounds())){
          if(p.hitTargets?.has(enemy))continue;
          p.hitTargets?.add(enemy);

          enemy.hp--;
          const fullBar=enemy.kind==='spawner'?40:enemy.kind==='hurler'?32:20;
          enemy.bar.width=Math.max(0,(enemy.hp/enemy.maxHp)*fullBar);
          enemy.hurtUntil=this.clock+200;
          if(enemy.kind!=='spawner'){
            enemy.body.setVelocity(p.vx*0.35,-100);
          }
          this.burst(enemy.body.x,enemy.body.y,8,p.piercing?0xffea00:0x8bf4e7,'dash');
          sound('hit');
          this.impact(0.001,50,15);

          if(enemy.hp<=0){
            if(enemy.kind==='bomber'){
              this.burst(enemy.body.x,enemy.body.y,20,0xff5500,'jump');
              sound('explode');
            }else if(enemy.kind==='spawner'){
              this.burst(enemy.body.x,enemy.body.y,35,0xff3b00,'jump');
              this.ring(enemy.body.x,enemy.body.y,0xff5500);
              sound('explodeBig');
              toast('MAGMA SPAWNER CRUSHED!');
            }
            enemy.visual.destroy();
            enemy.body.disableBody(true,true);
          }

          if(!p.piercing||(p.hitTargets && p.hitTargets.size>=2)){
            this.destroyProjectile(p);
            hit=true;
            break;
          }
        }
      }

      if(!hit){
        remaining.push(p);
      }
    }
    this.projectiles=remaining;
  }

  updateEnemies(_dt:number){
    const px=this.player.x, py=this.player.y;
    for(const e of this.enemies){
      if(e.hp<=0)continue;
      const b=e.body.body as Phaser.Physics.Arcade.Body;
      const dist=Phaser.Math.Distance.Between(e.body.x,e.body.y,px,py);

      if(e.kind==='bomber'){
        // Flying Wisp Bomber
        if(e.state==='idle'){
          e.body.y=e.baseY+Math.sin(this.clock*0.004+e.baseY)*20;
          e.body.setVelocityX(e.direction*35);
          if(b.blocked.left)e.direction=1;else if(b.blocked.right)e.direction=-1;
          if(dist<260){
            e.state='charging';
            e.timer=this.clock+1300;
            sound('air');
            toast('KAMIKAZE WISP IGNITED!');
          }
        }else if(e.state==='charging'){
          const ang=Math.atan2(py-e.body.y,px-e.body.x);
          e.body.setVelocity(Math.cos(ang)*270,Math.sin(ang)*270);
          e.sprite.setTint(Math.floor(this.clock/70)%2===0?0xffff00:0xff1100);
          if(this.clock>=e.timer||dist<34){
            this.burst(e.body.x,e.body.y,24,0xff4400,'dash');
            this.ring(e.body.x,e.body.y,0xffaa00);
            sound('explode');
            this.impact(0.015,200,30);
            if(dist<80)this.damage(1,px<e.body.x?-1:1);
            e.hp=0;e.visual.destroy();e.body.disableBody(true,true);
            continue;
          }
        }
      }else if(e.kind==='hurler'){
        // Molten Lava Hurler
        if(this.clock>e.timer&&dist<580){
          e.direction=px<e.body.x?-1:1;
          e.body.setVelocityX(0);
          this.spawnLavaRock(e.body.x+e.direction*15,e.body.y-15,px,py);
          sound('lava');
          e.timer=this.clock+3200;
        }else if(this.clock>e.hurtUntil){
          if(b.blocked.left)e.direction=1;else if(b.blocked.right)e.direction=-1;
          if(b.blocked.down){
            const foot=new Phaser.Geom.Rectangle(e.body.x+e.direction*30,e.body.y+20,3,10);
            if(!ROOMS[this.roomId].platforms.some(([x,y,w,h])=>Phaser.Geom.Intersects.RectangleToRectangle(foot,new Phaser.Geom.Rectangle(x,y,w,h))))e.direction*=-1;
          }
          b.setVelocityX(e.direction*55);
        }
      }else if(e.kind==='spawner'){
        // Stationary Magma Hive
        b.setVelocity(0,0);
        if(this.clock>e.timer){
          const activeBombers=this.enemies.filter(other=>other.kind==='bomber'&&other.hp>0).length;
          if(activeBombers<3){
            this.spawnEnemy(e.body.x,e.body.y-40,'bomber');
            this.burst(e.body.x,e.body.y-40,14,0xff4400,'jump');
            sound('step');
          }
          e.timer=this.clock+5000;
        }
      }else{
        // Standard patroller
        if(this.clock>e.hurtUntil){
          if(b.blocked.left)e.direction=1;else if(b.blocked.right)e.direction=-1;
          if(b.blocked.down){
            const foot=new Phaser.Geom.Rectangle(e.body.x+e.direction*27,e.body.y+17,3,10);
            if(!ROOMS[this.roomId].platforms.some(([x,y,w,h])=>Phaser.Geom.Intersects.RectangleToRectangle(foot,new Phaser.Geom.Rectangle(x,y,w,h))))e.direction*=-1;
          }
          b.setVelocityX(e.direction*66);
        }
      }

      e.visual.setPosition(e.body.x,e.body.y);
      e.visual.alpha=this.clock<e.hurtUntil?.5:1;
      if(e.kind!=='spawner')e.sprite.setFlipX(e.direction<0);
      if(e.kind!=='bomber'&&e.kind!=='spawner')e.sprite.play('enemy-attack',true);
      if(e.kind!=='bomber'&&Phaser.Geom.Intersects.RectangleToRectangle(this.player.getBounds(),e.body.getBounds())){
        this.damage(1,px<e.body.x?-1:1);
      }
    }
  }
  checkHazards(){
    for(const [x,y,w,h] of ROOMS[this.roomId].hazards){
      if(Phaser.Geom.Intersects.RectangleToRectangle(this.player.getBounds(),new Phaser.Geom.Rectangle(x,y,w,h))){this.damage(2,this.player.x<x+w/2?-1:1,true);break;}
    }
  }
  damage(amount:number,direction:number,recover=false){
    if(this.clock<this.immuneUntil||this.dead||this.transitioning)return;
    this.health=Math.max(0,this.health-amount);this.immuneUntil=this.clock+MOVE.invulnerability;this.hurtUntil=this.clock+MOVE.hurtDuration;this.dashUntil=0;this.attackUntil=0;
    this.traversal.jumpQueued=-Infinity;(this.player.body as Phaser.Physics.Arcade.Body).setAllowGravity(true);this.player.setVelocity(direction*270,-220);
    this.burst(this.player.x,this.player.y,12,COLORS.enemy,'dash');sound('hurt');this.impact(amount===1?.011:.019,amount===1?210:300,amount===1?45:65);this.renderHud();
    if(this.health<=0){this.die();return;}
    if(recover){this.transitioning=true;this.time.delayedCall(190,()=>{if(this.scene.isActive())this.scene.restart({room:save.checkpoint,spawn:CHECKPOINTS[save.checkpoint],health:this.health});});}
  }
  impact(intensity:number,duration:number,pause:number){
    if(settings.reduced)return;
    if(settings.shake)this.cameras.main.shake(duration,intensity,true);
    // Scene clock and physics freeze together during a very short impact pause.
    this.physics.pause();this.time.delayedCall(pause,()=>{if(this.active&&!this.dead&&!this.transitioning)this.physics.resume();});
  }
  die(){this.dead=true;save.deaths++;storeSave(save);this.player.setVelocity(0,0);this.physics.pause();this.impact(.024,320,0);this.time.delayedCall(300,()=>this.showMenu('dead'));}
  respawn(){this.scene.restart({room:save.checkpoint,spawn:CHECKPOINTS[save.checkpoint]});}
  checkMarkers(interact:boolean){
    let nearby='';
    for(const marker of this.markers){
      if(!marker.visual.active||Math.abs(this.player.x-marker.x)>65||Math.abs(this.player.y-marker.y)>75)continue;
      if(marker.kind==='pickup'){
        save.doubleJump=true;storeSave(save);marker.visual.destroy();this.ring(marker.x,marker.y,COLORS.player);this.burst(marker.x,marker.y,24,COLORS.player,'jump');sound('unlock');toast('SECOND BREATH — press Space again in the air.');continue;
      }
      if(marker.kind==='relic'){
        const relicKey=`${this.roomId}_${marker.x}_${marker.y}`;
        if(!this.relicsCollected.has(relicKey)){
          this.relicsCollected.add(relicKey);
          marker.visual.destroy();
          this.ring(marker.x,marker.y,0xffd700);
          this.burst(marker.x,marker.y,32,0xffea00,'jump');
          sound('relic');
          this.impact(0.012, 220, 25);
          if(this.relicsCollected.size>=3){
            toast('TEMPORAL OVERDRIVE AWAKENED! 3-way piercing pulse.');
          }else{
            toast(`TEMPORAL RELIC RESTORED (${this.relicsCollected.size}/3)`);
          }
          this.renderHud();
        }
        continue;
      }
      if(marker.kind==='checkpoint'){
        nearby='E / ENTER  /  REST & SAVE';if(interact){save.checkpoint=this.roomId;this.health=5;storeSave(save);this.ring(marker.x,marker.y,COLORS.gold);sound('checkpoint');toast('CHECKPOINT');}
      }
      if(marker.kind==='switch'){
        nearby=save.shortcut?'CIRCUIT OPEN':'E / ENTER  /  OPEN THE CIRCUIT';if(interact&&!save.shortcut){save.shortcut=true;storeSave(save);this.ring(marker.x,marker.y,COLORS.gold);sound('unlock');toast('CIRCUIT OPEN');}
      }
      if(marker.kind==='goal'){
        const ready=this.bossDefeated||save.completed;
        nearby=!ready?'LOCKED — DEFEAT CHRONOS':(save.completed?'E / ENTER  /  REVIEW RUN':'E / ENTER  /  RESTORE TIMELINE');
        if(interact){
          if(!ready){toast('DEFEAT CHRONOS TO RESTORE THE TIMELINE');}
          else{save.completed=true;storeSave(save);sound('unlock');this.showMenu('complete');}
        }
      }
      if(marker.kind==='exit'){
        const exit=ROOMS[this.roomId].exits[marker.exitIndex!];
        const locked=(exit.gate==='jump'&&!save.doubleJump)||(exit.gate==='shortcut'&&!save.shortcut);
        nearby=locked?'LOCKED':'E / ENTER  /  '+exit.label;
        if(interact){if(locked)toast('LOCKED');else this.changeRoom(exit.to,exit.spawn);}
      }
    }
    if(nearby !== this.lastNearbyText){
      this.lastNearbyText = nearby;
      const hint=document.getElementById('nearby');if(hint)hint.textContent=nearby;
    }
  }
  changeRoom(room:RoomId,spawn:[number,number]){
    if(this.transitioning)return;this.transitioning=true;this.player.setVelocity(0,0);this.physics.pause();this.clearInputs();storeSave(save);
    if(this.bossActive) setMusicBoss(false);
    this.cameras.main.fadeOut(160,9,18,26);this.time.delayedCall(165,()=>this.scene.restart({room,spawn,health:this.health}));
  }
  /** Tapered, animated air ribbons. Movement uses no dust or dot emitters. */
  wind(x:number,y:number,kind:'jump'|'double'|'dash'|'sprint'|'land',power=1,color=0xd9fff6){
    if(settings.reduced||this.effectCount>75)return;
    this.effectCount++;
    const art=this.add.graphics().setPosition(x,y).setDepth(13);
    const phase={t:0};
    const direction=this.facing;
    const double=kind==='double', horizontal=kind==='dash'||kind==='sprint';
    const count=double?4:kind==='dash'?4:2;
    const duration=double?480:kind==='dash'?340:kind==='land'?260:300;
    const draw=()=>{
      art.clear();
      const fade=Math.pow(1-phase.t,1.4);
      for(let ribbon=0;ribbon<count;ribbon++){
        const points:{x:number;y:number}[]=[];
        const segments=28;
        for(let i=0;i<=segments;i++){
          const t=i/segments;
          let px:number,py:number;
          if(horizontal){
            const length=kind==='dash'?150:65;
            px=-direction*(12+t*length+phase.t*35);
            py=(ribbon-(count-1)/2)*11+Math.sin(t*Math.PI)*((ribbon%2?1:-1)*9);
          }else if(kind==='land'){
            const side=ribbon===0?-1:1;
            px=side*(8+t*(38+power*24)+phase.t*24);
            py=-Math.sin(t*Math.PI)*(7+power*5)*(1-phase.t);
          }else{
            const radius=(double?53:29)+ribbon*(double?8:6)+phase.t*(double?26:14);
            const angle=(-.82+t*.9+ribbon*.085+phase.t*.35)*Math.PI;
            px=Math.cos(angle)*radius;
            py=Math.sin(angle)*(double?23:10)-phase.t*(double?30:12)+ribbon*3-(double?Math.pow(1-t,2)*28:0);
          }
          points.push({x:px,y:py});
        }
        for(let i=1;i<points.length;i++){
          const taper=Math.sin((i/points.length)*Math.PI);
          const alpha=fade*taper*(double?.88:kind==='sprint'?.3:.65);
          art.lineStyle((double?2.6:1.7)*(.25+taper*.75),color,alpha);
          art.lineBetween(points[i-1].x,points[i-1].y,points[i].x,points[i].y);
        }
      }
    };
    draw();
    this.tweens.add({targets:phase,t:1,duration,ease:'Linear',onUpdate:draw,onComplete:()=>{art.destroy();this.effectCount--;}});
  }
  burst(x:number,y:number,count:number,color:number,kind:'land'|'jump'|'dash'){
    if(settings.reduced)count=Math.min(count,2);
    for(let i=0;i<count&&this.effectCount<100;i++){
      this.effectCount++;const dot=this.add.image(x,y,'dot').setTint(color).setAlpha(.55).setScale(.3+Math.random()*.4).setDepth(9);
      const dx=(Math.random()-.5)*(kind==='dash'?110:75),dy=kind==='jump'?Math.random()*45:-(8+Math.random()*32);
      this.tweens.add({targets:dot,x:x+dx,y:y+dy,alpha:0,scale:0,duration:230+Math.random()*190,onComplete:()=>{dot.destroy();this.effectCount--;}});
    }
  }
  ring(x:number,y:number,color:number){if(settings.reduced)return;const ring=this.add.circle(x,y,12,color,0).setStrokeStyle(2,color,.8).setDepth(13);this.tweens.add({targets:ring,scaleX:3,scaleY:.7,alpha:0,duration:380,onComplete:()=>ring.destroy()});}
  afterimage(){
    if(settings.reduced||this.effectCount>90)return;
    this.effectCount++;
    const image=this.add.sprite(this.player.x,this.player.y+21,this.core.texture.key,this.core.frame.name)
      .setOrigin(139/300,261/300).setScale(0.32).setFlipX(this.facing<0).setTint(COLORS.player).setAlpha(.35).setDepth(7);
    this.tweens.add({targets:image,alpha:0,x:image.x-this.facing*18,duration:180,onComplete:()=>{image.destroy();this.effectCount--;}});
  }
  renderHud(){
    const ready=this.traversal.dashReady&&this.clock-this.traversal.lastDash>=MOVE.dashCooldown;
    const bossHp = this.boss?.hp ?? -1;
    const hudKey = `${this.health}_${ready}_${this.roomId}_${save.doubleJump}_${bossHp}_${this.relicsCollected.size}_${this.diagnostic}`;
    if (hudKey === this.lastHudKey && !this.diagnostic) return;
    this.lastHudKey = hudKey;

    const bossBar=(this.boss&&this.boss.hp>0&&this.boss.state!=='appear')
      ?`<div class="boss-bar-wrap"><div class="boss-name">CHRONOS, THE TIME KEEPER</div><div class="boss-bar-outer"><div class="boss-bar-fill" style="width:${Math.max(0,(this.boss.hp/this.boss.maxHp)*100)}%"></div></div></div>`
      :'';
    const relicStatus = this.relicsCollected.size >= 3 ? '★ OVERDRIVE' : `✦ RELICS: ${this.relicsCollected.size}/3`;
    hud.innerHTML=`<div class="hud-top"><div><div class="vitality-container"><div class="soul-orb-vessel" title="Soul Orb Companion"></div><div class="health" aria-label="Health: ${this.health}/5">${Array.from({length:5},(_,i)=>`<span class="pip ${i>=this.health?'empty':''}"></span>`).join('')}</div></div><div class="hud-sub-status"><span class="charge ${ready?'':'off'}">${ready?'◆ DASH READY':'◇ CHARGING'}</span>${save.doubleJump?'<span style="color:#d8b4fe">✦ SECOND BREATH</span>':''}<span class="hud-relics">${relicStatus}</span></div></div>${bossBar}<div class="hud-right" id="hud-minimap-btn" title="Open Map &amp; Chronicles [TAB / M]"><div class="hud-room">${ROOMS[this.roomId].name} <span style="font-size:8px;color:#d4b476;opacity:0.85;margin-left:4px">[TAB]</span></div><div class="room-map" aria-label="Discovered rooms">${(['start','lower','well','upper','final'] as RoomId[]).map((id,i)=>`<span class="room-cell ${this.roomId===id?'active':''} ${save.discovered.includes(id)?'':'unknown'}" title="${save.discovered.includes(id)?ROOMS[id].name:'Undiscovered room'}"></span>${i<4?'<span style="color:#4c6069;font-size:8px">—</span>':''}`).join('')}</div></div></div><div id="nearby" class="hud-hint"></div>${this.diagnostic?`<div id="debug">${this.roomId} | ${Math.round(this.player.x)}, ${Math.round(this.player.y)}\nFPS ${Math.round(this.game.loop.actualFps)} | effects ${this.effectCount}\nDash ${ready} | air jump used ${this.traversal.airJumpUsed}\nEnemies ${this.enemies.filter(e=>e.hp>0).length} | total HP ${this.enemies.reduce((n,e)=>n+Math.max(0,e.hp),0)}</div>`:''}`;

    const minimapBtn = document.getElementById('hud-minimap-btn');
    if (minimapBtn) {
      minimapBtn.onclick = () => {
        if (this.active && !this.dead && !this.transitioning) this.showMapJournal('map');
      };
    }
  }
  triggerBossFight() {
    if (this.bossActive || this.bossDefeated || this.roomId !== 'final') return;
    this.bossActive = true;
    setMusicBoss(true);
    this.arenaBarrier = this.add.rectangle(820, 720, 16, 240, 0x8b5cf6, 0.75).setDepth(6);
    this.physics.add.existing(this.arenaBarrier, true);
    this.ground.add(this.arenaBarrier);
    this.tweens.add({ targets: this.arenaBarrier, alpha: 0.35, duration: 800, yoyo: true, repeat: -1 });

    const bx = 1280, by = 680;
    const body = this.physics.add.image(bx, by, 'player').setAlpha(0).setSize(75, 120);
    (body.body as Phaser.Physics.Arcade.Body).setAllowGravity(false);
    const sprite = this.add.sprite(0, 0, 'b_idle_0').setScale(0.42).setOrigin(0.5, 0.5);
    sprite.play('boss-idle');
    const fxAppear = this.add.sprite(0, 0, 'b_appear_0').setScale(0.65).setOrigin(0.5, 0.5);
    fxAppear.play('boss-appear');
    fxAppear.once('animationcomplete', () => fxAppear.destroy());
    const visual = this.add.container(bx, by, [sprite, fxAppear]).setDepth(9);

    this.boss = {
      body,
      sprite,
      visual,
      state: 'appear',
      stateTimer: this.clock + 900,
      hp: 20,
      maxHp: 20,
      facing: -1,
      hurtUntil: 0,
      dashDir: -1,
      attackCount: 0,
    };

    sound('checkpoint');
    this.impact(0.012, 350, 0);
    toast('CHRONOS, THE TIME KEEPER EMERGES');
    this.renderHud();
  }

  updateBoss(dt: number) {
    if (!this.boss || this.boss.hp <= 0 || this.boss.state === 'dead') return;
    const b = this.boss;
    const now = this.clock;
    const px = this.player.x;
    b.facing = px < b.body.x ? -1 : 1;
    b.sprite.setFlipX(b.facing < 0);

    b.visual.setPosition(b.body.x, b.body.y);
    b.visual.alpha = now < b.hurtUntil && Math.floor(now / 60) % 2 === 0 ? 0.4 : 1;
    if (now >= b.hurtUntil) b.sprite.clearTint();

    if (b.state !== 'appear' && Phaser.Geom.Intersects.RectangleToRectangle(this.player.getBounds(), b.body.getBounds())) {
      this.damage(1, px < b.body.x ? -1 : 1);
    }

    if (b.state === 'appear') {
      if (now >= b.stateTimer) {
        b.state = 'idle';
        b.stateTimer = now + 1800;
        b.sprite.play('boss-idle', true);
      }
    } else if (b.state === 'idle') {
      b.sprite.play('boss-idle', true);
      const targetY = 690 + Math.sin(now * 0.003) * 28;
      b.body.y = approach(b.body.y, targetY, 45 * dt / 1000);
      const idealX = px + (b.facing > 0 ? -240 : 240);
      const clampedIdealX = Phaser.Math.Clamp(idealX, 900, 1750);
      const curVx = (b.body.body as Phaser.Physics.Arcade.Body)?.velocity.x ?? 0;
      b.body.setVelocityX(approach(curVx, (clampedIdealX - b.body.x) * 1.5, 300 * dt / 1000));

      if (now >= b.stateTimer) {
        b.body.setVelocity(0, 0);
        b.attackCount++;
        const isEnraged = b.hp <= b.maxHp * 0.55;

        if (isEnraged && !this.bossPhase2Triggered) {
          this.bossPhase2Triggered = true;
          toast('CHRONOS ENRAGES — TEMPORAL FISSURES AWAKEN!');
          this.impact(0.024, 500, 60);
          this.cameras.main.flash(450, 200, 100, 255);
          sound('timetrap');
        }

        if (isEnraged && b.attackCount % 4 === 0) {
          b.state = 'telegraph_slam';
          b.stateTimer = now + 750;
          b.sprite.setTint(0xba55d3);
          sound('air');
          this.tweens.add({ targets: b.body, y: 530, duration: 400, ease: 'Quad.easeOut' });
        } else if (isEnraged && b.attackCount % 3 === 0) {
          b.state = 'big_cast';
          b.stateTimer = now + 1200;
          b.sprite.play('boss-big');
          sound('unlock');
          this.impact(0.014, 400, 0);
          this.tweens.add({ targets: b.body, x: 1350, y: 550, duration: 350 });
        } else if (b.attackCount % 2 === 1) {
          b.state = 'telegraph_dash';
          b.stateTimer = now + (isEnraged ? 380 : 500);
          b.dashDir = px < b.body.x ? -1 : 1;
          b.sprite.setTint(0xffaa33);
          sound('step');
        } else {
          b.state = 'orb_attack';
          b.stateTimer = now + 700;
          b.sprite.play('boss-orbattack');
          this.spawnTimeBall(b.body.x, b.body.y - 10, px, this.player.y);
        }
      }
    } else if (b.state === 'telegraph_dash') {
      b.body.setVelocity(0, 0);
      if (now >= b.stateTimer) {
        b.state = 'dash';
        b.stateTimer = now + 550;
        b.sprite.play('boss-attack');
        b.sprite.clearTint();
        b.body.setVelocityX(b.dashDir * 780);
        sound('bossDash');
        this.wind(b.body.x, b.body.y, 'dash', 1.4, 0xffa040);
      }
    } else if (b.state === 'dash') {
      if (Math.random() < 0.4) this.wind(b.body.x, b.body.y, 'dash', 0.8, 0xff7722);
      if (now >= b.stateTimer || b.body.x < 870 || b.body.x > 1820) {
        b.body.setVelocity(0, 0);
        b.state = 'idle';
        b.stateTimer = now + 1400;
        b.sprite.play('boss-idle', true);
      }
    } else if (b.state === 'orb_attack') {
      b.body.setVelocity(0, 0);
      if (now >= b.stateTimer) {
        b.state = 'idle';
        b.stateTimer = now + 1600;
        b.sprite.play('boss-idle', true);
      }
    } else if (b.state === 'big_cast') {
      b.body.setVelocity(0, 0);
      if (now >= b.stateTimer) {
        this.spawnTimeBall(960, 770);
        this.spawnTimeBall(1320, 770);
        this.spawnTimeBall(1680, 770);
        toast('CHRONOS WARPS TIME ACROSS THE ARENA');
        sound('unlock');
        this.impact(0.016, 450, 0);
        b.state = 'idle';
        b.stateTimer = now + 1800;
        b.sprite.play('boss-idle', true);
      }
    } else if (b.state === 'telegraph_slam') {
      b.body.setVelocity(0, 0);
      if (now >= b.stateTimer) {
        b.state = 'ground_slam';
        b.sprite.clearTint();
        b.sprite.play('boss-attack');
        b.body.setVelocity(0, 950);
        sound('bossDash');
      }
    } else if (b.state === 'ground_slam') {
      if (Math.random() < 0.4) this.wind(b.body.x, b.body.y, 'jump', 1.2, 0xd977f8);
      if (b.body.y >= 750) {
        b.body.y = 750;
        b.body.setVelocity(0, 0);
        b.state = 'idle';
        b.stateTimer = now + 1200;
        b.sprite.play('boss-idle', true);
        this.spawnShockwaves(b.body.x, 775);
        this.burst(b.body.x, 775, 28, 0xd977f8, 'land');
        this.burst(b.body.x, 775, 20, 0xffaa00, 'land');
        this.ring(b.body.x, 775, 0xd977f8);
      }
    }
  }

  spawnTimeBall(startX: number, startY: number, targetX?: number, targetY?: number) {
    const sprite = this.add.sprite(startX, startY, 'b_timeball_0').setScale(0.32).setDepth(10);
    sprite.play('boss-timeball');
    const ring = this.add.circle(startX, startY, 65, 0xd977f8, 0).setStrokeStyle(1.5, 0xd977f8, 0.65).setDepth(10);
    this.tweens.add({ targets: ring, scale: 1.18, alpha: 0.3, duration: 600, yoyo: true, repeat: -1 });

    const ball: TimeBall = {
      sprite,
      ring,
      x: startX,
      y: startY,
      radius: 70,
      expiresAt: this.clock + 6000,
      lastTick: 0,
      targetX,
      targetY,
    };
    this.timeBalls.push(ball);

    if (targetX !== undefined && targetY !== undefined) {
      this.tweens.add({
        targets: [ball, sprite, ring],
        x: targetX,
        y: targetY,
        duration: 1200,
        ease: 'Cubic.easeOut',
      });
    }
    sound('air');
  }

  updateTimeBalls(_dt: number) {
    const now = this.clock;
    this.inTimeTrap = false;
    const remaining: TimeBall[] = [];

    for (const ball of this.timeBalls) {
      if (now >= ball.expiresAt) {
        this.burst(ball.x, ball.y, 16, 0xd977f8, 'jump');
        ball.sprite.destroy();
        ball.ring.destroy();
        continue;
      }
      remaining.push(ball);

      const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, ball.x, ball.y);
      if (dist < ball.radius) {
        this.inTimeTrap = true;
        if (now - ball.lastTick >= 1100) {
          ball.lastTick = now;
          this.damage(1, this.player.x < ball.x ? -1 : 1, false);
          sound('timetrap');
          toast('TRAPPED IN TIME ANOMALY');
        }
      }
    }
    this.timeBalls = remaining;
  }

  damageBoss() {
    if (!this.boss || this.boss.hp <= 0 || this.boss.state === 'appear' || this.boss.state === 'dead') return;
    const now = this.clock;
    if (now < this.boss.hurtUntil) return;

    this.boss.hp--;
    this.boss.hurtUntil = now + 240;
    this.boss.sprite.setTint(0xff4444);
    sound('hit');
    this.impact(0.011, 150, 40);
    this.burst(this.boss.body.x, this.boss.body.y, 14, 0xffa040, 'dash');
    this.renderHud();

    if (this.boss.hp <= 0) {
      this.defeatBoss();
    }
  }

  defeatBoss() {
    if (!this.boss) return;
    this.boss.state = 'dead';
    this.bossDefeated = true;
    this.bossActive = false;
    setMusicBoss(false);

    for (const ball of this.timeBalls) {
      this.burst(ball.x, ball.y, 14, 0xd977f8, 'jump');
      ball.sprite.destroy();
      ball.ring.destroy();
    }
    this.timeBalls = [];

    for (const s of this.shockwaves) {
      s.visual.destroy();
      s.glow.destroy();
      s.body.disableBody(true, true);
    }
    this.shockwaves = [];

    if (this.arenaBarrier) {
      this.ground.remove(this.arenaBarrier, true, true);
      this.arenaBarrier = undefined;
    }

    const bx = this.boss.body.x, by = this.boss.body.y;
    this.ring(bx, by, 0xffd700);
    this.burst(bx, by, 60, 0xffd700, 'jump');
    this.impact(0.035, 800, 120);
    sound('bossDefeat');

    // Cinematic white flash & camera shake
    this.cameras.main.flash(850, 255, 255, 255);
    this.cameras.main.shake(700, 0.016);

    this.boss.visual.destroy();
    this.boss.body.disableBody(true, true);
    this.boss = undefined;

    toast('TIME UNBOUND — CHRONOS VANQUISHED');
    this.showAreaBanner('TIME UNBOUND', 'The Slumbering Hourglass Hath Shattered');
    this.renderHud();
  }

  spawnShockwaves(originX: number, originY: number) {
    unlockAudio();
    sound('shockwave');
    this.impact(0.018, 280, 0);

    for (const dir of [-1, 1]) {
      const body = this.physics.add.image(originX + dir * 30, originY, 'dot').setSize(24, 38).setAlpha(0);
      (body.body as Phaser.Physics.Arcade.Body).setAllowGravity(false);
      body.setVelocityX(dir * 380);

      const glow = this.add.circle(originX + dir * 30, originY, 20, 0xd977f8, 0.35).setDepth(10);
      const visual = this.add.sprite(originX + dir * 30, originY, 'hk_shockwave').setDepth(10);
      visual.setFlipX(dir < 0);
      this.tweens.add({ targets: visual, scaleY: 1.25, duration: 150, yoyo: true, repeat: -1 });

      this.shockwaves.push({
        body,
        visual,
        glow,
        dir,
        expiresAt: this.clock + 2400
      });
    }
  }

  updateShockwaves(_dt: number) {
    const now = this.clock;
    const remaining: Shockwave[] = [];

    for (const s of this.shockwaves) {
      if (now >= s.expiresAt || !s.body.active) {
        s.visual.destroy();
        s.glow.destroy();
        s.body.disableBody(true, true);
        continue;
      }

      s.visual.setPosition(s.body.x, s.body.y);
      s.glow.setPosition(s.body.x, s.body.y);

      if (Math.random() < 0.3) {
        this.burst(s.body.x, s.body.y + 12, 1, 0xd977f8, 'land');
      }

      if (Phaser.Geom.Intersects.RectangleToRectangle(this.player.getBounds(), s.body.getBounds())) {
        this.damage(1, s.dir);
        this.burst(s.body.x, s.body.y, 8, 0xd977f8, 'jump');
        s.visual.destroy();
        s.glow.destroy();
        s.body.disableBody(true, true);
        continue;
      }

      remaining.push(s);
    }
    this.shockwaves = remaining;
  }

  spawnLavaRock(x: number, y: number, targetX: number, targetY: number) {
    const body = this.physics.add.image(x, y, 'dot').setSize(18, 18).setAlpha(0);
    const glow = this.add.circle(x, y, 16, 0xff3b00, 0.4).setDepth(11);
    const visual = this.add.sprite(x, y, 'hk_lava_rock').setScale(1.2).setDepth(12);

    const dx = targetX - x;
    const vx = Phaser.Math.Clamp(dx * 1.5, -420, 420);
    body.setVelocity(vx, -380);
    (body.body as Phaser.Physics.Arcade.Body).setGravityY(450);

    const rock: LavaRock = { body, visual, glow, createdAt: this.clock };
    this.physics.add.collider(body, this.ground, () => {
      this.explodeLavaRock(rock);
    });
    this.lavaRocks.push(rock);
  }

  updateLavaRocks() {
    const now = this.clock;
    const remaining: LavaRock[] = [];
    for (const rock of this.lavaRocks) {
      if (!rock.body.active || now - rock.createdAt > 4500) {
        this.explodeLavaRock(rock);
        continue;
      }
      rock.visual.setPosition(rock.body.x, rock.body.y);
      rock.visual.rotation += 0.12;
      rock.glow.setPosition(rock.body.x, rock.body.y);
      if (Math.random() < 0.25) this.burst(rock.body.x, rock.body.y, 1, 0xff6600, 'land');

      if (Phaser.Geom.Intersects.RectangleToRectangle(this.player.getBounds(), rock.body.getBounds())) {
        this.damage(1, this.player.x < rock.body.x ? -1 : 1);
        this.explodeLavaRock(rock);
        continue;
      }
      remaining.push(rock);
    }
    this.lavaRocks = remaining;
  }

  explodeLavaRock(rock: LavaRock) {
    if (!rock.body.active && !rock.visual.active) return;
    this.burst(rock.body.x, rock.body.y, 14, 0xff5500, 'land');
    sound('explode');
    rock.visual.destroy();
    rock.glow.destroy();
    rock.body.disableBody(true, true);
  }
}

const game=new Phaser.Game({type:Phaser.AUTO,parent:'game',width:1280,height:720,backgroundColor:'#05080c',antialias:true,roundPixels:true,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},physics:{default:'arcade',arcade:{gravity:{x:0,y:MOVE.gravity},debug:false,fixedStep:true}},scene:[GameScene],input:{keyboard:true},render:{powerPreference:'high-performance'}});
window.addEventListener('pagehide',()=>storeSave(save));
if(import.meta.hot)import.meta.hot.dispose(()=>{game.destroy(true);});
