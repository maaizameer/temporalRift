export const ROOM_IDS = ['start', 'lower', 'well', 'upper', 'final'] as const;
export type RoomId = typeof ROOM_IDS[number];
export interface Save { version: 1; checkpoint: RoomId; doubleJump: boolean; shortcut: boolean; discovered: RoomId[]; deaths: number; elapsed: number; completed: boolean; }
export interface Settings { muted: boolean; reduced: boolean; shake: boolean; }
const KEY = 'placeholder-game-name:progress:v1';
const SETTINGS_KEY = 'placeholder-game-name:settings:v1';
export const freshSave = (): Save => ({ version: 1, checkpoint: 'start', doubleJump: true, shortcut: false, discovered: ['start'], deaths: 0, elapsed: 0, completed: false });
export function validateSave(value: unknown): Save {
  const v = value as Partial<Save> | null;
  if (!v || v.version !== 1 || !ROOM_IDS.includes(v.checkpoint as RoomId)) return freshSave();
  const jump = v.doubleJump === true;
  const checkpoint = v.checkpoint === 'well' ? 'well' : 'start';
  return { version: 1, checkpoint, doubleJump: true, shortcut: jump && v.shortcut === true,
    discovered: Array.isArray(v.discovered) ? [...new Set(v.discovered.filter((x): x is RoomId => ROOM_IDS.includes(x)))] : ['start'],
    deaths: Number.isFinite(v.deaths) ? Math.max(0, Math.floor(v.deaths!)) : 0,
    elapsed: Number.isFinite(v.elapsed) ? Math.max(0, v.elapsed!) : 0, completed: jump && v.shortcut === true && v.completed === true };
}
export function readSave(): Save { try { return validateSave(JSON.parse(localStorage.getItem(KEY) || 'null')); } catch { return freshSave(); } }
export function storeSave(save: Save) { try { localStorage.setItem(KEY, JSON.stringify(save)); } catch { /* Session remains playable. */ } }
export function clearSave() { try { localStorage.removeItem(KEY); } catch { /* Session remains playable. */ } }
export function readSettings(): Settings { try { const v = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}'); return { muted: v.muted === true, reduced: v.reduced === true, shake: v.shake !== false }; } catch { return { muted: false, reduced: false, shake: true }; } }
export function storeSettings(settings: Settings) { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch {} }
