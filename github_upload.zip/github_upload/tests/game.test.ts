import test from 'node:test';
import assert from 'node:assert/strict';
import { Traversal } from '../src/controller';
import { validateSave, freshSave, ROOM_IDS } from '../src/progress';
import { ROOMS, CHECKPOINTS } from '../src/rooms';
import { MOVE } from '../src/config';

test('coyote time allows a late jump but cannot be consumed twice',()=>{
  const state=new Traversal();state.landed(true,100);state.landed(false,120);state.queueJump(180);
  assert.equal(state.consumeJump(180,false),'ground');state.queueJump(185);assert.equal(state.consumeJump(185,false),null);
});
test('buffered jump fires on landing; stale input expires',()=>{
  const state=new Traversal();state.airJumpUsed=true;state.queueJump(100);assert.equal(state.consumeJump(130,true),null);
  state.landed(true,190);assert.equal(state.consumeJump(190,true),'ground');
  state.queueJump(200);assert.equal(state.consumeJump(200+MOVE.buffer+1,true),null);
});
test('double jump needs unlock and allows only one airborne use',()=>{
  const state=new Traversal();state.queueJump(100);assert.equal(state.consumeJump(100,false),null);
  assert.equal(state.consumeJump(100,true),'air');state.queueJump(120);assert.equal(state.consumeJump(120,true),null);
  state.landed(true,140);state.queueJump(140);assert.equal(state.consumeJump(140,true),'ground');state.queueJump(150);assert.equal(state.consumeJump(150,true),'air');
});
test('dash charge needs landing and cooldown, reset restores safe defaults',()=>{
  const state=new Traversal();assert.equal(state.consumeDash(0),true);assert.equal(state.consumeDash(600),false);
  state.landed(true,650);assert.equal(state.consumeDash(650),true);state.landed(true,660);assert.equal(state.consumeDash(660),false);
  state.reset();assert.equal(state.consumeDash(0),true);
});
test('corrupt or inconsistent save data cannot softlock progression',()=>{
  assert.deepEqual(validateSave(null),freshSave());assert.deepEqual(validateSave({version:2}),freshSave());
  const repaired=validateSave({version:1,checkpoint:'well',doubleJump:false,shortcut:true,completed:true,deaths:-10,elapsed:Infinity,discovered:['well','fake','well']});
  assert.equal(repaired.checkpoint,'well');assert.equal(repaired.shortcut,false);assert.equal(repaired.completed,false);assert.equal(repaired.deaths,0);assert.equal(repaired.elapsed,0);assert.deepEqual(repaired.discovered,['well']);
});
test('room graph has valid safe entrances and all five rooms are reachable',()=>{
  const visited=new Set<string>();const visit=(id:typeof ROOM_IDS[number])=>{if(visited.has(id))return;visited.add(id);for(const exit of ROOMS[id].exits){assert.ok(ROOM_IDS.includes(exit.to));assert.ok(exit.spawn[0]>25&&exit.spawn[0]<1895);visit(exit.to);}};visit('start');assert.equal(visited.size,5);
  for(const [id,spawn] of Object.entries(CHECKPOINTS)){const room=ROOMS[id as typeof ROOM_IDS[number]];assert.ok(room.platforms.some(([x,y,w])=>spawn[0]>x&&spawn[0]<x+w&&spawn[1]+26<=y&&y-spawn[1]<100));}
});
test('starting upper route is above single-jump reach but below double-jump reach',()=>{
  const rise=MOVE.jump**2/(2*MOVE.gravity);const gap=840-580;
  assert.ok(gap>rise+40);assert.ok(gap<rise*2);
  assert.ok(ROOMS.start.exits.some(exit=>exit.gate==='shortcut'));
});

test('double jump is available on fresh runs and migrated saves',()=>{
  assert.equal(freshSave().doubleJump,true);
  assert.equal(validateSave({version:1,checkpoint:'start',doubleJump:false}).doubleJump,true);
});
