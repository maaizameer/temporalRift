import numpy as np
import wave
import struct

SAMPLE_RATE = 44100
DURATION = 203.68  # Full gameplay duration (~3 min 23s)
TOTAL_SAMPLES = int(SAMPLE_RATE * DURATION)

print(f"Generating Dark Fantasy Orchestral Soundtrack ({DURATION}s, {TOTAL_SAMPLES} samples)...")

# Initialize stereo audio buffers
left = np.zeros(TOTAL_SAMPLES, dtype=np.float32)
right = np.zeros(TOTAL_SAMPLES, dtype=np.float32)

t = np.linspace(0, DURATION, TOTAL_SAMPLES, endpoint=False)

# 1. Continuous Sub-Bass Cavern Drone (D2 = 73.41Hz, D1 = 36.7Hz, A1 = 55.0Hz)
drone = (
    0.28 * np.sin(2 * np.pi * 73.41 * t) +
    0.18 * np.sin(2 * np.pi * 36.71 * t) +
    0.14 * np.sin(2 * np.pi * 55.00 * t) +
    0.08 * np.sin(2 * np.pi * 110.00 * t + 0.5)
)
# Add subtle low-frequency cavern breath oscillation (0.15Hz LFO)
lfo = 0.75 + 0.25 * np.sin(2 * np.pi * 0.15 * t)
drone *= lfo

left += drone * 0.95
right += drone * 0.95

# 2. Ambient Dark Fantasy String Pads & Chords (D minor: D - F - A - C)
def add_pad(freq, start, end, amp=0.12, pan=0.0):
    i0 = int(start * SAMPLE_RATE)
    i1 = min(int(end * SAMPLE_RATE), TOTAL_SAMPLES)
    if i1 <= i0: return
    sub_t = t[i0:i1] - start
    dur = end - start
    # Envelope with soft attack and release
    env = np.ones_like(sub_t)
    att = min(2.5, dur * 0.3)
    rel = min(3.0, dur * 0.3)
    env[:int(att*SAMPLE_RATE)] = np.linspace(0, 1, int(att*SAMPLE_RATE))
    env[-int(rel*SAMPLE_RATE):] = np.linspace(1, 0, int(rel*SAMPLE_RATE))
    # Rich harmonics
    wave_sig = (
        np.sin(2 * np.pi * freq * sub_t) +
        0.5 * np.sin(2 * np.pi * freq * 2 * sub_t) +
        0.25 * np.sin(2 * np.pi * freq * 3 * sub_t) +
        0.12 * np.sin(2 * np.pi * (freq * 1.003) * sub_t) # chorus detune
    ) * env * amp
    left[i0:i1] += wave_sig * (1.0 - pan)
    right[i0:i1] += wave_sig * (1.0 + pan)

# Act 1 pads (0 - 25s)
add_pad(146.83, 0, 26, amp=0.14, pan=-0.2) # D3
add_pad(174.61, 2, 26, amp=0.12, pan=0.2)  # F3
add_pad(220.00, 4, 26, amp=0.11, pan=-0.1) # A3

# Act 2 pads (25 - 65s)
add_pad(146.83, 25, 45, amp=0.16, pan=-0.2)
add_pad(174.61, 25, 45, amp=0.14, pan=0.2)
add_pad(233.08, 45, 65, amp=0.15, pan=-0.2) # Bb3 tense
add_pad(220.00, 45, 65, amp=0.15, pan=0.2)  # A3

# Act 3 pads (65 - 88s - Cartography)
add_pad(196.00, 65, 88, amp=0.14, pan=-0.3) # G3
add_pad(246.94, 65, 88, amp=0.12, pan=0.3)  # B3
add_pad(293.66, 68, 88, amp=0.11, pan=0.0)  # D4

# Act 4 pads (88 - 120s - Cistern & Ascension)
add_pad(146.83, 88, 105, amp=0.15, pan=-0.2)
add_pad(174.61, 88, 105, amp=0.13, pan=0.2)
add_pad(220.00, 105, 120, amp=0.18, pan=-0.1)
add_pad(261.63, 105, 120, amp=0.16, pan=0.1) # C4
add_pad(293.66, 112, 120, amp=0.20, pan=0.0) # D4 Overdrive swell

# Act 5 pads (120 - 162s - Boss Battle Climax)
add_pad(146.83, 120, 158, amp=0.24, pan=-0.2) # Heavy D3
add_pad(174.61, 120, 158, amp=0.20, pan=0.2)
add_pad(220.00, 120, 158, amp=0.18, pan=-0.1)
add_pad(311.13, 138, 158, amp=0.22, pan=0.1) # Eb4 tension
# Boss defeat triumph & Outro (158 - 203.68s)
add_pad(146.83, 158, 203.68, amp=0.22, pan=-0.2) # D3
add_pad(185.00, 158, 203.68, amp=0.18, pan=0.2)  # F#3 radiant major
add_pad(220.00, 158, 203.68, amp=0.16, pan=0.0)  # A3
add_pad(293.66, 180, 203.68, amp=0.14, pan=0.1)  # D4 high chime chord

# 3. Dynamic Rhythmic War Percussion (Taiko hits & Bass Impacts)
def add_drum_hit(time_sec, strength=1.0, is_sub=False):
    idx = int(time_sec * SAMPLE_RATE)
    dur = 0.45 if is_sub else 0.28
    hit_samples = int(dur * SAMPLE_RATE)
    if idx + hit_samples >= TOTAL_SAMPLES: return
    ht = np.linspace(0, dur, hit_samples)
    freq = 65 if is_sub else 115
    # Pitch drop sweep
    pitch = freq * np.exp(-ht * 12.0)
    sig = np.sin(2 * np.pi * pitch * ht) * np.exp(-ht * (8.0 if is_sub else 14.0)) * strength
    # Noise snap
    noise = (np.random.rand(hit_samples) * 2 - 1) * np.exp(-ht * 24.0) * (0.15 * strength)
    left[idx:idx+hit_samples] += (sig + noise) * 0.95
    right[idx:idx+hit_samples] += (sig + noise) * 0.95

# Add battle drums during combat (Act 2: 25 - 65s, Act 4: 95 - 120s, Act 5 Boss: 122 - 158s)
def add_percussion_track(start, end, bpm=124, intensity=0.85):
    beat_sec = 60.0 / bpm
    cur = start
    beat_idx = 0
    while cur < end:
        # Measure accent on beat 0
        if beat_idx % 4 == 0:
            add_drum_hit(cur, strength=intensity * 1.3, is_sub=True)
        elif beat_idx % 2 == 0:
            add_drum_hit(cur, strength=intensity * 0.9, is_sub=False)
        else:
            add_drum_hit(cur, strength=intensity * 0.6, is_sub=False)
        cur += beat_sec
        beat_idx += 1

add_percussion_track(26.0, 64.0, bpm=120, intensity=0.75)   # Molten Passage battle
add_percussion_track(96.0, 118.0, bpm=128, intensity=0.82)  # Ramparts & Overdrive
add_percussion_track(122.0, 157.0, bpm=136, intensity=1.1)  # Boss Battle Fury

# Massive Boss Vanquish Sub-Drop at 157.5s
add_drum_hit(157.5, strength=2.2, is_sub=True)

# 4. Resonant Cathedral Bell Tolls on Story Beats
def add_bell(time_sec, freq=523.25, amp=0.22):
    idx = int(time_sec * SAMPLE_RATE)
    dur = 4.2
    bell_samples = int(dur * SAMPLE_RATE)
    if idx + bell_samples >= TOTAL_SAMPLES: return
    bt = np.linspace(0, dur, bell_samples)
    bell = (
        np.sin(2 * np.pi * freq * bt) +
        0.6 * np.sin(2 * np.pi * freq * 1.5 * bt) +
        0.35 * np.sin(2 * np.pi * freq * 2.05 * bt) +
        0.2 * np.sin(2 * np.pi * freq * 3.1 * bt)
    ) * np.exp(-bt * 1.1) * amp
    left[idx:idx+bell_samples] += bell * 0.85
    right[idx:idx+bell_samples] += bell * 1.05

add_bell(0.5, 440.0)    # Opening bell
add_bell(25.2, 523.25)  # Molten entrance
add_bell(65.0, 392.0)   # Map unfurl
add_bell(88.0, 440.0)   # Cistern entrance
add_bell(112.0, 587.33) # Overdrive awakening
add_bell(121.5, 349.23) # Boss entrance
add_bell(157.6, 659.25) # Boss defeat triumph
add_bell(164.0, 523.25) # Timeline beacon
add_bell(180.5, 440.0)  # Sacred Altar approached
add_bell(191.0, 587.33) # Victory title bell
add_bell(195.0, 880.0)  # High celestial chime

# Normalize and prevent clipping
max_val = max(np.max(np.abs(left)), np.max(np.abs(right)), 0.001)
left = (left / max_val) * 0.92
right = (right / max_val) * 0.92

# Write 16-bit PCM Stereo WAV
wav_out = '/tmp/trailer_soundtrack.wav'
with wave.open(wav_out, 'wb') as wf:
    wf.setnchannels(2)
    wf.setsampwidth(2)
    wf.setframerate(SAMPLE_RATE)
    # Interleave left and right channels
    stereo_interleaved = np.empty((TOTAL_SAMPLES * 2,), dtype=np.int16)
    stereo_interleaved[0::2] = (left * 32767).astype(np.int16)
    stereo_interleaved[1::2] = (right * 32767).astype(np.int16)
    wf.writeframes(stereo_interleaved.tobytes())

print(f"Soundtrack generated successfully: {wav_out} ({round(DURATION, 1)}s, 2 channels, 44.1kHz)")
