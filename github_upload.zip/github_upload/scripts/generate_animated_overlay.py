import subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import math

WIDTH = 1280
HEIGHT = 720
FPS = 30
DURATION = 203.6
TOTAL_FRAMES = int(DURATION * FPS)

font_bold_path = '/usr/share/fonts/liberation-serif-fonts/LiberationSerif-Bold.ttf'
font_italic_path = '/usr/share/fonts/liberation-serif-fonts/LiberationSerif-Italic.ttf'

font_large = ImageFont.truetype(font_bold_path, 46)
font_medium = ImageFont.truetype(font_bold_path, 36)
font_sub = ImageFont.truetype(font_italic_path, 22)
font_huge = ImageFont.truetype(font_bold_path, 52)

# Playful, high-energy text cards synchronized with user's gameplay
CARDS = [
    {
        "start": 1.0, "end": 4.5,
        "title": "WAKE UP LITTLE BUG 🪲", "sub": "The Void Awaits Your Blade",
        "pos": (640, 160), "angle": -4,
        "bg": (22, 20, 32, 230), "outline": (255, 220, 40, 255), "text_col": (255, 235, 80)
    },
    {
        "start": 6.0, "end": 9.5,
        "title": "MEET THE VESSEL ✨", "sub": "Featuring His Loyal Soul Familiar",
        "pos": (640, 580), "angle": 3,
        "bg": (16, 26, 32, 230), "outline": (100, 240, 220, 255), "text_col": (140, 250, 235)
    },
    {
        "start": 11.5, "end": 15.0,
        "title": "SMOOTH AIR DASH 💨", "sub": "Mothwing Reflexes On Point",
        "pos": (760, 220), "angle": -5,
        "bg": (18, 22, 34, 230), "outline": (0, 220, 255, 255), "text_col": (200, 245, 255)
    },
    {
        "start": 19.0, "end": 22.5,
        "title": "INTO THE ABYSS WE GO 🕳️", "sub": "Down to the Scorched Veins",
        "pos": (640, 580), "angle": 2,
        "bg": (20, 20, 26, 230), "outline": (180, 160, 120, 255), "text_col": (230, 215, 180)
    },
    {
        "start": 26.5, "end": 30.5,
        "title": "WELCOME TO HELL 🌋", "sub": "Watch Your Step Above The Magma",
        "pos": (640, 160), "angle": -5,
        "bg": (36, 16, 12, 235), "outline": (255, 80, 20, 255), "text_col": (255, 140, 50)
    },
    {
        "start": 33.5, "end": 37.0,
        "title": "KAMIKAZE WISP?! BYE 👋💥", "sub": "Airborne Slash Interception",
        "pos": (640, 360), "angle": 5,
        "bg": (38, 14, 10, 240), "outline": (255, 220, 0, 255), "text_col": (255, 240, 60)
    },
    {
        "start": 43.5, "end": 47.0,
        "title": "LAVA SNIPER? NAH BRO 🏃💨", "sub": "Clean Under-Boulder Slide",
        "pos": (500, 240), "angle": -4,
        "bg": (32, 18, 12, 230), "outline": (255, 120, 30, 255), "text_col": (255, 180, 80)
    },
    {
        "start": 54.0, "end": 58.0,
        "title": "HIVE GO BOOM 💣🔥", "sub": "Magma Spire Obliterated",
        "pos": (640, 360), "angle": 4,
        "bg": (35, 12, 10, 235), "outline": (255, 60, 20, 255), "text_col": (255, 210, 60)
    },
    {
        "start": 68.0, "end": 72.0,
        "title": "SHINY RELIC FOUND ✨ [1/3]", "sub": "Crest of the Pyre Restored",
        "pos": (640, 160), "angle": 0,
        "bg": (30, 26, 14, 240), "outline": (255, 215, 0, 255), "text_col": (255, 235, 100)
    },
    {
        "start": 80.0, "end": 86.0,
        "title": "HOLLOW KNIGHT MAP VIBES 🗺️", "sub": "Cornifer Would Be Proud",
        "pos": (640, 150), "angle": -3,
        "bg": (28, 22, 16, 235), "outline": (212, 180, 118, 255), "text_col": (255, 235, 180)
    },
    {
        "start": 96.0, "end": 100.5,
        "title": "DOUBLE JUMP BABY 🪶", "sub": "Wings of the Second Breath Unlocked",
        "pos": (640, 340), "angle": 5,
        "bg": (14, 28, 30, 235), "outline": (80, 240, 220, 255), "text_col": (160, 255, 240)
    },
    {
        "start": 107.0, "end": 112.5,
        "title": "OVERDRIVE TIME ⚡⚡⚡", "sub": "All 3 Relics Restored • Triad Soul Pulse",
        "pos": (640, 350), "angle": -5,
        "bg": (36, 28, 12, 245), "outline": (255, 225, 0, 255), "text_col": (255, 245, 120)
    },
    {
        "start": 118.5, "end": 124.0,
        "title": "BIG BOSS ALERT: CHRONOS 💀", "sub": "Architect of Lost Time Has Entered The Chat",
        "pos": (640, 160), "angle": 0,
        "bg": (30, 16, 36, 240), "outline": (210, 130, 255, 255), "text_col": (240, 190, 255)
    },
    {
        "start": 130.5, "end": 134.5,
        "title": "CLUTCH DASH 💨", "sub": "Blade Dodged By A Micro-Meter",
        "pos": (740, 260), "angle": 5,
        "bg": (18, 22, 36, 235), "outline": (0, 220, 255, 255), "text_col": (210, 250, 255)
    },
    {
        "start": 141.0, "end": 145.5,
        "title": "TIME TRAP? NOT TODAY 😎", "sub": "Out-Manoeuvred The Temporal Stasis",
        "pos": (640, 350), "angle": -4,
        "bg": (28, 18, 38, 235), "outline": (210, 120, 255, 255), "text_col": (245, 195, 255)
    },
    {
        "start": 151.0, "end": 155.5,
        "title": "SHOCKWAVE HOP 🦘", "sub": "Jump • Double Jump • Air Dash",
        "pos": (640, 580), "angle": 4,
        "bg": (22, 24, 32, 230), "outline": (255, 220, 50, 255), "text_col": (255, 235, 100)
    },
    {
        "start": 166.0, "end": 172.0,
        "title": "ABSOLUTE CINEMA 🎬", "sub": "TIME UNBOUND • CHRONOS VANQUISHED 🏆",
        "pos": (640, 350), "angle": -3,
        "bg": (34, 26, 14, 245), "outline": (255, 215, 0, 255), "text_col": (255, 240, 130)
    },
    {
        "start": 180.0, "end": 188.0,
        "title": "TIMELINE RESTORED ⌛", "sub": "The Sacred Hourglass Slumbers In Peace",
        "pos": (640, 160), "angle": 0,
        "bg": (18, 28, 30, 235), "outline": (120, 245, 225, 255), "text_col": (190, 255, 245)
    },
    {
        "start": 191.0, "end": 203.0,
        "title": "CHRONOS : THE TEMPORAL RIFT", "sub": "PLAY IT NOW IN YOUR BROWSER 🎮",
        "pos": (640, 360), "angle": 0,
        "bg": (16, 14, 22, 245), "outline": (255, 215, 0, 255), "text_col": (255, 230, 100),
        "is_grand": True
    }
]

def render_badge(card, progress, duration):
    # progress is in [0, 1]
    # Elastic bounce entrance (0 -> 0.15)
    if progress < 0.15:
        p_norm = progress / 0.15
        scale = p_norm * (1.0 + 0.35 * math.sin(p_norm * math.pi))
        alpha = min(1.0, p_norm * 1.5)
        angle = card["angle"] * (1.0 + 0.3 * (1.0 - p_norm))
        y_offset = (1.0 - p_norm) * 20
    # Fade out / exit (0.85 -> 1.0)
    elif progress > 0.85:
        p_exit = (progress - 0.85) / 0.15
        scale = 1.0 - p_exit * 0.15
        alpha = max(0.0, 1.0 - p_exit)
        angle = card["angle"]
        y_offset = -p_exit * 25
    # Sustain floating wiggle
    else:
        dt = (progress - 0.15) / 0.70
        scale = 1.0 + 0.03 * math.sin(dt * 12.0)
        alpha = 1.0
        angle = card["angle"] + 1.2 * math.sin(dt * 8.0)
        y_offset = 0

    if alpha <= 0.01:
        return None, (0, 0)

    title_font = font_huge if card.get("is_grand") else font_large
    sub_font = font_medium if card.get("is_grand") else font_sub

    t_bbox = title_font.getbbox(card["title"])
    s_bbox = sub_font.getbbox(card["sub"])

    tw = max(t_bbox[2] - t_bbox[0], s_bbox[2] - s_bbox[0])
    th = (t_bbox[3] - t_bbox[1]) + (s_bbox[3] - s_bbox[1]) + 12

    pad_x, pad_y = (34, 20) if card.get("is_grand") else (26, 14)
    bw, bh = tw + pad_x * 2, th + pad_y * 2

    # Draw badge onto local RGBA surface
    badge = Image.new('RGBA', (bw, bh), (0, 0, 0, 0))
    bdraw = ImageDraw.Draw(badge)

    bg_col = tuple(int(c) for c in card["bg"][:3]) + (int(card["bg"][3] * alpha),)
    out_col = tuple(int(c) for c in card["outline"][:3]) + (int(card["outline"][3] * alpha),)
    txt_col = tuple(int(c) for c in card["text_col"]) + (int(255 * alpha),)
    sub_col = (200, 215, 225, int(230 * alpha))

    # Badge background
    bdraw.rounded_rectangle([0, 0, bw, bh], radius=14, fill=bg_col, outline=out_col, width=4)

    # Title text
    tx = (bw - (t_bbox[2] - t_bbox[0])) // 2 - t_bbox[0]
    ty = pad_y - t_bbox[1]
    bdraw.text((tx, ty), card["title"], font=title_font, fill=txt_col, stroke_width=4, stroke_fill=(10, 10, 14, int(240 * alpha)))

    # Sub text
    sx = (bw - (s_bbox[2] - s_bbox[0])) // 2 - s_bbox[0]
    sy = ty + (t_bbox[3] - t_bbox[1]) + 10
    bdraw.text((sx, sy), card["sub"], font=sub_font, fill=sub_col, stroke_width=3, stroke_fill=(10, 10, 14, int(220 * alpha)))

    # Scale with bicubic
    if abs(scale - 1.0) > 0.02:
        nw, nh = max(10, int(bw * scale)), max(10, int(bh * scale))
        badge = badge.resize((nw, nh), resample=Image.BICUBIC)

    # Rotate
    if abs(angle) > 0.1:
        badge = badge.rotate(angle, resample=Image.BICUBIC, expand=True)

    rw, rh = badge.size
    cx, cy = card["pos"]
    target_pos = (int(cx - rw // 2), int(cy - rh // 2 + y_offset))
    return badge, target_pos

def main():
    print(f"=== Rendering {TOTAL_FRAMES} Transparent Animated Text Frames via FFmpeg Pipe ===", flush=True)
    out_mov = "/tmp/animated_overlay.mov"

    cmd = [
        'ffmpeg', '-y',
        '-f', 'rawvideo', '-vcodec', 'rawvideo',
        '-pix_fmt', 'rgba', '-s', f'{WIDTH}x{HEIGHT}', '-r', str(FPS),
        '-i', '-',
        '-c:v', 'qtrle',
        out_mov
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    transparent_frame = Image.new('RGBA', (WIDTH, HEIGHT), (0, 0, 0, 0))
    transparent_bytes = transparent_frame.tobytes()

    for f_idx in range(TOTAL_FRAMES):
        cur_time = f_idx / FPS

        # Find active card
        active_card = None
        for c in CARDS:
            if c["start"] <= cur_time <= c["end"]:
                active_card = c
                break

        if not active_card:
            proc.stdin.write(transparent_bytes)
        else:
            duration = active_card["end"] - active_card["start"]
            progress = (cur_time - active_card["start"]) / duration
            badge_img, pos = render_badge(active_card, progress, duration)
            if badge_img:
                frame = transparent_frame.copy()
                frame.paste(badge_img, pos, badge_img)
                proc.stdin.write(frame.tobytes())
            else:
                proc.stdin.write(transparent_bytes)

        if f_idx % 600 == 0:
            print(f"Rendered {f_idx}/{TOTAL_FRAMES} frames ({int(cur_time)}s / {int(DURATION)}s)...", flush=True)

    proc.stdin.close()
    proc.wait()
    print("Overlay video successfully generated:", out_mov, flush=True)

if __name__ == '__main__':
    main()
