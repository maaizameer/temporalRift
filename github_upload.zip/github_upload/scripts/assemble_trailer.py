import subprocess
import os
import sys

def run_cmd(cmd):
    print("Executing:", " ".join(cmd))
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode != 0:
        print("Error output:\n", res.stderr)
        raise RuntimeError(f"Command failed with exit code {res.returncode}")

def main():
    raw_gameplay = "/tmp/gameplay_raw.webm"
    soundtrack = "/tmp/trailer_soundtrack.wav"
    output_mp4 = "/home/miyagi/Desktop/game/trailer.mp4"
    font_bold = "/usr/share/fonts/liberation-serif-fonts/LiberationSerif-Bold.ttf"
    font_italic = "/usr/share/fonts/liberation-serif-fonts/LiberationSerif-Italic.ttf"

    if not os.path.exists(raw_gameplay):
        print(f"Error: {raw_gameplay} not found")
        sys.exit(1)
    if not os.path.exists(soundtrack):
        print(f"Error: {soundtrack} not found")
        sys.exit(1)

    print("=== Step 1: Generating 20-Second Cinematic Story Prologue ===")
    prologue_mp4 = "/tmp/trailer_prologue.mp4"
    prologue_filters = [
        f"drawtext=fontfile='{font_bold}':text='✦ ❖ ✦':fontsize=28:fontcolor=0xc8aa6e:x=(w-text_w)/2:y=h*0.35:alpha='if(lt(t,1),t,if(gt(t,6),7-t,1))':enable='between(t,0,7)'",
        f"drawtext=fontfile='{font_bold}':text='BEFORE THE RIFTS TORE THE SKY':fontsize=36:fontcolor=0xffebd0:x=(w-text_w)/2:y=h*0.45:alpha='if(lt(t,1),t,if(gt(t,6),7-t,1))':enable='between(t,0,7)'",
        f"drawtext=fontfile='{font_italic}':text='Time was an unbroken, sacred thread':fontsize=22:fontcolor=0x9cb0ba:x=(w-text_w)/2:y=h*0.55:alpha='if(lt(t,1),t,if(gt(t,6),7-t,1))':enable='between(t,0,7)'",

        f"drawtext=fontfile='{font_bold}':text='THEN, THE GRAND HOURGLASS SHATTERED':fontsize=34:fontcolor=0xffa570:x=(w-text_w)/2:y=h*0.45:alpha='if(lt(t,8),t-7,if(gt(t,13),14-t,1))':enable='between(t,7,14)'",
        f"drawtext=fontfile='{font_italic}':text='Plunging the subterranean deeps into molten ruin and stasis':fontsize=20:fontcolor=0xd4b490:x=(w-text_w)/2:y=h*0.55:alpha='if(lt(t,8),t-7,if(gt(t,13),14-t,1))':enable='between(t,7,14)'",

        f"drawtext=fontfile='{font_bold}':text='FROM THE FORGOTTEN SHADOWS OF THE WEAVER':fontsize=32:fontcolor=0xffebd0:x=(w-text_w)/2:y=h*0.45:alpha='if(lt(t,15),t-14,if(gt(t,19),20-t,1))':enable='between(t,14,20)'",
        f"drawtext=fontfile='{font_italic}':text='An ancient Vessel and its Soul Familiar awaken...':fontsize=22:fontcolor=0x8bf4e7:x=(w-text_w)/2:y=h*0.55:alpha='if(lt(t,15),t-14,if(gt(t,19),20-t,1))':enable='between(t,14,20)'",
    ]
    run_cmd([
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", "color=c=black:s=1280x720:d=20:r=30",
        "-vf", ",".join(prologue_filters),
        "-c:v", "libopenh264", "-b:v", "4M", "-pix_fmt", "yuv420p",
        prologue_mp4
    ])

    print("=== Step 2: Processing 135-Second In-Game Gameplay Mastercut ===")
    gameplay_mp4 = "/tmp/trailer_gameplay_titled.mp4"
    gameplay_filters = [
        # Act 1 (Awakening)
        f"drawtext=fontfile='{font_bold}':text='THE ANCIENT THRESHOLD':fontsize=26:fontcolor=0xffebd0:x=(w-text_w)/2:y=h*0.82:box=1:boxcolor=black@0.65:boxborderw=10:enable='between(t,1,7)'",
        f"drawtext=fontfile='{font_italic}':text='Awaken the Companion Soul Orb & Master the Void Nail':fontsize=17:fontcolor=0x8bf4e7:x=(w-text_w)/2:y=h*0.88:box=1:boxcolor=black@0.65:boxborderw=6:enable='between(t,1,7)'",

        # Act 2 (Molten Descent & Combat)
        f"drawtext=fontfile='{font_bold}':text='THE MOLTEN PASSAGE':fontsize=26:fontcolor=0xffa570:x=(w-text_w)/2:y=h*0.82:box=1:boxcolor=black@0.65:boxborderw=10:enable='between(t,26,34)'",
        f"drawtext=fontfile='{font_italic}':text='Slash diving Wisps • Dodge molten boulders • Sever the magma hive':fontsize=17:fontcolor=0xffd29a:x=(w-text_w)/2:y=h*0.88:box=1:boxcolor=black@0.65:boxborderw=6:enable='between(t,26,34)'",

        # Act 3 (Cartography)
        f"drawtext=fontfile='{font_bold}':text='PARCHMENT CARTOGRAPHY & SACRED CHRONICLES':fontsize=24:fontcolor=0xffdca0:x=(w-text_w)/2:y=h*0.82:box=1:boxcolor=black@0.65:boxborderw=10:enable='between(t,60,68)'",
        f"drawtext=fontfile='{font_italic}':text='Chart interconnected caverns and reclaim lost temporal relics':fontsize=17:fontcolor=0xb0c0c8:x=(w-text_w)/2:y=h*0.88:box=1:boxcolor=black@0.65:boxborderw=6:enable='between(t,60,68)'",

        # Act 4 (Cistern & Ascension)
        f"drawtext=fontfile='{font_bold}':text='ABYSSAL CISTERN & SECOND BREATH':fontsize=24:fontcolor=0x9bf1df:x=(w-text_w)/2:y=h*0.82:box=1:boxcolor=black@0.65:boxborderw=10:enable='between(t,76,84)'",
        f"drawtext=fontfile='{font_italic}':text='Unlock airborne jump wings to ascend the ruined towers':fontsize=17:fontcolor=0x9bf1df:x=(w-text_w)/2:y=h*0.88:box=1:boxcolor=black@0.65:boxborderw=6:enable='between(t,76,84)'",

        # Act 4.5 (Temporal Overdrive)
        f"drawtext=fontfile='{font_bold}':text='★ TEMPORAL OVERDRIVE AWAKENED ★':fontsize=28:fontcolor=0xffd700:x=(w-text_w)/2:y=h*0.82:box=1:boxcolor=black@0.7:boxborderw=10:enable='between(t,94,102)'",
        f"drawtext=fontfile='{font_italic}':text='All 3 relics restored — Unleashing radiant 3-way piercing pulses':fontsize=17:fontcolor=0xffea88:x=(w-text_w)/2:y=h*0.88:box=1:boxcolor=black@0.65:boxborderw=6:enable='between(t,94,102)'",

        # Act 5 (Chronos Boss Encounter)
        f"drawtext=fontfile='{font_bold}':text='SANCTUM OF CHRONOS':fontsize=28:fontcolor=0xffc28a:x=(w-text_w)/2:y=h*0.82:box=1:boxcolor=black@0.7:boxborderw=10:enable='between(t,106,114)'",
        f"drawtext=fontfile='{font_italic}':text='Overthrow the Lord of Time and shatter the stasis anomaly':fontsize=17:fontcolor=0xd8b4fe:x=(w-text_w)/2:y=h*0.88:box=1:boxcolor=black@0.65:boxborderw=6:enable='between(t,106,114)'",

        # Act 5.5 (Boss Defeated)
        f"drawtext=fontfile='{font_bold}':text='TIME UNBOUND • CHRONOS VANQUISHED':fontsize=25:fontcolor=0xfff4d0:x=(w-text_w)/2:y=h*0.82:box=1:boxcolor=black@0.7:boxborderw=10:enable='between(t,126,134)'",
    ]
    run_cmd([
        "ffmpeg", "-y",
        "-i", raw_gameplay,
        "-vf", ",".join(gameplay_filters),
        "-c:v", "libopenh264", "-b:v", "4M", "-pix_fmt", "yuv420p",
        gameplay_mp4
    ])

    print("=== Step 3: Generating 25-Second Grand Title Epilogue ===")
    epilogue_mp4 = "/tmp/trailer_epilogue.mp4"
    epilogue_filters = [
        f"drawtext=fontfile='{font_bold}':text='✦ ❖ ✦':fontsize=32:fontcolor=0xc8aa6e:x=(w-text_w)/2:y=h*0.22",
        f"drawtext=fontfile='{font_bold}':text='CHRONOS — THE TEMPORAL RIFT':fontsize=46:fontcolor=0xffeac2:x=(w-text_w)/2:y=h*0.34",
        f"drawtext=fontfile='{font_italic}':text='A Dark Fantasy Metroidvania Odyssey':fontsize=24:fontcolor=0x9cb0ba:x=(w-text_w)/2:y=h*0.46",

        f"drawtext=fontfile='{font_bold}':text='SEAMLESS 60 FPS COMBAT  •  HANDCRAFTED CAVERNS':fontsize=16:fontcolor=0xd4b476:x=(w-text_w)/2:y=h*0.58",
        f"drawtext=fontfile='{font_bold}':text='DYNAMIC LUMAFLY LIGHTING  •  PARCHMENT CARTOGRAPHY':fontsize=16:fontcolor=0xd4b476:x=(w-text_w)/2:y=h*0.64",

        f"drawtext=fontfile='{font_bold}':text='PLAYABLE NOW IN BROWSER':fontsize=22:fontcolor=0xffd700:x=(w-text_w)/2:y=h*0.76",
        f"drawtext=fontfile='{font_italic}':text='Reclaim the Shattered Hourglass Today':fontsize=16:fontcolor=0x8da0a8:x=(w-text_w)/2:y=h*0.83",
    ]
    run_cmd([
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", "color=c=black:s=1280x720:d=25:r=30",
        "-vf", ",".join(epilogue_filters),
        "-c:v", "libopenh264", "-b:v", "4M", "-pix_fmt", "yuv420p",
        epilogue_mp4
    ])

    print("=== Step 4: Concatenating 3-Minute Master Video with Orchestral Soundtrack ===")
    concat_list = "/tmp/concat_trailer.txt"
    with open(concat_list, "w") as f:
        f.write(f"file '{prologue_mp4}'\n")
        f.write(f"file '{gameplay_mp4}'\n")
        f.write(f"file '{epilogue_mp4}'\n")

    cmd = [
        "ffmpeg", "-y",
        "-f", "concat", "-safe", "0", "-i", concat_list,
        "-i", soundtrack,
        "-c:v", "libopenh264",
        "-b:v", "4.5M",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", "180",
        output_mp4
    ]
    run_cmd(cmd)

    size_mb = os.path.getsize(output_mp4) / (1024 * 1024)
    print(f"\n Master 3-Minute Cinematic Trailer Successfully Produced: {output_mp4} ({size_mb:.2f} MB)")

if __name__ == "__main__":
    main()
