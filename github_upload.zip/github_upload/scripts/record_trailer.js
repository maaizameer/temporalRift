import puppeteer from 'puppeteer';
import fs from 'fs';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function main() {
  console.log('=== Launching Headless Chromium for Master 3-Minute Trailer Capture ===');
  const browser = await puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--use-gl=swiftshader',
      '--enable-webgl',
      '--window-size=1280,720',
      '--autoplay-policy=no-user-gesture-required'
    ]
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 720 });
  await page.goto('http://localhost:5173/', { waitUntil: 'networkidle2' });

  const rawOutputPath = '/tmp/gameplay_raw.webm';
  const writeStream = fs.createWriteStream(rawOutputPath);

  let totalBytes = 0;
  await page.exposeFunction('onChunk', (base64Chunk) => {
    const buf = Buffer.from(base64Chunk, 'base64');
    totalBytes += buf.length;
    writeStream.write(buf);
  });

  console.log('Attaching MediaRecorder to Canvas Stream at 30 FPS...');
  await page.evaluate(() => {
    const canvas = document.querySelector('canvas');
    if (!canvas) throw new Error('Canvas not found');
    const stream = canvas.captureStream(30);
    const rec = new MediaRecorder(stream, {
      mimeType: 'video/webm;codecs=vp8',
      videoBitsPerSecond: 8000000
    });
    rec.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const b64 = reader.result.split(',')[1];
          window.onChunk(b64);
        };
        reader.readAsDataURL(e.data);
      }
    };
    rec.start(100);
    window.__trailerRecorder = rec;
  });

  console.log('Recording active. Commencing 170-second cinematic choreography...');
  const exec = async (fn) => page.evaluate(fn);

  // --- ACT 1: Awakening at the Threshold (~30s) ---
  console.log('[Act 1] The Ancient Threshold: Awakening & Cavern Traversal (30s)');
  await exec(() => {
    window.__game.scene.resume();
    window.__game.showBanner('THE ANCIENT THRESHOLD', 'Forgotten Caverns of the Weaver');
  });
  await sleep(3500);

  // Deliberate atmospheric traversal
  for (let step = 0; step < 10; step++) {
    await exec(() => window.__game.setVelocity(220, 0));
    await sleep(600);
  }

  // Jump and mothwing dash across chasm
  await exec(() => window.__game.jump());
  await sleep(450);
  await exec(() => window.__game.dash(1));
  await sleep(1000);

  // Demonstrate fluid nail slashes and orb shot
  await exec(() => window.__game.slash(1, 0));
  await sleep(500);
  await exec(() => window.__game.slash(1, -0.3));
  await sleep(450);
  await exec(() => window.__game.slash(-1, 0));
  await sleep(450);
  await exec(() => window.__game.shoot(1, 0));
  await sleep(1200);

  // Sprint run towards upper ledge
  for (let step = 0; step < 8; step++) {
    await exec(() => window.__game.setVelocity(280, 0));
    await sleep(500);
  }
  await exec(() => window.__game.jump());
  await sleep(400);
  await exec(() => window.__game.dash(1));
  await sleep(1200);

  for (let step = 0; step < 6; step++) {
    await exec(() => window.__game.setVelocity(250, 0));
    await sleep(500);
  }
  await sleep(2000);

  // --- ACT 2: Molten Passage & Inferno Combat (~45s) ---
  console.log('[Act 2] Molten Passage: Wisps, Lava Hurlers & Hive Spawner (45s)');
  await exec(() => {
    window.__game.warp('lower', [180, 790]);
    window.__game.showBanner('MOLTEN PASSAGE', 'Scorched Veins of the Under-Deep');
  });
  await sleep(3500);

  // Advance into volcanic room
  for (let step = 0; step < 8; step++) {
    await exec(() => window.__game.setVelocity(240, 0));
    await sleep(500);
  }

  // Combat with Kamikaze Wisp: leap into the air and slash
  await exec(() => window.__game.jump());
  await sleep(350);
  await exec(() => window.__game.slash(1, 0));
  await sleep(300);
  await exec(() => window.__game.slash(1, 0.4));
  await sleep(900);

  // Advance towards Lava Hurler
  for (let step = 0; step < 10; step++) {
    await exec(() => window.__game.setVelocity(250, 0));
    await sleep(450);
  }

  // Dodge incoming molten rock
  await exec(() => window.__game.jump());
  await sleep(350);
  await exec(() => window.__game.dash(1));
  await sleep(600);

  // Slashes and ranged orb cast into Lava Hurler
  await exec(() => window.__game.slash(1, 0));
  await sleep(350);
  await exec(() => window.__game.shoot(1, 0));
  await sleep(400);
  await exec(() => window.__game.slash(1, 0));
  await sleep(800);

  // Advance to Magma Spawner Hive
  for (let step = 0; step < 8; step++) {
    await exec(() => window.__game.setVelocity(240, 0));
    await sleep(450);
  }

  // Slashes on Spawner Hive
  for (let hit = 0; hit < 5; hit++) {
    await exec(() => window.__game.slash(1, -0.1));
    await sleep(350);
    await exec(() => window.__game.shoot(1, 0));
    await sleep(400);
  }

  // Jump to high volcanic ledge and claim Relic I
  await exec(() => window.__game.jump());
  await sleep(400);
  await exec(() => window.__game.dash(1));
  await sleep(600);
  await exec(() => window.__game.collectRelic('lower_1420_570'));
  await sleep(3000);

  // --- ACT 3: Cartography & Relics Journal (~20s) ---
  console.log('[Act 3] Parchment Cartography & Relic Bestiary (20s)');
  await exec(() => window.__game.openMap('map'));
  await sleep(8000);
  await exec(() => window.__game.openMap('relics'));
  await sleep(9000);
  await exec(() => window.__game.closeMap());
  await sleep(2000);

  // --- ACT 4: Abyssal Cistern & Hollow Ramparts (~35s) ---
  console.log('[Act 4] Abyssal Cistern & Second Breath Ascension (35s)');
  await exec(() => {
    window.__game.warp('well', [220, 790]);
    window.__game.showBanner('ABYSSAL CISTERN', 'Submerged Depths of Still Water');
  });
  await sleep(3000);

  // Reclaim Relic II
  await exec(() => window.__game.collectRelic('well_1620_430'));
  await sleep(2000);

  // Ascend high flooded vertical shafts with Double Jump
  for (let ascent = 0; ascent < 6; ascent++) {
    await exec(() => window.__game.setVelocity(250, 0));
    await sleep(400);
    await exec(() => window.__game.jump());
    await sleep(350);
    await exec(() => window.__game.doubleJump());
    await sleep(700);
  }

  // Enter Hollow Ramparts
  await exec(() => {
    window.__game.warp('upper', [200, 790]);
    window.__game.showBanner('HOLLOW RAMPARTS', 'Overlook of the Lost Spire');
  });
  await sleep(3000);

  // Reclaim Relic III
  await exec(() => window.__game.collectRelic('upper_730_560'));
  await sleep(2000);

  // AWAKEN TEMPORAL OVERDRIVE!
  console.log('[Act 4.5] Temporal Overdrive Awakening!');
  await exec(() => {
    window.__game.setOverdrive(true);
    window.__game.showBanner('TEMPORAL OVERDRIVE', 'Triad Soul Pulse Unleashed');
  });
  await sleep(2500);

  // Unleash 3-way piercing overdrive pulses
  for (let burst = 0; burst < 6; burst++) {
    await exec(() => window.__game.shoot(1, 0));
    await sleep(700);
    await exec(() => window.__game.slash(1, 0));
    await sleep(450);
  }

  // --- ACT 5: Sanctum of Chronos & Epic Boss Battle (~45s) ---
  console.log('[Act 5] Sanctum of Chronos: Boss Battle & Time Unbound (45s)');
  await exec(() => {
    window.__game.warp('final', [350, 790]);
    window.__game.showBanner('SANCTUM OF CHRONOS', 'Domain of the Slumbering Hourglass');
  });
  await sleep(3000);

  // Chronos emerges
  await exec(() => window.__game.triggerBoss());
  await sleep(3500);

  // Dash attack dodge & strike
  await exec(() => window.__game.dash(1));
  await sleep(400);
  await exec(() => window.__game.slash(1, 0));
  await sleep(400);
  await exec(() => window.__game.damageBoss());
  await sleep(700);

  // Jump high over Chronos blade dash
  await exec(() => window.__game.jump());
  await sleep(400);
  await exec(() => window.__game.doubleJump());
  await sleep(450);
  await exec(() => window.__game.shoot(1, 0));
  await sleep(800);

  // Overdrive shots into Chronos
  for (let hit = 0; hit < 6; hit++) {
    await exec(() => window.__game.damageBoss());
    await exec(() => window.__game.shoot(1, 0));
    await sleep(550);
  }

  // Dodge shockwave with mothwing back-dash
  await exec(() => window.__game.dash(-1));
  await sleep(500);
  await exec(() => window.__game.jump());
  await sleep(400);
  await exec(() => window.__game.slash(1, 0));
  await sleep(700);

  // Phase 2 boss overdrive hits
  for (let hit = 0; hit < 7; hit++) {
    await exec(() => window.__game.damageBoss());
    await sleep(450);
  }

  // Decisive Final Strike!
  console.log('[Act 5.5] Chronos Vanquished - Time Unbound!');
  await exec(() => {
    window.__game.defeatBoss();
  });
  await sleep(7000);

  // --- ACT 6: Restoration of the Timeline Beacon (~12s) ---
  console.log('[Act 6] Communing with the Timeline Beacon (12s)');
  for (let walk = 0; walk < 10; walk++) {
    await exec(() => window.__game.setVelocity(200, 0));
    await sleep(600);
  }
  await sleep(5000);

  // Finalize video stream
  console.log('Choreography complete. Finalizing video stream...');
  await page.evaluate(() => {
    if (window.__trailerRecorder && window.__trailerRecorder.state !== 'inactive') {
      window.__trailerRecorder.stop();
    }
  });

  await sleep(2000);
  writeStream.end();
  await browser.close();

  console.log(`Recording complete! Raw video saved to ${rawOutputPath} (${totalBytes} bytes).`);
}

main().catch((err) => {
  console.error('Recording error:', err);
  process.exit(1);
});
