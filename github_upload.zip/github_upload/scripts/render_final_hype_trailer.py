import subprocess
import os
import sys

def main():
    raw_gameplay = "/home/miyagi/Desktop/game/recording.mp4"
    animated_overlay = "/tmp/animated_overlay.mov"
    soundtrack = "/tmp/trailer_soundtrack.wav"
    output_mp4 = "/home/miyagi/Desktop/game/trailer.mp4"

    if not os.path.exists(raw_gameplay):
        print(f"Error: {raw_gameplay} not found")
        sys.exit(1)
    if not os.path.exists(animated_overlay):
        print(f"Error: {animated_overlay} not found")
        sys.exit(1)
    if not os.path.exists(soundtrack):
        print(f"Error: {soundtrack} not found")
        sys.exit(1)

    print("=== Assembling Final High-Energy Animated Gameplay Trailer ===")

    # Dynamic camera zoom and punch-in formula across action beats:
    # We define zoom multipliers and camera shakes:
    # Dash (t: 11-13) -> 1.22
    # Wisp Strike (t: 33.5-35.5) -> 1.30 + shake
    # Lava Dodge (t: 43.5-45.5) -> 1.22
    # Hive Spawner Burst (t: 54-56.5) -> 1.26 + shake
    # Double Jump (t: 96-98.5) -> 1.20
    # Overdrive (t: 107-110) -> 1.28 + pulsing
    # Chronos Boss Appears (t: 118.5-122) -> 1.35
    # Chronos Blade Dash (t: 130.5-133) -> 1.25
    # Time Trap Dodge (t: 141-143.5) -> 1.26
    # Shockwave Jump (t: 151-153.5) -> 1.20
    # Boss Vanquished (t: 166-170) -> 1.40 + mega shake
    # General gentle breathing zoom: 1.0 + 0.02*sin(t*0.5)

    zoom_expr = (
        "1.0 + 0.03*sin(t*0.6) "
        "+ 0.22*between(t,11,13) "
        "+ 0.30*between(t,33.5,35.5) "
        "+ 0.22*between(t,43.5,45.5) "
        "+ 0.26*between(t,54,56.5) "
        "+ 0.20*between(t,96,98.5) "
        "+ 0.28*between(t,107,110) "
        "+ 0.35*between(t,118.5,122) "
        "+ 0.25*between(t,130.5,133) "
        "+ 0.26*between(t,141,143.5) "
        "+ 0.20*between(t,151,153.5) "
        "+ 0.40*between(t,166,170)"
    )

    # Camera impact shake
    shake_x = (
        "16*sin(t*85)*between(t,33.5,34.5) "
        "+ 18*sin(t*90)*between(t,54,55.5) "
        "+ 14*sin(t*80)*between(t,118.5,120) "
        "+ 24*sin(t*95)*between(t,166,168)"
    )
    shake_y = (
        "16*cos(t*85)*between(t,33.5,34.5) "
        "+ 18*cos(t*90)*between(t,54,55.5) "
        "+ 14*cos(t*80)*between(t,118.5,120) "
        "+ 24*cos(t*95)*between(t,166,168)"
    )

    crop_w = f"in_w/({zoom_expr})"
    crop_h = f"in_h/({zoom_expr})"
    crop_x = f"(in_w-out_w)/2 + ({shake_x})"
    crop_y = f"(in_h-out_h)/2 + ({shake_y})"

    # Filter graph:
    # 1. Base video: crop for camera zoom/shake -> scale to 1280x720 -> fps=30
    # 2. Overlay transparent animated kinetic typography on top
    filter_complex = (
        f"[0:v]crop=w='{crop_w}':h='{crop_h}':x='{crop_x}':y='{crop_y}',"
        f"scale=1280:720,fps=30[cam];"
        f"[cam][1:v]overlay=0:0[v]"
    )

    cmd = [
        "ffmpeg", "-y",
        "-i", raw_gameplay,
        "-i", animated_overlay,
        "-i", soundtrack,
        "-filter_complex", filter_complex,
        "-map", "[v]",
        "-map", "2:a",
        "-c:v", "libopenh264",
        "-b:v", "5M",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", "203.6",
        output_mp4
    ]

    print("Running master FFmpeg composite...")
    res = subprocess.run(cmd)
    if res.returncode == 0:
        size_mb = os.path.getsize(output_mp4) / (1024 * 1024)
        print(f"\n Master High-Energy Animated Gameplay Trailer Produced: {output_mp4} ({size_mb:.2f} MB)")
    else:
        print("FFmpeg compositing failed with exit code", res.returncode)
        sys.exit(res.returncode)

if __name__ == "__main__":
    main()
