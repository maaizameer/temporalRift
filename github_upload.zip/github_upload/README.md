# Placeholder-Game-Name

A self-contained Phaser metroidvania placeholder. Five connected rooms, responsive traversal, double jump from the start, a return shortcut, generic combat, checkpoints, and a finish. The game fills the browser viewport; the main menu, HUD and pause menu live inside it.

All artwork is generated locally. All sound is synthesized with Web Audio. No downloaded art, fonts, remote services, backend, account, or production character assets are required.

## Run locally

Use Node.js **22.12 or newer** and npm. Development was verified with Node 26.7.0 / npm 11.19.0 on macOS.

```bash
npm install
npm run dev
```

Open the Local URL printed by Vite, normally **http://127.0.0.1:5173/**. If that port is occupied, Vite prints another port. Keep the terminal running; Ctrl+C stops it. Use a desktop keyboard. Click **Begin exploring** or **Continue exploring** to start and enable sound.

Dependencies are already installed in the delivered folder. `npm ci` provides a clean, lockfile-based reinstall.

## Build and checks

```bash
npm test
npm run typecheck
npm run build
npm run preview
```

Preview normally serves at **http://127.0.0.1:4173/**. `dist/` is a static web build. Deploy the contents of that folder to a static host; opening the source `index.html` directly through `file://` is not supported. The Vite base is relative so builds can also be hosted under a subdirectory.

## Visual direction

Jump, double jump, sprint and dash use tapered animated air ribbons rather than dot/dust particles. Single-jump wind is restrained; double jump uses broader, stronger sweeping arcs. Landing uses a low outward air sweep. Contact damage shakes the camera at 0.011 normalized intensity for 210 ms; hazards use 0.019 for 300 ms; death uses 0.024 for 320 ms. Reduced effects and shake preferences remain respected.

Canvas backing size follows device pixel density (capped at 2×), with 3×-resolution world-label textures and rounded camera positioning. Menu backdrop blur is removed. Menus contain only action titles, settings, buttons and completion statistics. There are no in-game tutorial tips. Controls remain documented here.

## Controls

| Action | Input |
| --- | --- |
| Move | A/D or left/right arrows |
| Jump | Space; release early for a shorter jump |
| Double jump | Press Space again in the air; available immediately |
| Sprint | Hold Shift on the ground |
| Horizontal dash | K or X, in the facing direction |
| Melee strike | J or Z |
| Use a door, checkpoint, switch or exit | E while close to its marker |
| Pause/resume | Escape |
| Mute | M |
| Diagnostics | F3 |

Dash restores on landing, with a short cooldown. It does not grant immunity. Thin platforms allow jumping upward through them and catch you while falling. Walk or jump off their edges to descend. Double jump uses a fresh press; holding Space does not trigger it automatically.

## The route (spoilers)

1. **The Threshold:** the upper ledges are reachable with double jump; the final passage requires the circuit switch. Rest at the triangle checkpoint if desired, then use the lower-right door.
2. **The Underpass:** jump and dash over gaps and coral hazards. The right door leads to the Well. Enemies can be avoided or defeated with three short melee strikes.
3. **The Well:** use the checkpoint. Double jump is already available. Climb the thin ledges to the upper-right door. Rest again if you want to save the Well checkpoint.
4. **The Return:** cross two gaps, interact with the circuit switch near the right side, then use the right door to return to the Threshold's upper ledge.
5. **The Threshold again:** cross the upper platforms to the upper-left exit. The opened switch unlocks this door.
6. **Open Circuit:** cross the final chamber and interact with the end beacon. Completion shows exploration time, deaths and discovered rooms. You can continue exploring or replay.

No boss, character-specific ability set, story, special enemy attacks or production art is included. Double jump is available from the beginning for movement testing. The circuit switch still gates the final exit.

## Health, saves and settings

Five health units. Enemy contact deals one damage; coral hazards deal two. Damage adds knockback and approximately 850 ms of immunity, so overlap does not drain health every frame. Stronger impacts produce stronger, capped camera shake. Hazards/pits return you to the checkpoint; fatal damage opens the respawn menu. Enemies reset on checkpoint recovery and room entry.

Checkpoint location, circuit switch, discovered rooms, deaths and exploration time persist locally. Death preserves progression. Old saves are migrated to enable double jump immediately. The completion timer stops when the exit is first activated. **Restart run** asks before clearing run progress. Sound and effects settings are saved separately and survive restarting a run.

Pause includes mute, reduced effects and screen-shake settings. Reduced effects disable shake, impact pauses, stretch and excess particles. Losing focus or switching away pauses automatically and clears held inputs. Save failures are caught; if browser storage is blocked, the current session is still playable.

## Source map

| File | Purpose |
| --- | --- |
| `IMPLEMENTATION_PLAN.md` | Governing scope, controller rules, architecture and acceptance criteria |
| `src/audio.ts` | Filtered air-whoosh and soft low-body jump synthesis |
| `src/config.ts` | Movement timings, velocities, gravity and colors |
| `src/controller.ts` | Testable jump buffering, coyote time and traversal charges |
| `src/rooms.ts` | Platforms, room graph, enemy spawns, hazards and interactive markers |
| `src/progress.ts` | Save validation, persistence and settings |
| `src/main.ts` | Phaser scene, player controller integration, combat, camera, effects, menus and sound |
| `src/style.css` | Full-viewport HUD and in-game menus |
| `tests/game.test.ts` | Controller, save-data and progression geometry checks |
| `VERIFICATION.md` | Actual validation performed and remaining limits |

The physics world uses fixed 120 Hz stepping. Movement acceleration and gameplay timers use elapsed time. Particle/afterimage counts are bounded. F3 shows live FPS, position, traversal state and remaining enemy HP.

## Replace placeholders with team artwork

1. Add exported art under `public/assets/`. Use PNG/WebP images, a fixed-frame sprite sheet, or an atlas image plus JSON. Retain layered art originals elsewhere.
2. Add a Phaser `preload()` method to `GameScene` and load the exported assets with a new key, e.g. `this.load.spritesheet('hero-art', 'assets/hero.png', { frameWidth: 64, frameHeight: 64 })`.
3. In `create()`, replace the visible `core` image with a sprite using that art key. Match the current visual footprint and origin; adjust visual offsets to align the feet. The generated `player` texture can remain on the **invisible physics image**, keeping the 26×42 collision body independent of the art. The visible placeholder scarf/eye can be removed.
4. Define animations for `idle`, `run`, `sprint`, `rise`, `fall`, `doubleJump`, `dash`, `attack` and `hurt`, then select them from existing controller state. These state names are a suggested animation contract, not preloaded art.
5. Replace the visible image inside each enemy container similarly. Keep the hidden enemy physics object unless deliberately changing collision size. The small HP bar and hit feedback can remain.
6. Change platform decoration/background drawing independently from collision geometry. Room solids and placements are centralized in `rooms.ts`.
7. Replace `sound()` with loaded sound assets when ready. The sound function's event names form the temporary integration points.

Do not resize the physics body each animation frame. If the final character needs a different body, tune its fixed dimensions once, then check all ledges and spawn points again.

## Deliberate limits

Desktop keyboard prototype; touch and gamepad controls are not implemented. No networking, backend saves, boss, one-way platform drop-through input, wall movement, slopes, moving platforms, remapping menu or final accessibility audit. The room map shows a compact route overview, not a detailed spatial minimap. Save data is specific to this browser/origin. Camera composition adapts to aspect ratio, so narrow windows show less horizontal world at once.

The bundled Phaser renderer accounts for most of the roughly 340 KB compressed JavaScript download. There are no external media downloads. Repository: https://github.com/v-ahmed/Placeholder-Game-Name. No public game deployment has been created.

## Jump audio and grounding revision

Jump sound blends a short filtered-noise air swoosh with a quiet descending low sine tone; double jump is slightly fuller. Both use the existing mute and user-gesture audio initialization. The noise buffer is reused, and source/filter/gain nodes disconnect after playback. Player art is anchored at the collision body’s bottom, preserving foot contact during squash/stretch; grounded rotation is disabled so no corner dips through the floor.
