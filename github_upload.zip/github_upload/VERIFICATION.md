# Verification — 2026-10-17

## Environment

macOS; Node 26.7.0; npm 11.19.0; Phaser 3.90.0; Vite 7.3.7. Tested interactively in the Codex in-app Chromium browser at a roughly 979×827 viewport. Gameplay filled the viewport and adapted camera zoom. F3 reported about 60–61 FPS during traversal and combat in this environment; this is an observation, not a benchmark across devices.

## Automated checks

- TypeScript strict typecheck and Vite production build: pass.
- Seven targeted tests: pass. Covers coyote timing, buffered jumps/expiry, unlock-gated double jump/landing reset, dash charge/cooldown, corrupt save recovery, room graph/checkpoint safety, and single/double-jump gate reach.
- Dependency audit after updating Vite to 7.3.7: zero reported vulnerabilities.

## Interactive browser checks

- Played the complete five-room route with keyboard input, including the original lower route, Second Breath pickup, Well climb, upper return, circuit switch, starting-room upper platforms, final route and completion beacon.
- Completion screen displayed 5/5 rooms, run time and deaths. Test deaths occurred while stepping through the early playtest; respawn recovered correctly.
- Jump and aerial dash crossed gaps; double jump displayed its ring and consumed one airborne use. Thin platforms allowed upward passage and supported descending landings.
- Confirmed the locked route rejected interaction before opening the switch; opening it updated the objective and allowed the return/final passage.
- Saved at the Well and reloaded: checkpoint and double-jump unlock persisted. Later reload preserved circuit/completion progress and discovered rooms.
- Three distinct melee swings reduced a fresh enemy from 3 HP to 2, 1, then 0. The enemy disappeared after the third strike, with no runtime errors. A full swing window removed one HP, not one per update.
- Contact damage, health loss, knockback, death menu and checkpoint respawn were exercised during the playthrough.
- Escape paused and resumed; movement stopped while paused. Held inputs were cleared on menu transitions.
- Mute/reduced effects/shake settings were changed, page reloaded, and checkbox states persisted. Defaults were restored afterward.
- Browser error/warning log after the interactive playthrough: empty.
- Restart confirmation was exercised: a new run returned to the Threshold with no double jump and the initial objective.
- Final production build was served with `npm run preview` on port 4173: main menu, movement, pause and rendering worked; browser warning/error log was empty.
- Removed all website/header/footer framing after user clarification. Only the game, HUD and in-game menus remain.

## Limits and follow-up

No broad hardware/browser matrix, touch/gamepad testing, or automated visual regression suite. Audio events were exercised through game actions and Web Audio initialization; subjective sound quality was not independently measured. Focus-loss behavior is implemented with window blur/document visibility listeners; native OS app switching was not separately audited. Storage-denial handling is implemented with guarded reads/writes; browser-level storage denial was not forced during this run. The Vite build's large-chunk notice reflects the Phaser engine bundle, not a failed build.

This file records actual checks, not a claim that every acceptance case was independently automated.

## Wind/clarity revision — 2026-10-17

- Double jump enabled on fresh runs and old saves; eight automated tests pass including migration coverage.
- Single and double jumps exercised in the browser immediately after loading; diagnostics confirmed the airborne jump was consumed.
- Wind ribbons visually inspected; removed jump/landing/run dust emissions, retained combat impact sparks.
- Main/pause menus inspected: titles, buttons and settings only. No tutorials, reassurance paragraphs, objective prose or giant background lettering.
- Checkpoint/exit labels and vector symbols inspected at 1280×720; world labels render with 3× texture resolution. Canvas backing density is capped at 2× device scale; no CSS backdrop blur.
- Contact/hazard/death shake amplitudes increased; stronger impacts now restart shake. Settings can still disable it.
- Strict production build passes. Browser warning/error log empty during jump/menu checks.

## Jump audio / grounding revision — 2026-10-17

- Added filtered noise plus low sine-body synthesis for jump and double jump. Both events and mute/unmute were exercised in the browser without runtime errors. Subjective audio quality was not independently measured.
- Corrected five-pixel art/body foot mismatch with a bottom-anchored visual; squash/stretch preserve the foot position. Disabled grounded lean rotation.
- Browser screenshot after jumping/landing confirms the visible blob rests on the platform surface.
- Strict production build and all eight tests pass.
